PitchLab R33 — The Minimal Editor (first GUI surface), Linux x64 + Windows x64
==============================================================================

WHAT THIS IS
------------
The R33 round of the PitchLab Harmonizer wrapper: a MINIMALIST EDITOR
(the user asked for "egy minimalista ui") — a fixed-size 784x416
software-rendered IPlugView served by IEditController::createView
("Editor"). Same "Balanced" variant as the R31/R32 demos (Lagrange6
interpolation, decimated YIN detector, the frozen 38-parameter surface +
v2 state blob + the R31 IPitchTelemetry vendor interface — all
UNCHANGED; see the R31/R32 packages).

The editor:
  * dark warm-neutral theme, single amber accent, embedded classic 5x7
    bitmap font — NO VSTGUI, NO font stack, NO new heavy dependencies
    (core Xlib on Linux; user32+gdi32 on Windows);
  * ALL 38 parameters reachable: global PITCH slider / VOICES stepper /
    HARMONY MAP toggle / FEEDBACK + MIX sliders; per-voice transpose
    fields (drag up/down), gain bars (drag), delay fields (drag),
    MUTE buttons; the header BYPASS LED is clickable;
  * every edit lands on the exact step-quantized grid the host surface
    defines (0.01 st pitch steps etc.) via the canonical
    beginEdit -> setParamNormalized + performEdit -> endEdit protocol;
    DOUBLE-CLICK any control = its documented default;
  * the bottom PITCH TELEMETRY panel renders the R31 vendor interface
    LIVE: per-voice Hz (derived from id 7's cents-from-C4), raw cents,
    the id-11 confidence bar, the id-8 glide ratio, and per-voice
    activity LEDs driven by consumeDirtyBits(); the -65535 no-pitch
    sentinel and the zeroed parked/never-polled cells render as "--".

The two PNG screenshots in screenshots/ are the REAL renderer output
(rendered by the same model/renderer the live view uses, via the
offscreen screenshot tool — not mock-ups).

INSTALL (Linux x64)
-------------------
Copy linux/PitchLab_Lagrange6_Balanced.vst3 to:
  per-user : ~/.vst3/
  for all  : /usr/lib/vst3/
The bundle was built + verified on Debian 13 x64 (g++ 14): wrapper tests
21/21, module integration 17/17, UI tests 11/11 (incl. a real-X-server
pixel-identity proof), Steinberg validator 47/47.

INSTALL (Windows x64)
---------------------
Copy windows-x64/PitchLab_Lagrange6_Balanced.vst3 to:
  per-user : C:\Users\<you>\AppData\Local\Programs\Common\VST3\
  for all  : C:\Program Files\Common Files\VST3\
The .pdb beside the binary is debug symbols (optional).

HOST AUTHORS (the editor contract)
----------------------------------
  * createView("Editor") returns a fresh IPlugView per call; any other
    name returns nullptr. canResize() is kResultFalse (fixed size);
    getSize() = 784x416.
  * Linux: the view attaches into the parent you pass with the
    "X11EmbedWindowID" platform type and REQUIRES the VST 3.6.8+ Linux
    hosting contract — IRunLoop queried from the IPlugFrame you set via
    setFrame() (an IEventHandler on the view's X11 connection fd + an
    ITimerHandler at ~30 Hz drive it, on YOUR thread). Without IRunLoop
    attached() returns kResultFalse (parameters stay fully automatable).
  * Windows: the view creates a WS_CHILD window in your HWND; WM_TIMER
    (~30 Hz) + WM_PAINT drive it on your message thread.
  * macOS: not implemented (isPlatformTypeSupported refuses NSView).
  * The editor performs edits ONLY through your IComponentHandler
    (beginEdit/performEdit/endEdit) + setParamNormalized on the
    controller — the audio path keeps reading parameter queues
    exclusively; no shared mutable state crosses into process().

TOOLCHAIN HONESTY NOTES
-----------------------
  * Linux bundle: native build (g++ 14.2), executed and verified
    end-to-end in this environment.
  * Windows bundle: cross-built on Linux with Zig 0.13.0 (clang/LLVM 18
    frontend, lld, mingw-w64 headers, static libc++) — the same recorded
    toolchain deviation behind the accepted R21/R22/R24-W/R32 Windows
    deliveries. NO PE execution happened in this environment: the
    Windows binary is verified at the machine-code + structural level
    (ISA accounting identical to the R32 record: ymm=275 vfmadd=26
    cpuid=3 xgetbv=1; the editor TUs are baseline-ISA; GDI32+USER32
    imported; zero X11 references; single GetPluginFactory export; both
    GUIDs found; moduleinfo byte-identical to the Linux twin), and the
    IDENTICAL model/renderer logic is executed end-to-end on Linux
    (pixel-identity test). Not a DAW compatibility claim.

CONTENTS
--------
  README.txt                            this file
  OCTAVOX_R33_MINIMAL_UI.md             the round report
  linux/PitchLab_Lagrange6_Balanced.vst3/      the Linux x64 bundle
  windows-x64/PitchLab_Lagrange6_Balanced.vst3/ the Windows x64 bundle (+PDB)
  screenshots/r33_editor_default.png    the default surface (real render)
  screenshots/r33_editor_demo.png       a musical preset + live telemetry
  verification_*.txt                    the verification logs
  r33_build_environment.txt             the build environment record
  r33w_machinecode_verification.txt     the Windows machine-code record
