# DELIVERY ROUND 24 (2026-11-08) — R24 SIMD CAPABILITY LAYER + FINAL AUDIT

**Project:** PitchLab Harmonizer (independent, static reverse engineering of
Eventide's Octavox; the original plugin binary is NEVER executed).
**Core:** octavox-native 16.3.0. **Archive:** delta package, 103 files.

## What this round delivered

1. The R24 SIMD capability layer (`include/octavox/simd.hpp`,
   `src/simd_dispatch.cpp`, `src/simd_avx2.cpp`, `src/simd_fma.cpp`):
   one-time CPUID detection (AVX2/FMA independent), the
   `Config::simd` surface (default Scalar = bit-exact vs the R12--R23
   record), RT-safe kernel resolution at prepare() time, loud
   rejection of un-honourable forced modes, and the three kernel
   levels (scalar reference / bit-exact lag-axis AVX2 / bounded FMA
   opt-in). Measured: kernel 4.5--6.2x on the dominant shapes,
   FullRate 96 kHz 8v stereo 1148 -> 368 ms/s (3.12x, bit-exact).
2. Full engine integration (estimate + Hybrid coarse/fine/parabolic)
   and the VST3 module integration (`octavox_core_vst3` compiles the
   SIMD units with per-TU ISA flags; the wrapper surface is
   UNCHANGED -- 38 parameters, frozen v2 state blob).
3. The R24 FINAL AUDIT (8 gates A--H) on the final source: fresh
   clean builds, 111/111 Release + ASan/UBSan, 22/22 VST3 wrapper
   (incl. the Gate B production-config case), 12/12 module
   integration + 47/47 validator on a FRESH bundle, 8/8 hash pins,
   20-run benchmark distributions with full provenance, the 5-document
   decision record set, and this evidence package.

## The audit's honest findings (see VALIDATION §4, WORKLOG §4)

The interrupted session's Gate B test delivery (commit `25b3b05`)
never compiled: an ill-formed using-declaration in the new wrapper
case meant the recorded "wrapper 21/21" predated the case, and its
alloc-gate sub-check miscounted the harness's own buffer. Both were
test-harness-only defects, found and fixed by this audit; the shipped
core sources are unchanged and every gate was re-proven fresh.

## Package contents

| path | content |
|---|---|
| `src/`, `include/`, `tests/`, `cli/`, `bench/`, `CMakeLists.txt`, `r15_reference_hashes.txt` | the native tree (reproducible: cmake configure + build + run per the docs) |
| `vst3/` | the VST3 wrapper (processor, params, factory, tests, module integration harness, CMakeLists) |
| `probe/` | the R24 isolation probes (hybrid estimate probe, kernel timing cross-check, reference objects) |
| `evidence_analysis_round24/logs/` | g0 baseline, g1 stage bench, g2 suites (Release + ASan), g3 stages (scalar + avx2), g4 bench13 (scalar + avx2), g5 kernel bench, g6 final validation, g7 audit distributions + `audit_reruns/` (20 raw repeated-run JSONs) |
| `PITCHLAB_R24_SIMD_BENCHMARK_RESULTS.md` | the measured decision record (+ the final-audit provenance addendum §6) |
| `PITCHLAB_R24_SIMD_IMPLEMENTATION.md` | implementation + propagation chain |
| `PITCHLAB_R24_SIMD_VALIDATION.md` | the verification matrix + the audit corrections |
| `PITCHLAB_R24_SIMD_DECISION_RECORD.md` | the 10 explicit statements |
| `PITCHLAB_R24_WORKLOG.md` | the round chronology |
| `PITCHLAB_ROUND24_FINDINGS.md` | the round findings |
| `checksums.txt` | SHA-256 manifest of every file in this package |

## Reproduction

```
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
./build/octavox_tests            # 111/111
./build/octavox_bench --kernels  # kernel microbench
# VST3 (needs the pinned VST3 SDK 3.7.12_build_20 at VST3_SDK_ROOT):
cmake -S vst3 -B build_vst3 -DCMAKE_BUILD_TYPE=Release \
      -DVST3_SDK_ROOT=/path/to/vst3sdk && cmake --build build_vst3 -j
./build_vst3/bin/Release/octavox_vst3_wrapper_tests        # 22/22
./build_vst3/bin/Release/octavox_module_integration_tests  # 12/12
./build_vst3/bin/Release/validator build_vst3/VST3/Release/PitchLab_Lagrange6_Balanced.vst3  # 47/47
```

## Standing scope statements

No original-plugin execution; no Octavox branding in the product
surface; synthetic corpora only, labelled as such; evidence classes
OBS/DER (no new HYP/UNK). Windows cross-build NOT performed this round
(llvm-mingw toolchain lost to a sandbox reset; MinGW shims authored
but unexecuted) -- no Windows or DAW compatibility claims. The pinned
VST3 SDK is used as-is and NOT redistributed with this package.
