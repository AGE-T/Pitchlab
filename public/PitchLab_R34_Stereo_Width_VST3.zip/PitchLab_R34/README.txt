PitchLab R34 — The Chain-End Stereo Width Stage (energy-preserving), Linux x64 + Windows x64
=============================================================================================

WHAT THIS IS
------------
The R34 round of the PitchLab Harmonizer wrapper: a STEREO IMAGE WIDTH
control at the very end of the DSP chain, collapsible all the way to
mono, WITH the sound's energy maintained (the user-requested feature).
The compensation adapts to the measured L/R correlation:

    k(w, rho) = sqrt( (2 - w^2*(1-rho)) / (1+rho) )

so dual-mono content collapses at EXACT unity, uncorrelated content at
+3 dB (the classic law), and out-of-phase content is honestly clamped at
+6 dB (it cannot survive a mono collapse at any finite gain). At the
default width 1.0 the stage is INERT — the plugin's output is
BIT-IDENTICAL to the pre-R34 build (the r15acc determinism hash is
unchanged).

Full research record (the option space A-F + the decision + the honest
correction note): report/OCTAVOX_R34_STEREO_WIDTH_RESEARCH.md.
Round report (implementation + verification): report/
OCTAVOX_R34_STEREO_WIDTH.md.

THE PARAMETER
-------------
  id 38, "Stereo Width", [0,1] continuous, default 1.0
  (id 0..37 are unchanged; DAW automation of pre-R34 sessions is safe)
  State blobs: v3 (adds the 39th double); v1/v2 sessions restore with
  the width at the bit-neutral default 1.0.
  The R33 minimal editor gained a WIDTH slider (row B, right); the demo
  screenshot shows it at 60%.

CONTENTS
--------
  PitchLab_Lagrange6_Balanced.vst3/   the Linux x64 bundle
  windows-x64/                        the Windows x64 bundle + PDB
  report/                             the round report + the research record
  evidence/                           the verification logs:
      verification_core_suite.txt      126/126 Release (11 new r34 cases)
      verification_core_asan.txt       126/126 ASan/UBSan/LSan, zero reports
      verification_wrapper_tests.txt   22/22 Release + ASan (39-param
                                       surface, state v3 + v2 back-compat)
      verification_ui_tests.txt        11/11 Release + ASan (hit-map 39/39,
                                       the re-pinned golden, X11 pixel
                                       identity)
      verification_module_integration.txt  18/18 Release + ASan/LSan (the
                                       stereo_width_module case: bitwise
                                       mono, +0.013 dB energy, bypass gate)
      verification_validator.txt       47/47 Steinberg validator
      r34w_machinecode_verification.txt   the Windows PE record
      r34_build_environment.txt        toolchains + build dirs + method
  screenshots/                        the REAL renderer output (the same
                                       model/renderer the live view uses)

PROVENANCE
----------
Our own independent harmonizer implementation around the octavox-native
core (own design; see the reports). NOT a reproduction of the original
Eventide Octavox plug-in; no target code; the original binary was never
executed. The VST3 SDK v3.7.12_build_20 (Steinberg dual license) is used
as-is and is NOT redistributed here.

HONEST LIMITS
-------------
Energy is preserved, not peaks (+3 dB RMS can raise sample peaks);
stationary-content exactness (a ~200 ms smoother tracks the image, not
the level); anti-correlated content collapses to the honest zero;
widening beyond the original image is not exposed; macOS not implemented;
the Windows module is machine-code verified (no PE execution in this
sandbox) while the identical stage logic runs end-to-end on Linux. Not a
DAW compatibility claim.
