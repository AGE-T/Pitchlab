# R24 probe sources (research harnesses)

These are the R24 in-round ISOLATION probe harnesses (development-time
debugging tools; NOT part of the shipped build):

* `probe_hybrid.cpp` — the Hybrid fine-stage off-by-one isolation probe
  that pinned the +1-lag parabolic-neighbourhood defect found by the
  test suite during R24 (880 Hz tracked as 864.86 Hz; see
  `../R24/PITCHLAB_R24_WORKLOG.md` phase 2 and the findings doc §2).
* `timing_check.cpp` — the timing sanity harness used while chasing the
  runtime batch-count spill defect.

They are included for research continuity (reproducing the defect
isolation). The prebuilt probe binaries and the R23 reference objects
(`libref.a`, `dsp_ref.o`, ...) from the development tree are deliberately
NOT packaged (stale build artifacts).
