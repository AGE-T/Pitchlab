# PITCHLAB R24 — WORKLOG (SIMD capability layer + final audit)

Round 24 of the PitchLab independent re-implementation (static reverse
engineering of Eventide's Octavox; the original binary is never
executed). Chronological record of the round, including the final
audit. Supporting documents: IMPLEMENTATION / BENCHMARK_RESULTS /
VALIDATION / DECISION_RECORD (this directory).

## Phase 1 — interrupted start (session A, 2026-11-05..06)

* G0 baseline: pristine R23 source, fresh cmake build, 100/100 suite,
  4/4 legacy hash pins recorded (`logs/g0_baseline.txt`).
* G1 stage bench on the R23 baseline; probe harnesses authored
  (`probe/`), `simd.hpp` + `simd_dispatch.cpp` + `simd_avx2.cpp`
  started. Session ran out of context mid-task.

## Phase 2 — completion (session B, 2026-11-06)

* Diagnosed the left-behind state: unwired layer, MISSING
  `simd_fma.cpp` despite being declared, no CMake/engine/test/doc
  integration. Wrote the FMA unit; wired the per-TU ISA flags
  (`-mavx2` / `-mavx2 -mfma`, both `-ffp-contract=off`).
* Full engine integration (estimate + Hybrid coarse/fine/parabolic),
  `Config::simd` with loud prepare() validation, in-place re-prepare.
* In-round defects caught by our own gates and fixed: (1) Hybrid
  fine-stage off-by-one in the parabolic-neighbourhood kernel call
  (y2 = d(best) instead of d(best+1) -> +1-lag bias, 880 Hz tracked as
  864.86 Hz; fixed by spanning 3 taus in one call); (2) runtime batch
  count spilled the vector accumulators (2.1-3.1x -> templated NB ->
  5.0-6.3x); (3) ntau<16 pure-scalar branch (FMA 0.45x); (4) the VST3
  core library compiled dsp.cpp alone (added pitch_control + SIMD
  sources).
* R23 stale-bundle gap closed (OBS): the R23 evidence tree's VST3
  bundle predated the R23 engine deltas; R24 rebuilt from the current
  core and re-ran the chain green on the FRESH bundle.
* Suite 100 -> 110; 110/110 Release + ASan/UBSan; hash pins 8/8;
  wrapper 21/21 + module 12/12 + validator 47/47 (as of THIS source
  state). Kernel/stage/engine measurements recorded; measured decision
  record written. DELIVERED as commit `fb01b3f` (round summary in the
  top-level worklog).

## Phase 3 — final audit interrupted (session C, 2026-11-08, partial)

* The R24 final-audit specification arrived (8 gates A--H). Session C
  began Gate B: added the processor diagnostic seam
  (`configuredSimdMode` / `resolvedSimdLevel` /
  `setSimdModeForTest`), the state-restore non-serialization
  documentation, the in-suite `simd_fallback_override_matrix` case
  (suite 110 -> 111), and the wrapper case 22
  `simd_config_dispatch_r24`. Committed as `25b3b05` -- BUT the
  session ran out of context BEFORE BUILDING ANY OF IT.

## Phase 4 — FINAL AUDIT COMPLETION (session D, 2026-11-08, this audit)

* **Gate A (repo state):** branch `main` @ `25b3b05`; no remote
  configured (local-only evidence tree); working tree clean except the
  embedded `vst3sdk` gitlink (untracked SDK content, by design); no
  stash; all R24 SIMD sources tracked. No destructive operations
  performed.
* **Gate B (production VST3 SIMD config):** traced the full chain in
  source (Config default Scalar -> defaultConfig()/referenceConfig()
  -> setActive -> prepare -> det.configure -> kern_ resolution ->
  indirect calls). FOUND THE REAL DEFECT of session C: the new wrapper
  case contained an ill-formed using-declaration and the suite DID NOT
  COMPILE -- the "21/21" record predated the case. Fixed (namespace
  alias); also fixed the case's alloc-gate harness ordering bug
  (output vector allocated after arming). Wrapper suite now **22/22**
  with the Gate B case passing: production default Scalar; five
  configurations received/resolved/retained; AVX2-level wrapper output
  bit-identical to Scalar; FMA bounded; state restore returns to
  Scalar; accelerated process() 0 allocations.
* **Gate C (runtime dispatch + fallback):** fresh Release build from
  scratch; suite **111/111** (the new fallback matrix: no-AVX2 /
  AVX2-no-FMA / dispatch-caching branches all exercised via the
  controlled override). Fresh ASan/UBSan build: **111/111, zero
  sanitizer reports**. RT-safety re-proven (alloc-free accelerated
  processing at core AND wrapper level).
* **Gate D (benchmark provenance):** recorded the full environment
  (CPU/OS/compiler/CMake/flags/ISA units/method); re-ran every
  benchmark on the FINAL source; added 20 repeated-run distributions
  (5x kernel + 5x2 bench13 + 3x2 stages) with avg/median/p95/p99/max
  (`logs/g7_audit_benchmark_stats.json`, `logs/audit_reruns/`);
  appended the provenance addendum §6 to the benchmark record. All
  figures consistent with the Nov 6 record within shared-vCPU noise
  (headline: FullRate 96k 8v stereo 1148.2 -> 368.3 ms/s, 3.12x).
* **Gate E (final numeric/regression):** hash gates 4/4 legacy +
  4/4 default bit-exact on the final source (fresh r15refcap runs);
  Hybrid off-by-one fix explicitly verified (ASan-clean full suite
  incl. the Hybrid battery; 3-tau spanning call in the final source);
  scalar-default bit-identity vs the R23 record proven by the 8
  in-suite hash gates; optimisation-neutrality gated by the full
  regression groups. Fresh G6 record composed
  (`logs/g6_final_validation.txt`).
* **Gate F (build integrity):** SIMD sources present in ALL CMake
  targets (native `octavox_dsp`, VST3 `octavox_core_vst3` -- x86
  targets, per-TU ISA flags in both). CLEAN VST3 build from scratch
  (deleted + reconfigured + rebuilt): module integration 12/12 on the
  FRESH bundle, validator 47/47, wrapper 22/22. Windows: NOT built
  this round (llvm-mingw lost to the sandbox reset; shims authored but
  unexecuted) -- no Windows or DAW claims.
* **Gate G (documents):** this document set -- BENCHMARK_RESULTS
  (updated with the audit addendum), IMPLEMENTATION, VALIDATION,
  DECISION_RECORD (10 explicit statements), WORKLOG.
* **Gate H (evidence archive):** see the delivery manifest.

## Honest statements

* The "wrapper 21/21" claim of commit `fb01b3f` was true for the
  source state it shipped, but the final-audit case added by
  `25b3b05` never compiled -- recorded here and in VALIDATION §4.
* The core sources are unchanged by the audit (test-harness fixes
  only); all core results carry over bit-exactly -- re-proven by
  fresh runs anyway.
* The Windows cross-build remains open (recorded in DECISION_RECORD
  statement 10 and FINDINGS §5).
