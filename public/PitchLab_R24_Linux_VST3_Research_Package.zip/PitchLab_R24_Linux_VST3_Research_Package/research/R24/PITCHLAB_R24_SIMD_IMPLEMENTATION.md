# PITCHLAB R24 — SIMD CAPABILITY LAYER: IMPLEMENTATION

Round 24 of the PitchLab independent re-implementation (static reverse
engineering of Eventide's Octavox; the original binary is never executed).
This document describes WHAT was implemented, WHERE it lives, and HOW it
is wired into the production VST3 module. Measured evidence lives in
`PITCHLAB_R24_SIMD_BENCHMARK_RESULTS.md`; the verification record lives in
`PITCHLAB_R24_SIMD_VALIDATION.md`; the decisions live in
`PITCHLAB_R24_SIMD_DECISION_RECORD.md`.

## 1. The capability layer (what was added)

| file | role | ISA / flags |
|---|---|---|
| `include/octavox/simd.hpp` | public API: `Mode` / `Level` / `Capabilities`, `detect()`, `resolve()`, `kernels()`, the RT-safety + numerical-semantics contract | header |
| `src/simd_dispatch.cpp` | the baseline TU: scalar reference kernels, one-time CPUID detection (AVX2 and FMA independently), the Mode->Level resolution rules, the kernel tables, the test-only capability override | baseline (x86-64 SSE2) |
| `src/simd_avx2.cpp` | the AVX2 units: `diffLagAxisAVX2` (order-preserving, bit-exact), `diffSampleAxisAVX2` (reassociating, bench only), `peakAVX2` | `-mavx2 -ffp-contract=off` |
| `src/simd_fma.cpp` | the AVX2+FMA units: `diffLagAxisFMA` (order-preserving, fused per-term rounding), `diffSampleAxisFMA` (reassociating, bench only), `peakFMA` | `-mavx2 -mfma -ffp-contract=off` |

The per-TU ISA wiring exists identically in BOTH build systems: the
native `CMakeLists.txt` (`octavox_dsp`, x86 targets only) and the VST3
`vst3/CMakeLists.txt` (`octavox_core_vst3`). The dispatch TU is always
compiled at the baseline ISA, so the library LOADS and RUNS on every
x86-64 processor; the ISA units are entered only through the resolved
kernel table.

## 2. Configuration surface

`Config::simd` (`include/octavox/dsp.hpp`), type `simd::Mode`, default
`Scalar`:

* **Scalar** -- the historical reference implementation, bit-exact
  against every recorded hash of the R12--R23 record.
* **AVX2** -- the lag-axis kernel: bit-identical to Scalar by
  construction (each lane reproduces the reference op sequence: sub,
  mul, sequential add in ascending j).
* **AVX2FMA** -- the lag-axis FMA kernel: order-preserving with FUSED
  per-term rounding (the smallest possible deviation: only the
  per-term rounding differs). Explicit opt-in.
* **Auto** -- resolves to the bit-exact AVX2 level when available, else
  Scalar (the R24 measured decision; never selects FMA).

Engine-internal configuration exactly like `f0_min` / `tracking_gate`:
NOT a host parameter, NOT serialized in the VST3 state blob (a restored
session returns to the Scalar default -- the machine-local property
rule, proven by the wrapper suite's state-restore case).

## 3. The production propagation chain (Gate B of the final audit)

```
VST3 processor ctor / initialize()
    cfg_ = defaultConfig()                    -> Config::simd == Scalar
setActive(true)
    engine_.prepare(cfg_, channels_)          -> MultichannelShifter::prepare
        -> AlignedDelayLine::prepare(cfg)     -> validation + allocation
            -> det.configure(sr, mode, f0_min, cfg.simd)
                kern_ = simd::kernels(simd::resolve(simd_mode))   <- ONCE
process()                                     -> kern_.diff / kern_.peak
                                                (indirect calls only)
```

* `PitchDetector::configure()` resolves the kernel table ONCE, at
  prepare() time -- never inside `process()`. The audio callback
  performs an indirect call through a function pointer stored at
  configuration time (no CPUID, no table resolution, no allocation).
* `prepare()` VALIDATES the mode: an explicitly forced AVX2 / AVX2+FMA
  that the processor or build cannot honour REJECTS the configuration
  (returns false -- loud failure); only Auto degrades silently.
* The in-place re-prepare path (R13-c) re-resolves the table, so a
  `setSimdModeForTest()` / state-restore cycle picks up the new level
  with zero reallocations.
* Observability (no host surface): `OctavoxNativeProcessor::
  configuredSimdMode()` (the configured Mode) and `resolvedSimdLevel()`
  (the engine's resolved Level, channel 0). `setSimdModeForTest(m)` is
  the TEST-ONLY seam (re-prepares exactly like the state-restore path).

## 4. The kernels (numerical semantics summary)

The YIN difference function
`d[tau] = sum_{j=0..m-1} (x[seg0+j] - x[seg0+tau+j])^2`:

| kernel | summation order | per-term rounding | vs Scalar |
|---|---|---|---|
| scalar (reference) | sequential j | mul+add (2 roundings) | -- |
| lag-axis AVX2 | sequential j (per tau) | mul+add (2 roundings) | BIT-IDENTICAL |
| lag-axis AVX2+FMA | sequential j (per tau) | fused (1 rounding), vector lanes; scalar tail keeps mul+add | bounded deviation |
| sample-axis AVX2 | 4-lane reassociated | mul+add | NOT bit-exact (bench only) |
| sample-axis AVX2+FMA | 4-lane reassociated | fused | NOT bit-exact (bench only) |

The window-peak kernel (max |x[i]|) is exact and order-free at every
level. Full semantics table + the RT-safety contract:
`include/octavox/simd.hpp`.

## 5. Engine integration points (all four call sites)

`src/dsp.cpp`, every site routes through the stored table `kern_`:

1. FullRate / Decimated estimate: the window peak (`kern_.peak`) and
   the difference function over the lag domain (`kern_.diff`) --
   one call per estimate.
2. Hybrid fine stage: the neighborhood difference values via ONE
   lag-axis kernel call over `[i0, i1]` (`kern_.diff`), keeping the
   historical tie law (first strictly-smaller wins = lowest lag).
3. Hybrid parabolic refine: the three neighborhood lags (t0, best, t2)
   in ONE kernel call (`tau0 = t0, ntau = 3`); the accumulators are
   independent in the reference too, so the values are bit-identical
   at Scalar/AVX2.
4. The argmin scan / parabolic vertex / gates: scalar control code,
   unchanged.

## 6. In-round fixes retained in the final source

1. **Hybrid off-by-one (window law):** the fine-stage search upper
   bound is clamped ONE below `tau_max_raw_` (`i1 > tau_max_raw_ - 1`),
   because the parabolic refine reads `best+1` with the FULL `m_raw`
   difference support whose last index at `best == tau_max_raw_` is
   exactly `win_raw_` -- one past the end (caught by ASan at 48 kHz).
   Cost: the topmost 1/799th of the lag domain (the [60,1200] Hz gate
   applies afterwards anyway). Verified: the full Hybrid battery +
   ASan suite pass, and the r24 battery's bit-identity matrix includes
   three Hybrid configs.
2. **Kernel micro-architecture** (found by measurement, see the
   benchmark record §2.2): templated batch count (NB in {1,4}) keeps
   the accumulators in ymm registers; small lag domains route through
   the one-batch path; the FMA scalar tail reverted to mul+add.

## 7. What was NOT done (scope exclusions, unchanged)

Phase vocoder, phase locking, transient preservation, LPC, TD-PSOLA,
new GUI, unrelated detector changes -- none. The voice_loop /
interp_reads stages (now the dominant cost at 8 voices) are the
recorded R25 candidate, not an R24 change.
