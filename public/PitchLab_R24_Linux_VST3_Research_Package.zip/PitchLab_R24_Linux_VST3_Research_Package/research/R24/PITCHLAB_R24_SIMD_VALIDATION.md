# PITCHLAB R24 — SIMD CAPABILITY LAYER: VALIDATION RECORD

Round 24 of the PitchLab independent re-implementation (static reverse
engineering of Eventide's Octavox; the original binary is never
executed). This document records EVERY verification executed for the
R24 SIMD capability layer, including the final audit's corrections, and
where each raw record lives. Implementation: see
`PITCHLAB_R24_SIMD_IMPLEMENTATION.md`; decisions:
`PITCHLAB_R24_SIMD_DECISION_RECORD.md`.

## 1. The verification matrix (all on the FINAL audited source)

| gate | evidence | result | raw record |
|---|---|---|---|
| Full suite, Release | 111 cases incl. the 11-case R24 SIMD battery | **111/111** | `logs/g2_tests_release.json` |
| Full suite, ASan+UBSan | same 111 cases | **111/111, zero sanitizer reports** | `logs/g2_tests_asan.json` |
| Hash gates (legacy 15.0.0 pins) | `octavox_r15refcap --legacy`, 4 configs | **4/4 bit-exact** | `logs/g6_final_validation.txt` |
| Hash gates (16.0.0 defaults) | `octavox_r15refcap`, 4 configs | **4/4 bit-exact** | `logs/g6_final_validation.txt` |
| Scalar-default neutrality | in-suite: `default_neutrality` + `default_neutrality_r19` | **8/8 hash matches** | `logs/g2_tests_release.json` |
| VST3 wrapper suite | 22 cases incl. Gate B `simd_config_dispatch_r24` | **22/22** | `logs/g6_final_validation.txt` |
| VST3 module integration (FRESH clean bundle) | 12 cases, real dlopen + factory | **12/12** | `logs/g6_final_validation.txt` |
| VST3 SDK validator | `validator` on the fresh bundle | **47/47** | `logs/g6_final_validation.txt` |
| R23 control battery | 290 checks | **0 failures** | `logs/g6_final_validation.txt` |
| R23 integration check | 5 checks | **0 failures** | `logs/g6_final_validation.txt` |
| Kernel / engine / stage benchmarks | 20 repeated runs | distributions recorded | `logs/g7_audit_benchmark_stats.json`, `logs/audit_reruns/` |

## 2. The R24 SIMD battery (the 11 in-suite cases)

| case | verifies |
|---|---|
| `simd_detect_resolve_rules` | the Mode->Level rules never upgrade past availability; independent AVX2/FMA detection |
| `simd_kernel_avx2_lag_bitexact` | the AVX2 lag kernel == the scalar reference, EXACT equality, multiple shapes incl. tails |
| `simd_kernel_peak_bitexact` | the SIMD peak == the scalar peak exactly |
| `simd_kernel_fma_bounded` | the FMA lag kernel deviation vs Scalar is bounded (documented mixed rounding) |
| `simd_engine_avx2_bitidentity` | full-engine output at the AVX2 level == Scalar, bit-exact, 10 configs (rates x voices x detector modes incl. Hybrid) |
| `simd_engine_fma_closeness` | full-engine FMA deviation bounded; estimate deltas recorded |
| `simd_prepare_mode_validation` | invalid enums rejected; forced AVX2/FMA accepted iff honoured; Auto resolves |
| `simd_default_scalar_neutrality` | the DEFAULT configuration output is bit-exact vs the reference (hash gates) |
| `simd_reprepare_level_switch` | in-place re-prepare switches levels with zero allocations |
| `simd_rt_allocfree_accelerated` | ZERO allocations during an accelerated-level process() (global-new counter armed) |
| `simd_fallback_override_matrix` | the Gate C controlled-override battery (final-audit addition; see §4) |

## 3. The Gate B VST3 wrapper case (`simd_config_dispatch_r24`)

(a) a freshly instantiated processor carries `simd == Scalar` and
resolves the Scalar kernels (the audited production answer: **the
production VST3 plugin is Scalar by default**); a full
terminate()->initialize() cycle returns to the same default.
(b) the five configurations through the TEST seam: default, explicit
Scalar, explicit AVX2, Auto, FMA opt-in -- each RECEIVED
(`configuredSimdMode()`), RESOLVED (`resolvedSimdLevel()`), and
RETAINED across blocks, a real processing lifecycle and a
suspend/resume cycle.
(c) the AVX2-level wrapper run is BIT-IDENTICAL to the Scalar-level
run; the FMA opt-in deviates only within the documented bound.
(d) state save/restore does NOT carry the SIMD mode (the 'OVR1' v2
blob has no simd field): a restored instance returns to Scalar.
(e) an accelerated-level process() performs ZERO allocations through
the full wrapper path.

## 4. FINAL-AUDIT CORRECTIONS (the honest record)

The final audit found that the interrupted session's case-22 delivery
(commit 25b3b05) had NEVER BUILT:

1. **Ill-formed using-declaration** -- `using octavox::simd;` inside
   `caseSimdDispatchR24` (a using-declaration may not name a
   namespace). The wrapper suite did not compile with the Gate B case
   present; the recorded "21/21" predated the case. Fixed with a
   function-local namespace alias. The suite now compiles and passes
   22/22 with the case INCLUDED.
2. **Alloc-gate harness ordering bug** -- the case's RT-safety
   sub-check constructed its output vector AFTER arming the global-new
   counter, counting the harness's own 16 KiB allocation (the observed
   "1 allocation" failure). The buffer is now allocated BEFORE arming
   (the core-suite pattern); the process() path itself was
   allocation-free all along (proven independently by
   `no_alloc_steady_state` and `simd_rt_allocfree_accelerated`).

Both fixes are TEST-HARNESS-ONLY: the shipped core sources
(`dsp.cpp`, `simd_*.cpp`, `pitch_control.cpp`) are UNCHANGED from
commit 25b3b05 -- every core-suite result (111/111 Release + ASan) and
every hash pin carries over bit-exactly. The audit's fresh runs
(timestamps in the raw records) re-proved everything end-to-end.

## 5. The Gate C dispatch/fallback battery

`simd_fallback_override_matrix` uses the controlled TEST-ONLY capability
override (`simd::setTestCapabilities`) -- NOT physical
hardware removal -- to exercise the dispatch rules for machines this
host cannot provide, WITHOUT ever executing an unsupported instruction
(the override only changes WHICH kernels the resolver hands out, and
under a feature-less report it hands out only the scalar kernels):

* **(a) synthetic no-AVX2/no-FMA machine:** Auto -> Scalar; forced
  AVX2 / AVX2+FMA REJECTED at prepare() (loud failure); the Auto
  kernel table is the scalar one; honourable modes still prepare;
  invalid enums still rejected.
* **(b) synthetic AVX2-without-FMA machine** (run only when the REAL
  machine has AVX2, so executing the AVX2 kernels is genuinely safe):
  Auto -> AVX2; forced AVX2 honoured; forced FMA rejected -- AVX2 and
  FMA are evaluated INDEPENDENTLY.
* **(c) dispatch caching:** an engine prepared under a no-AVX2
  override STAYS Scalar after the override is cleared and the engine
  processes audio (the audio callback never re-queries CPUID); a
  subsequent prepare() re-resolves Auto to the accelerated level.

An RAII guard restores the real hardware report on every path (no
override leaks into other cases, including the --reverse suite order).

## 6. Hybrid off-by-one fix (explicit verification)

The window-law clamp `i1 > tau_max_raw_ - 1` (see the implementation
document §6.1) is verified by: (i) the full ASan/UBSan suite --
111/111 including the three Hybrid-accuracy battery cases and the
Hybrid-vs-FullRate delta cases -- with ZERO out-of-bounds reports (the
original defect WAS an ASan window overrun at 48 kHz); (ii) the r24
battery's engine bit-identity matrix includes three Hybrid configs
(hyb_44k_l6, hyb_48k_ok6, hyb_96k_l6) + the gated variant, all
bit-exact at the AVX2 level vs the Scalar level.

## 7. Optimisation-neutrality proof (nothing silently changed)

The R24 optimisation did NOT change any observable DSP decision:
lag selection (same argmin tie law), CMNDF values (bit-exact at
Scalar/AVX2), pitch estimates, voiced/unvoiced decisions, period
history, engine spacing -- all gated by: the 8 hash-gate matches
(legacy + default), the 10-config engine bit-identity matrix, the R13
stability/stereo/rates groups, the R19/R22 regression groups, and the
R23 control battery + integration check re-run in this audit.

## 8. Evidence classes

OBS: every measurement above (raw JSON/txt records). DER: bit-exactness
of the AVX2 lag kernel (by construction, proven by exact-equality
gates). HYP: none new. UNK: none new.
