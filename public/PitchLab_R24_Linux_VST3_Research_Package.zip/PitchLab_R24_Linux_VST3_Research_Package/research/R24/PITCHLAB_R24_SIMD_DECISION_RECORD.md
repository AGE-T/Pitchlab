# PITCHLAB R24 — SIMD DECISION RECORD (the 10 explicit statements)

Round 24 of the PitchLab independent re-implementation (static reverse
engineering of Eventide's Octavox; the original binary is never
executed). Each statement below is a DELIBERATE, MEASURED decision with
its evidence pointer. Evidence classes: OBS (observed measurement),
DER (derived / proven by construction + hard gate), HYP (hypothesis),
UNK (unknown). This round introduced no HYP and no UNK items.

---

**1. The production default is Scalar (statement of record).**
The shipped VST3 plugin builds its engine configuration through
`defaultConfig()` -> `referenceConfig()`, which leaves `Config::simd`
at the Config default `simd::Mode::Scalar`. The default production
plugin NEVER executes an ISA-extended instruction and its output is
bit-exact against the R12--R23 hash record (8 hash-gate matches,
re-proven in this audit). The default was NOT changed to make the
benchmark numbers look better.
Evidence: DER (`simd_config_dispatch_r24` case (a);
`logs/g2_tests_release.json` `default_neutrality*`).

**2. Auto resolves to AVX2, never to AVX2+FMA (statement of record).**
The measured kernel record shows the AVX2 lag kernel >= the FMA lag
kernel on EVERY representative shape on the reference machine (equal
on the throughput-bound big domains, 1.8x faster on the latency-bound
single-batch shapes), while FMA additionally deviates from the
reference rounding. Auto therefore selects the BIT-EXACT accelerated
level. AVX2+FMA remains an explicit opt-in for per-host
experimentation.
Evidence: OBS (`logs/g5_kernel_bench.json`, `logs/audit_reruns/`,
`PITCHLAB_R24_SIMD_BENCHMARK_RESULTS.md` §4).

**3. The production accelerated kernel is the LAG-AXIS AVX2
implementation (statement of record).**
It is bit-identical to the scalar reference BY CONSTRUCTION (each
256-bit lane reproduces the exact reference op sequence: sub, mul,
sequential add in ascending j) and is the fastest bit-exact option on
every dominant shape (measured 4.5--6.2x). The reassociating
sample-axis variant is FASTER only on small shapes and is REJECTED as
a production kernel (not bit-exact; the gain does not buy the loss).
Evidence: DER + OBS (`simd_kernel_avx2_lag_bitexact`;
`simd_engine_avx2_bitidentity` -- 10 configs).

**4. AVX2+FMA is an opt-in with a documented bounded deviation
(statement of record).**
The FMA level fuses the per-term rounding (order preserved; scalar
tail keeps the reference mul+add). Its full-engine deviation is gated
as bounded (`simd_engine_fma_closeness`, wrapper-level bound 1e-4);
it is NEVER claimed bit-exact and NEVER selected by Auto or by the
default.
Evidence: DER (`simd_kernel_fma_bounded`; wrapper case (c) FMA
sub-check, `fma_vs_scalar_maxdiff` recorded per run).

**5. A forced mode the machine or build cannot honour is REJECTED
loudly at prepare() (statement of record).**
`prepare()` returns false for an explicit AVX2 / AVX2+FMA request that
`simd::resolve()` cannot honour; only Auto degrades silently (it ASKS
for "best available"). An unsupported processor therefore never
receives an ISA unit through the kernel table -- verified with the
controlled test-only capability override (no physical
hardware-removal claims).
Evidence: DER (`simd_prepare_mode_validation`;
`simd_fallback_override_matrix` (a)/(b); `prepare()` validation block
in `src/dsp.cpp`).

**6. Dispatch is resolved at prepare() time; the audio callback
performs indirect calls only (statement of record).**
`kern_` is resolved ONCE in `PitchDetector::configure()` (called from
`prepare()`); `process()` uses the stored function pointers -- no
CPUID, no table resolution, no allocation, no locks in the callback.
ZERO allocations during accelerated process() are hard-gated at BOTH
the core level and the full VST3 wrapper level.
Evidence: DER (`simd_rt_allocfree_accelerated`;
`simd_config_dispatch_r24` (e) `avx2_process_allocations = 0`;
`no_alloc_steady_state`).

**7. The scalar fallback is unconditional and independent per feature
(statement of record).**
AVX2 and FMA are detected INDEPENDENTLY (CPUID; GCC/Clang
`__builtin_cpu_supports` which also verifies OSXSAVE/YMM state). A
machine without AVX2 runs Scalar at every mode; a machine with AVX2
but without FMA honours AVX2 and rejects the FMA opt-in. A CPU never
executes an ISA-extended instruction it does not report.
Evidence: DER (`simd_fallback_override_matrix` (a)/(b)/(c);
`simd_detect_resolve_rules`).

**8. The SIMD mode is engine-internal: no host parameter, no state
serialization (statement of record).**
The 38-parameter host surface is UNCHANGED; the 'OVR1' v2 state blob
is the FROZEN layout (no simd field) -- a session saved on an AVX2
machine restores runnable on a scalar-only machine and returns to the
Scalar default. Observability is through internal diagnostics
(`configuredSimdMode()` / `resolvedSimdLevel()`) and the TEST seam
(`setSimdModeForTest`) only.
Evidence: DER (`simd_config_dispatch_r24` (d); the unchanged parameter
metadata table; `octavox_params.cpp` state layout).

**9. The optimisation changed NO observable DSP decision (statement
of record).**
Lag selection (same argmin tie law), CMNDF values, pitch estimates,
voiced/unvoiced decisions, period history and engine spacing are
unchanged at the default: proven by the 8 hash-gate matches, the
10-config engine bit-identity matrix (incl. Hybrid), and the full
R13/R15/R19/R22/R23 regression groups re-run in this audit.
Evidence: DER (`logs/g2_tests_release.json` + `g2_tests_asan.json`,
111/111 each; `g6_final_validation.txt`).

**10. No Windows build or DAW verification is claimed for R24
(statement of record).**
The Windows cross-toolchain (llvm-mingw) was lost to a sandbox reset;
the MinGW compatibility shims are authored but UNEXECUTED this round.
All R24 execution evidence is Linux x86-64. The R21 Windows delivery
(pre-R24, without the SIMD layer) is not present in the current tree.
No Windows compatibility claim is made.
Evidence: OBS (`octavox-work/win-zig/` toolchain scripts present,
`/home/z/tools/llvm-mingw` empty; no Windows build directory).

---

Supporting pointers: implementation
(`PITCHLAB_R24_SIMD_IMPLEMENTATION.md`), measured evidence
(`PITCHLAB_R24_SIMD_BENCHMARK_RESULTS.md` incl. the final-audit
provenance addendum §6), verification record
(`PITCHLAB_R24_SIMD_VALIDATION.md` incl. the final-audit corrections
§4), chronology (`PITCHLAB_R24_WORKLOG.md`).
