# MATHEMATICAL AND IMPLEMENTATION REFERENCES — access information

This directory contains OUR OWN research documents (the PitchLab project's
independent work product, written during rounds 23–24). External
copyrighted research material is NOT redistributed in this package —
references and access information are provided below instead.

## Included documents (our own work; no third-party copyright)

| file | content |
|---|---|
| `PITCHLAB_R23_YIN_MATHEMATICAL_DERIVATION.md` | the YIN CMNDF/parabolic-interpolation derivation as implemented in our engine |
| `PITCHLAB_R23_YIN_IMPLEMENTATION_SPEC.md` | the implementation contract of the detector stages |
| `PITCHLAB_R23_YIN_SOURCE_COMPARISON.md` | the comparison of our implementation against the published YIN description (independent re-derivation, no source code copied) |
| `PITCHLAB_R23_YIN_RESEARCH.md` | the research overview and terminology |
| `PITCHLAB_R23_YIN_VARIANT_TAXONOMY.md` | the taxonomy of detector variants (Decimated / Hybrid / FullRate) |
| `PITCHLAB_R23_YIN_WINDOW_LAG_LATENCY_STUDY.md` | the window/lag/latency analysis |
| `PITCHLAB_R23_YIN_CONFIDENCE_VOICING_STUDY.md` | confidence and voicing-decision study |
| `PITCHLAB_R23_YIN_STEP6_REALTIME_STUDY.md` | step-6 (best-local-estimate) realtime considerations |
| `PITCHLAB_R23_DECIMATION_FILTER_STUDY.md` | the decimation-stage filter study |

## External references (NOT included; access pointers)

1. **The YIN algorithm** — de Cheveigné, A., Kawahara, H.: *YIN, a
   fundamental frequency estimator for speech and music*, JASA 111(4),
   2002, pp. 1917–1930. DOI: 10.1121/1.1458024.
   Access: https://doi.org/10.1121/1.1458024 (publisher: Acoustical
   Society of America; subscription/pay-per-article). A widely mirrored
   author copy exists at http://auditoryneuroscience.com/pitch/auditory-neurosciencecom/yin (as of the research rounds) — verify against the DOI record.
   License: copyrighted academic publication; NOT redistributable with
   this package.

2. **Steinberg VST3 SDK v3.7.12_build_20** — the plugin ABI our wrapper
   targets. Dual license (GPLv3 OR the proprietary Steinberg VST3
   license). NOT redistributed in this package; acquire via
   `source/tools/get_vst3_sdk.sh` (pinned-SHA acquisition + verification).
   Pinned component SHAs (tag `v3.7.12_build_20`):
   | component | repository | pinned SHA |
   |---|---|---|
   | main | steinbergmedia/vst3sdk | `cc2adc90382dded9e347caf74e4532f1458715db` |
   | base | steinbergmedia/vst3_base | `f0998e7b8424b32ba275cf4218aa56beef29821c` |
   | cmake | steinbergmedia/vst3_cmake | `2022b265cdbcd90b37294d3fb397f9766dbe4c06` |
   | pluginterfaces | steinbergmedia/vst3_pluginterfaces | `151ecde4d6ee1c457dcce848342b162461944fe6` |
   | public.sdk | steinbergmedia/vst3_public_sdk | `3fce096d6ee575479753f1aab23033d2e2ffdc6e` |
   Access: https://github.com/steinbergmedia/vst3sdk (tag v3.7.12_build_20).
   License: https://github.com/steinbergmedia/vst3sdk/blob/main/LICENSE.txt
   (dual license; anyone rebuilding the plugins must accept one of the two
   options).

3. **Eventide Octavox / Ox.vst3** — the ORIGINAL third-party plugin that
   this project reverse-engineers STATICALLY (documentation/observation
   only; the original binary was never executed in our research; no
   original code is contained in this package). Product page:
   https://www.eventide.com (Octavox harmonizer plugin). The original
   binary and its contents are Eventide Audio's copyrighted IP and are
   NOT part of this package in any form.

## Provenance / license of THIS package's own material

* All documents in this directory and all source under `source/` are the
  PitchLab project's independent work product (static reverse-engineering
  research), created without executing or copying any third-party plugin
  code.
* Commit of record for the delivered source: `757f242`
  (`757f242d5906b51b90fc0c79649cdcfc21b048e5`, branch `main`).
