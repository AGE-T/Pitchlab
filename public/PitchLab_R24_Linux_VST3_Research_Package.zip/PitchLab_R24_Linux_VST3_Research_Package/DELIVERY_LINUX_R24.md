# DELIVERY REPORT — PitchLab R24 Linux VST3 Build & Research Package

**Date:** 2026-11-08 · **Source commit:** `757f242`
(`757f242d5906b51b90fc0c79649cdcfc21b048e5`, branch `main`, the expected
final R24 state — verified before building; working tree clean except the
external `vst3sdk` gitlink content (permission-bit noise only, pinned
HEAD `cc2adc9` = v3.7.12_build_20 verified) and one unrelated untracked
file outside the source tree).
**Nature of this delivery:** a fresh NATIVE LINUX build of every VST3
plugin target defined by the project, plus the complete R24 research and
verification material, packaged for independent verification. No previous
build artifact was treated as a Linux result; every binary and every
validation record in this package was produced fresh for this delivery.

---

## 1. Status taxonomy (the four statuses, kept separate)

| status | applies to |
|---|---|
| **Successfully built** | all 9 VST3 plugin variants (native Linux x86-64 Release builds from source) |
| **Successfully validated (SDK-level)** | all 9: Steinberg validator **47/47** each; compiled-module integration harness **12/12** each (real `dlopen` + factory + bit-exact processing); wrapper suite **22/22** for 8 variants, **21/22** for `PitchLab_Lagrange6Q` (see §7); dual-module null test PASS |
| **Successfully loaded in a host** | SDK module loader: YES (per the integration harness — a real load of every bundle). **DAW: NOT TESTED** — no Linux audio host exists in the build environment (checked: ardour, carla, reaper, bitwig, qtractor, lmms, vsthost, renoise, JACK — none installed; recorded in `evidence/vst3_validation/HOST_AVAILABILITY.txt`) |
| **Not tested** | DAW compatibility (any specific host); Windows; macOS; GUI (none exists by design) |

## 2. Linux build result

Fresh Release builds, from the final R24 source, in clean build
directories, on:

* OS: Debian GNU/Linux 13 (trixie), kernel 5.10.134 x86_64
* CPU: Intel Xeon, 2 cores, AVX2 + FMA (+ AVX-512, unused by the code)
* Compiler: GCC 14.2.0 (Debian 14.2.0-19)
* CMake 4.4.4, Unix Makefiles generator
* VST3 SDK v3.7.12_build_20 (pinned SHAs, verified)

**BUILD RESULT: SUCCESS — all 9 variants, zero build errors.**
Compiler warnings in first-party code: benign only (`-Wclass-memaccess`
on SDK `ProcessData` memset in the test harness, `-Wmissing-field-initializers`
on aggregate init, one unused-parameter in a test; no warnings in the
DSP/SIMD/wrapper production sources).

## 3. Generated VST3 modules (all nine)

| module bundle | binary | size | SHA-256 (first 16) |
|---|---|---|---|
| PitchLab_Lagrange6_Balanced.vst3 | Contents/x86_64-linux/PitchLab_Lagrange6_Balanced.so | 417,072 B | `cd8f8185d47ecdfd` |
| PitchLab_Lagrange6_Hybrid.vst3 | …/PitchLab_Lagrange6_Hybrid.so | 417,072 B | `eb3bdcff9116ac59` |
| PitchLab_ObsKernel6_Balanced.vst3 | …/PitchLab_ObsKernel6_Balanced.so | 417,072 B | `ab0e92e2fdcf0db5` |
| PitchLab_Lagrange6Q.vst3 | …/PitchLab_Lagrange6Q.so | 417,072 B | `d364acbd295d95ef` |
| PitchLab_Lagrange6Q_Hybrid.vst3 | …/PitchLab_Lagrange6Q_Hybrid.so | 417,072 B | `35c113a4fdb033c1` |
| PitchLab_ObsKernel6_Hybrid.vst3 | …/PitchLab_ObsKernel6_Hybrid.so | 417,072 B | `e1ec7d47eff633d9` |
| PitchLab_Lagrange6_FullRate.vst3 | …/PitchLab_Lagrange6_FullRate.so | 417,072 B | `f9edd0a1eeca738a` |
| PitchLab_Lagrange6Q_FullRate.vst3 | …/PitchLab_Lagrange6Q_FullRate.so | 417,072 B | `5095d1fa18535323` |
| PitchLab_ObsKernel6_FullRate.vst3 | …/PitchLab_ObsKernel6_FullRate.so | 417,072 B | `0ff8ea32567be8f3` |

(Full 64-hex digests: `SHA256SUMS` + each variant's `binary_inspection.txt`.)

## 4. Binary architecture verification (every module)

* `file`: **`ELF 64-bit LSB shared object, x86-64, version 1 (SYSV),
  dynamically linked`** — native Linux x86_64, no Windows/PE, no
  cross-compiled artifact.
* Dynamic dependencies: `libstdc++.so.6`, `libm.so.6`, `libgcc_s.so.1`,
  `libc.so.6`, `linux-vdso.so.1`, `ld-linux-x86-64.so.2` — all resolve.
* `ldd -r` (full relocation + symbol resolution): **zero unresolved
  symbols**.
* VST3 bundle structure: `Contents/x86_64-linux/<name>.so` +
  `Contents/Resources/moduleinfo.json` (SDK-generated; identity fields
  verified per variant — CID, name, vendor `PitchLab Project`, category
  `Audio Module Class`, subcategories `Fx`, `Pitch Shift`, SDKVersion
  `VST 3.7.12`).
* **ISA containment (the "no mandatory AVX2 in baseline TUs" proof):**
  per-object disassembly of `liboctavox_core_vst3.a`: ymm instructions
  present ONLY in `simd_avx2.cpp.o` (70) and `simd_fma.cpp.o` (45);
  **zero** in `dsp.cpp.o`, `simd_dispatch.cpp.o`, `pitch_control.cpp.o`.
  Whole-module: 115 ymm total, **0 zmm (no AVX-512)**, 11 FMA
  instructions (the FMA unit, dispatched only after CPUID clears it).
* **Per-TU ISA flags (from the generated + executed build rules):**
  `simd_avx2.cpp` → `-mavx2 -ffp-contract=off` (no FMA); `simd_fma.cpp`
  → `-mavx2 -mfma -ffp-contract=off`; baseline TUs → no `-m` flags at
  all. The plugin was NOT globally compiled with `-mavx2`/`-mfma`; the
  library loads and runs on every x86-64 processor.

## 5. VST3 validation results (fresh, per bundle)

| gate | result |
|---|---|
| Steinberg VST3 SDK validator | **47 tests passed, 0 failed × 9 bundles** (also run automatically inside each module build) |
| In-process wrapper suite (22 cases) | **22/22 × 8 bundles**; **21/22** for `PitchLab_Lagrange6Q` (§7) |
| Compiled-module integration harness (12 cases, real dlopen + factory + bit-exact audio) | **12/12 × 9 bundles** |
| Dual-module null test (two bundles loaded simultaneously) | **PASS** (unity bit-identical; ±shift cases differ as required; same-symbol-name coexistence OK) |
| Wrapper-level SIMD dispatch case (`simd_config_dispatch_r24`) | ok in all 9 builds (production default Scalar; five modes received/resolved/retained; AVX2 wrapper output bit-identical; accelerated process() = 0 allocations; state restore returns to Scalar) |
| Linux audio host / DAW | **NOT AVAILABLE** in this environment — not tested, not claimed (`HOST_AVAILABILITY.txt`) |

Core-level gates re-proven fresh on the same source (see §6 for
environment): suite **111/111 Release** and **111/111 ASan+UBSan with
zero sanitizer reports**; hash gates **8/8 bit-exact** (4 legacy 15.0.0
pins + 4 default 16.0.0 pins, via `octavox_r15refcap --legacy` and
default runs compared against the recorded pin files).

## 6. Runtime SIMD dispatch results (this Linux machine)

* CPU: Intel Xeon (2 cores) reporting **AVX2 = yes, FMA = yes** (CPUID;
  also recorded by the kernel bench JSON `cpu` block: avx2 true, fma true).
* Mode → resolved level (Level: 0 = Scalar, 1 = AVX2, 2 = AVX2+FMA):
  * **Scalar → 0** — the production default of every shipped plugin
    (`production_default_mode = 0` in all nine wrapper dispatch cases).
  * **AVX2 → 1** — forced AVX2 honoured; wrapper output bit-identical to
    Scalar (`avx2_vs_scalar_bitidentical = 1`).
  * **AVX2+FMA → 2** — opt-in only; on this corpus wrapper output
    `fma_vs_scalar_maxdiff = 0` (kernel-level bound 4.4e-16 relative,
    gated).
  * **Auto → 1 (AVX2)** on this AVX2+FMA-capable CPU — the expected
    implementation IS selected under Auto (`auto_resolved_level = 1`;
    engine-level cross-check: the Auto bench timing profile equals the
    AVX2 profile on all 13 cases).
* Fallback safety (controlled-override matrix, NOT hardware removal):
  synthetic no-AVX2 machine → Auto resolves Scalar, forced AVX2/FMA
  REJECTED at `prepare()`; synthetic AVX2-without-FMA → Auto resolves
  AVX2, forced FMA rejected (features evaluated independently); an
  engine prepared under an override keeps its resolved table while
  processing (dispatch cached at prepare; no CPUID in the callback).
* RT safety: **0 allocations** during accelerated `process()` at both
  the core and wrapper level (hard-gated).
* **Decision preserved:** production default Scalar; Auto → AVX2; FMA
  opt-in. **No production default was modified for this delivery.**
  Fresh Linux benchmarks (best-of-3, 5 s/case): kernel AVX2 lag 5.66×;
  engine 13-case speedups vs Scalar — 1v ≈ 2.7–3.4×, 8v ≈ 1.6–1.9×,
  consistent with the R24 reference-machine record (shared-vCPU
  absolute-time variance noted; relative speedups consistent).

## 7. Known limitations and findings (complete, honest list)

1. **`PitchLab_Lagrange6Q` wrapper suite 21/22** — the failing case is
   `identity_variant_authority_r21`, sub-check: "display name must name
   the detector variant ('Balanced' = Decimated)". The auxiliary
   Lagrange6Q+Decimated variant deliberately keeps its HISTORICAL short
   display name ("PitchLab Harmonizer Lagrange6Q", per
   `octavox_build_config.h`'s own naming table), which contains neither
   "Decimated" nor "Balanced", so the R21-era identity check fails.
   Classification: a **test expectation gap for the auxiliary variant's
   historical name** (authored when only the three recommended variants
   were exercised), NOT a Linux-specific defect, NOT a DSP/SIMD defect,
   and NOT a plugin malfunction — the bundle passes the SDK validator
   (47/47) and the compiled-module integration harness (12/12, including
   bit-exact audio processing), and all DSP/bit-exactness/dispatch cases
   pass. Per the task's scope rules (no source changes without a
   concrete Linux-specific defect; the delivered source must remain the
   validated R24 state at commit `757f242`), the source was NOT modified;
   the finding is recorded here and in the validation matrix. The other
   Lagrange6Q variants (Hybrid/FullRate) carry detector-suffixed names
   and pass 22/22.
2. **No DAW validation** — no Linux audio host is installed in this
   environment; SDK-level validation only. No DAW compatibility is
   claimed for any bundle.
3. **No GUI/editor** — by design (minimal processor/controller wrapper;
   hosts automate the 38 parameters).
4. **Windows and macOS: not built** — this package is Linux x86_64 only.
   The Windows cross-build remains the documented open item from R24
   (statement 10 of the R24 decision record).
5. **VST3 SDK not included** — Steinberg dual license; the pinned-SHA
   acquisition script + reference table are included instead
   (`source/tools/get_vst3_sdk.sh`,
   `research/mathematical_references/REFERENCES.md`). Network access is
   required to fetch it once for rebuilding.
6. **FullRate variants are offline/benchmark-only** (≈97% of one core at
   96 kHz) — included for completeness because they are buildable
   targets, not recommended for real-time use.
7. Benchmark absolute times on this shared-vCPU machine vary run-to-run;
   relative speedups are consistent with the R24 reference record. The
   20-run distribution methodology and raw data live in
   `evidence/R24_audit/logs/` (reference machine) and
   `evidence/benchmarks/` (this machine, fresh).

## 8. Git provenance

* Delivered source = commit **`757f242`**
  (`757f242d5906b51b90fc0c79649cdcfc21b048e5`), branch `main` — the
  expected final R24 commit; verified as HEAD before any build. No
  commits were made, no branches created, no destructive Git operations
  performed during this delivery. The source in `source/` is a faithful
  copy of that tree (verified by the reproducibility rebuild, §9).
* The `source/` tree's own file-integrity anchor: the per-file SHA-256
  record captured during the R24 audit
  (`evidence/R24_audit/logs/g0_baseline_source_sha256.txt`) plus this
  package's `SHA256SUMS`.

## 9. Reproducibility (verified end-to-end)

`build_configuration/rebuild_linux_r24.sh` reproduces the ENTIRE chain
from the extracted source (native Release + ASan legs, all 9 plugin
variants, every gate). After creating the ZIP, it was verified by:

1. extracting into a clean directory,
2. checking every `SHA256SUMS` entry,
3. rebuilding from the EXTRACTED source (a full fresh VST3 variant build
   + the native Release gate chain, using the documented commands),
4. confirming the rebuilt plugin binary is byte-identical to the
   packaged one (deterministic compilation),
5. confirming the research documents open and every referenced evidence
   file exists.

The reproducibility log is archived in
`evidence/linux_build/reproducibility_check.txt`.

## 10. Package integrity

* `SHA256SUMS` covers every file in the package (generated last, after
  all content was final).
* The ZIP: `PitchLab_R24_Linux_VST3_Research_Package.zip` — size and
  SHA-256 are stated in the final report accompanying this package (and
  in the delivery page's sidecar `.sha256` file).

---

**Verdict:** all mandatory Linux build + validation stages for this
delivery completed successfully, with two explicitly-reported
non-success areas — (i) DAW-level testing: NOT TESTED (no host
available), (ii) one auxiliary variant's wrapper identity-string case:
21/22 (test-expectation gap, documented above; plugin fully functional
and SDK-validated). The R24 SIMD algorithms, decisions and production
defaults are unchanged; every gate that the R24 final audit established
was re-proven fresh on this Linux machine.
