# PitchLab R24 — Linux VST3 Research Package

**PitchLab Harmonizer** — an independent, static reverse-engineering
re-implementation of Eventide's Octavox harmonizer plugin (the original
binary was never executed; no original code is contained here) — round 24
(the SIMD capability layer), delivered as **native Linux x86_64 VST3
plugin builds plus the complete R24 research and verification material**.

| | |
|---|---|
| Source commit of record | `757f242` (`757f242d5906b51b90fc0c79649cdcfc21b048e5`, branch `main`) |
| Target platform | Linux x86_64 (ELF `x86-64`, System V ABI) |
| Build type | Release (`-O2` core / `-O3 -DNDEBUG` module via CMake defaults) |
| Compiler | GCC 14.2.0 (Debian 14.2.0-19) |
| CMake | 4.4.4 |
| Build host | Intel Xeon (2 cores, AVX2+FMA), Debian 13 (trixie), kernel 5.10.134 |
| VST3 SDK | v3.7.12_build_20 (pinned SHAs; **not** redistributed — see below) |

Full details of what was built, validated and NOT tested:
**`DELIVERY_LINUX_R24.md`** (the delivery report).

---

## 1. What this package contains

```text
PitchLab_R24_Linux_VST3_Research_Package/
|
+-- plugins/                     9 built VST3 bundles (see §2)
+-- source/                      the COMPLETE final native source tree
|   |                            (as at commit 757f242; no build dirs)
|   +-- src/                     DSP core + the three SIMD units
|   +-- include/octavox/         public headers (dsp.hpp, simd.hpp, ...)
|   +-- vst3/                    the VST3 wrapper (module, tests, factory)
|   +-- tests/                   the 111-case suite harness
|   +-- bench/                   the benchmark harness
|   +-- cli/                     research CLI tools (R15..R23)
|   +-- tools/                   SDK acquisition + build+test scripts
|   +-- CMakeLists.txt           the native build (per-TU ISA wiring)
|   +-- ARCHITECTURE.md          engine architecture documentation
|   +-- README.md / VST3_READINESS.md
|   +-- r15/r18/r19_reference_hashes.txt   the bit-exactness hash pins
+-- research/
|   +-- R23/                     the 16 R23 (YIN round) research documents
|   +-- R24/                     the 5 R24 documents + round-24 findings
|   +-- mathematical_references/ YIN math/implementation studies (our own)
|   |                            + REFERENCES.md (external access pointers,
|   |                              licenses; copyrighted material NOT copied)
|   +-- probe_sources/           the R24 probe harness sources
+-- evidence/
|   +-- linux_build/             fresh build logs + environment record
|   +-- vst3_validation/         per-variant validation (see §3) + matrix
|   +-- regression/              111/111 Release + 8 hash gates (fresh)
|   +-- sanitizers/              111/111 ASan/UBSan, zero reports (fresh)
|   +-- benchmarks/              fresh Linux benchmarks (4 SIMD levels + kernels)
|   +-- simd_dispatch/           the runtime dispatch evidence record
|   +-- R24_audit/               the R24 final-audit raw logs (G0..G7,
|                                incl. the 20-run distributions)
+-- build_configuration/
|   +-- rebuild_linux_r24.sh     the EXACT reproduction script (all gates)
|   +-- CMakeCache_native_release.txt / CMakeCache_vst3_*.txt
|   +-- environment.txt
+-- README.md                    (this file)
+-- DELIVERY_LINUX_R24.md        the delivery report (statuses, limits)
+-- SHA256SUMS                   the SHA-256 manifest of every file
```

## 2. The built plugins (`plugins/`)

Nine bundles — every buildable (interpolation × detector) variant of the
single VST3 plugin target defined by the project. Each bundle is the
proper VST3 layout:

```text
<name>.vst3/
+-- Contents/x86_64-linux/<name>.so      native ELF x86-64 shared object
+-- Contents/Resources/moduleinfo.json   SDK-generated module metadata
```

| bundle | variant | role |
|---|---|---|
| `PitchLab_Lagrange6_Balanced.vst3` | Lagrange6 + Decimated | **recommended production build** (R16–R20 lineage identity) |
| `PitchLab_Lagrange6_Hybrid.vst3` | Lagrange6 + Hybrid | **recommended production build** |
| `PitchLab_ObsKernel6_Balanced.vst3` | ObsKernel6 + Decimated | **recommended production build** |
| `PitchLab_Lagrange6Q.vst3` | Lagrange6Q + Decimated | auxiliary kernel variant (see known limitations) |
| `PitchLab_Lagrange6Q_Hybrid.vst3` | Lagrange6Q + Hybrid | auxiliary |
| `PitchLab_ObsKernel6_Hybrid.vst3` | ObsKernel6 + Hybrid | auxiliary |
| `PitchLab_Lagrange6_FullRate.vst3` | Lagrange6 + FullRate | **offline/benchmark only** (≈97% CPU at 96 kHz — never the recommended real-time mode) |
| `PitchLab_Lagrange6Q_FullRate.vst3` | Lagrange6Q + FullRate | offline/benchmark only |
| `PitchLab_ObsKernel6_FullRate.vst3` | ObsKernel6 + FullRate | offline/benchmark only |

Each module is 417,072 bytes; per-file SHA-256 values are in `SHA256SUMS`
and in each variant's `evidence/vst3_validation/<bundle>/binary_inspection.txt`.

All nine are native Linux binaries: `ELF 64-bit LSB shared object, x86-64`,
dynamically linked only against `libstdc++.so.6`, `libm.so.6`,
`libgcc_s.so.1`, `libc.so.6` (all resolved; no Windows-specific
dependencies; `ldd -r` reports zero unresolved symbols — see
`binary_inspection.txt` per variant).

## 3. What was verified on these exact binaries (fresh runs)

Per variant (full logs under `evidence/vst3_validation/<bundle>/`):

* **Steinberg VST3 SDK conformance validator: 47/47 tests passed** (run
  twice: automatically inside the module build, and explicitly after).
* **In-process wrapper suite** (drives the actual VST3 classes through
  their COM interfaces): **22/22** for eight variants; **21/22** for
  `PitchLab_Lagrange6Q` (one identity-string expectation case — a
  documented naming-consistency check, NOT a DSP defect; the plugin
  passes the validator and all integration tests; details in
  `DELIVERY_LINUX_R24.md` §7).
* **Compiled-module integration harness: 12/12** — loads each bundle via
  the SDK's `VST3::Hosting::Module` (a real `dlopen()` +
  `GetPluginFactory()`), drives the factory instances through the full
  host interface contract with bit-exact audio comparisons vs the
  hand-driven core.
* **Binary inspection**: ELF class/machine/ABI, dynamic dependencies,
  symbol resolution, exported factory symbols, SHA-256.
* **Per-TU ISA verification** (from the generated + executed build
  rules): `simd_avx2.cpp` compiled with exactly `-mavx2 -ffp-contract=off`
  (no FMA), `simd_fma.cpp` with `-mavx2 -mfma -ffp-contract=off`, and
  `dsp.cpp` / `simd_dispatch.cpp` / `pitch_control.cpp` at baseline ISA
  (no `-m` flags). Instruction-level containment audit: ymm instructions
  ONLY in the two SIMD objects (70 + 45); zero ymm in the baseline
  objects; zero zmm (AVX-512) anywhere in the module.
* **Dual-module null test** (`Lagrange6_Balanced` +
  `ObsKernel6_Balanced` simultaneously loaded): PASS — unity
  bit-identical, non-unity differs (different kernels genuinely engaged),
  two same-symbol-name modules coexist in one process.

Core-level (fresh builds of the same source):

* **111/111** test cases, Release — including the 11-case R24 SIMD
  battery (kernel bit-exactness, engine bit-identity, fallback matrix).
* **111/111** under ASan+UBSan, zero sanitizer reports.
* **8/8 hash gates** bit-exact: 4 legacy 15.0.0 pins + 4 default 16.0.0
  pins (the R12–R23 bit-identity record).
* Fresh Linux benchmarks at Scalar / AVX2 / Auto / FMA levels + the
  kernel microbenchmark (AVX2 lag kernel 5.66× on this machine).

## 4. SIMD implementations and the runtime dispatch

The R24 SIMD capability layer provides the YIN difference/peak kernels at
three levels, compiled as separate translation units with isolated ISA
flags (see §3). Runtime CPUID detection (AVX2 / FMA independently) picks
the level ONCE at `prepare()` time; the audio callback performs indirect
calls only (no CPUID, no allocation, no locks — hard-gated by tests).

* **Scalar** — the production DEFAULT of every shipped plugin
  (`Config::simd == Scalar`; bit-exact vs the R12–R23 hash record).
* **AVX2** — bit-identical to Scalar by construction (the measured
  production accelerated kernel; 4.5–6.3× on the reference machine).
* **AVX2+FMA** — explicit opt-in only, bounded deviation (≤ 4.4e-16
  relative at kernel level); never selected by Auto or the default.
* **Auto** — resolves to the bit-exact AVX2 level when the CPU reports
  AVX2 (proven on this AVX2+FMA machine: `auto_resolved_level = 1`),
  else Scalar. A forced level the machine cannot honour is REJECTED
  loudly at `prepare()`; unsupported combinations fall back safely (the
  controlled-override fallback matrix test).

The mode is engine-internal: no host parameter, not serialized in the
VST3 state blob (a restored session returns to Scalar).

**Decision status (unchanged by this delivery):** production default
Scalar; Auto→AVX2; FMA opt-in. No production default was modified.

## 5. Installation

Copy the chosen `.vst3` bundle directory into the host's VST3 plugin
path, e.g.:

```sh
mkdir -p ~/.vst3
cp -a plugins/PitchLab_Lagrange6_Balanced.vst3 ~/.vst3/
```

Common Linux VST3 paths: `~/.vst3` (user), `/usr/lib/vst3` (system).
Recommended for real-time use: the three production variants
(`*_Balanced`, `*_Hybrid` — see §2). The `*_FullRate` bundles exist for
offline/benchmark comparisons only.

Runtime dependencies (already present on any normal x86-64 Linux with a
C++ runtime): `libstdc++.so.6`, `libm.so.6`, `libgcc_s.so.1`, `libc.so.6`.

## 6. Verifying a plugin yourself

```sh
# 1) the module exists and is a native Linux x86-64 ELF object
file plugins/PitchLab_Lagrange6_Balanced.vst3/Contents/x86_64-linux/*.so

# 2) dependencies resolve
ldd -r plugins/PitchLab_Lagrange6_Balanced.vst3/Contents/x86_64-linux/*.so

# 3) the package is intact
sha256sum -c SHA256SUMS
```

For full validation (validator + wrapper suite + integration harness +
the whole core gate chain), rebuild from source with the reproduction
script — §7.

## 7. Reproducing the build

Requirements: Linux x86_64, GCC ≥ 13 (verified 14.2.0), CMake ≥ 3.19
(verified 4.4.4), binutils/file/python3, and the **Steinberg VST3 SDK
v3.7.12_build_20** — which is NOT in this package (its dual license does
not permit unconditional redistribution with this evidence package).
Acquire it pinned-and-verified:

```sh
./source/tools/get_vst3_sdk.sh        # fetches + verifies the pinned SHAs
# or: git clone https://github.com/steinbergmedia/vst3sdk  (tag v3.7.12_build_20)
```

Then reproduce the ENTIRE delivery chain (native Release + ASan legs +
all nine plugin variants + every validation gate):

```sh
./build_configuration/rebuild_linux_r24.sh --sdk-root <path-to-vst3sdk>
```

Exit code 0 iff every gate passes (the exact gates that produced this
package's evidence, re-run from the extracted source). The minimal
single-variant plugin build:

```sh
cmake -S source/vst3 -B build -DCMAKE_BUILD_TYPE=Release \
      -DVST3_SDK_ROOT=<path-to-vst3sdk>
cmake --build build -j
# -> build/VST3/Release/PitchLab_Lagrange6_Balanced.vst3
```

(The native core without the SDK: `cmake -S source -B build
-DCMAKE_BUILD_TYPE=Release && cmake --build build -j`.)

## 8. Known limitations (honest)

* **No GUI/editor** — the wrapper is a minimal processor/controller;
  hosts automate the 38 parameters. No graphical interface is claimed.
* **No DAW validation** — no Linux audio host exists in the build
  environment. SDK-level validation only (validator 47/47 + module
  integration 12/12 + dual-load null test). See
  `evidence/vst3_validation/HOST_AVAILABILITY.txt`.
* **`PitchLab_Lagrange6Q` wrapper suite 21/22** — one identity-string
  expectation case (`identity_variant_authority_r21`) does not accept the
  auxiliary variant's historical short display name (which omits the
  detector suffix). Not a DSP or plugin defect: the bundle passes the
  SDK validator (47/47) and module integration (12/12), and all DSP,
  bit-exactness and dispatch cases pass. Full analysis in
  `DELIVERY_LINUX_R24.md` §7.
* **No Windows/macOS builds** in this package — Linux x86_64 only
  (Windows remains a separate, documented open item from R24).
* **The VST3 SDK is not included** — pinned acquisition script +
  reference table included instead (`tools/get_vst3_sdk.sh`,
  `research/mathematical_references/REFERENCES.md`).
* FullRate detector variants are offline/benchmark-only (≈97% CPU at
  96 kHz) — installed at the user's discretion.
* The original Eventide Octavox plugin is NOT part of this package in
  any form; this project is an independent static re-implementation.

## 9. Where everything is (quick index)

| want | look at |
|---|---|
| delivery statuses + final numbers | `DELIVERY_LINUX_R24.md` |
| per-variant validation raw logs | `evidence/vst3_validation/<bundle>/` |
| fresh core test/sanitizer/bench records | `evidence/regression/`, `evidence/sanitizers/`, `evidence/benchmarks/` |
| R24 final-audit raw logs (G0..G7) | `evidence/R24_audit/logs/` |
| runtime dispatch evidence | `evidence/simd_dispatch/runtime_dispatch_linux.txt` |
| R24 decisions (10 statements) | `research/R24/PITCHLAB_R24_SIMD_DECISION_RECORD.md` |
| engine architecture | `source/ARCHITECTURE.md` |
| reproduction | `build_configuration/rebuild_linux_r24.sh` |
| file integrity | `SHA256SUMS` |
