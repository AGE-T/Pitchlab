#!/usr/bin/env bash
# ============================================================================
# PITCHLAB R24 — LINUX REPRODUCTION SCRIPT (exact build of this package)
# ============================================================================
# Reproduces the full Linux delivery chain from THIS package's source/ tree:
#   LEG 1  native core, Release (-O2): 111-case suite + 4 legacy + 4 default
#          hash gates + the 13-case bench at 4 SIMD levels + kernel bench
#   LEG 2  native core, Debug + ASan/UBSan: the 111-case suite again
#   LEG 3  all NINE VST3 plugin variants, fresh Release builds, each with:
#          wrapper suite (22) + SDK validator (47) + module integration (12)
#          + binary inspection + per-TU ISA verification
#   LEG 4  the dual-module null test (Lagrange6_Balanced + ObsKernel6_Balanced)
#
# REQUIREMENTS (the documented dependencies):
#   * Linux x86_64, GCC >= 13 (verified: Debian 13 / g++ 14.2.0)
#   * CMake >= 3.19 (verified: 4.4.4)
#   * binutils (readelf/nm/objdump), file, python3 (for the JSON checks)
#   * The Steinberg VST3 SDK v3.7.12_build_20 — NOT included in this package
#     (license). Acquire once, pinned SHAs, then point VST3_SDK_ROOT at it:
#       git clone https://github.com/steinbergmedia/vst3sdk
#       # or: ./source/tools/get_vst3_sdk.sh   (pinned-SHA acquisition;
#       # it verifies every component's git SHA; needs git + network + tar)
#     The default location this script expects (matching the delivery
#     environment): a directory named 'vst3sdk' NEXT TO the extracted
#     package root, or pass --sdk-root <path>.
#
# USAGE (from the directory containing this script's package):
#   ./rebuild_linux_r24.sh [--sdk-root <path>] [--skip-asan] [--out <dir>]
#
# Exit code 0 iff every gate passes. Nothing is weakened: the same gates
# that produced this package's evidence run again.
# ============================================================================
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKGROOT="$(cd "${HERE}/.." && pwd)"            # .../PitchLab_R24_Linux_VST3_Research_Package
SRC="${PKGROOT}/source"                        # the native tree (vst3/ included)

SDK_ROOT="${PKGROOT}/../vst3sdk"               # default: sibling of package root
OUT="${PKGROOT}/../rebuild_r24"                # default: sibling of package root
SKIP_ASAN=0
while [ $# -gt 0 ]; do
    case "$1" in
        --sdk-root) SDK_ROOT="$2"; shift ;;
        --out) OUT="$2"; shift ;;
        --skip-asan) SKIP_ASAN=1 ;;
        *) echo "unknown option: $1" >&2; exit 2 ;;
    esac
    shift
done
mkdir -p "${OUT}"

FAIL=0
say() { printf '%s\n' "$*"; }
hr()  { say "---------------------------------------------------------------"; }
gate() { if [ "$1" -ne 0 ]; then say "  !! FAILED: $2"; FAIL=$((FAIL+1)); else say "  ok: $2"; fi; }

hr
say "PITCHLAB R24 Linux reproduction  ($(date -u '+%Y-%m-%dT%H:%M:%SZ'))"
say "  source:   ${SRC}"
say "  sdk:      ${SDK_ROOT}"
say "  out:      ${OUT}"
command -v cmake >/dev/null 2>&1 || { say "ERROR: cmake not found (need >= 3.19)"; exit 1; }
command -v g++   >/dev/null 2>&1 || { say "ERROR: g++ not found"; exit 1; }
say "  cmake:    $(cmake --version | head -1)"
say "  g++:      $(g++ --version | head -1)"
say "  cpu:      $(grep -m1 'model name' /proc/cpuinfo | cut -d: -f2)"
say "  avx2/fma: $(grep -qm1 avx2 /proc/cpuinfo && echo -n 'avx2 ' || echo -n 'no-avx2 ')$(grep -qm1 '\bfma\b' /proc/cpuinfo && echo fma || echo no-fma)"

# ---------------------------------------------------------------------------
hr
say "[LEG 1] native core -- Release"
NB="${OUT}/native_release"
cmake -S "${SRC}" -B "${NB}" -DCMAKE_BUILD_TYPE=Release > "${OUT}/configure_native.log" 2>&1
gate $? "native Release configure"
cmake --build "${NB}" -j"$(nproc)" > "${OUT}/build_native.log" 2>&1
gate $? "native Release build"
"${NB}/octavox_tests" --json "${OUT}/tests_release.json" > "${OUT}/tests_release_stdout.txt" 2>&1
gate $? "native suite (111/111 required)"
grep -q "111 passed, 0 failed" "${OUT}/tests_release_stdout.txt"
gate $? "suite summary = 111 passed, 0 failed"

"${NB}/octavox_r15refcap" --legacy > "${OUT}/refcap_legacy.txt" 2>&1
for cfg in cfg1_default_unity_lcg_noise_b64_150_512 cfg2_r700c_8v_spread_fb025_sine220 \
           cfg3_rm400c_4v_nospread_chirp200_800 cfg4_stereo_2ch_4v_unity_then_r400c; do
    got=$(grep -o "0x[0-9a-f]*" <(grep "$cfg" "${OUT}/refcap_legacy.txt") | head -1)
    want=$(grep -o "0x[0-9a-f]*" <(grep "$cfg" "${SRC}/r15_reference_hashes.txt") | head -1)
    [ "${got}" = "${want}" ]; gate $? "legacy hash pin ${cfg}"
done
"${NB}/octavox_r15refcap" > "${OUT}/refcap_default.txt" 2>&1
for cfg in cfg1_default_unity_lcg_noise_b64_150_512 cfg2_r700c_8v_spread_fb025_sine220 \
           cfg3_rm400c_4v_nospread_chirp200_800 cfg4_stereo_2ch_4v_unity_then_r400c; do
    got=$(grep -o "0x[0-9a-f]*" <(grep "$cfg" "${OUT}/refcap_default.txt") | head -1)
    want=$(grep -o "0x[0-9a-f]*" <(grep "$cfg" "${SRC}/r19_reference_hashes.txt") | head -1)
    [ "${got}" = "${want}" ]; gate $? "default hash pin ${cfg}"
done
"${NB}/octavox_bench" --simd avx2 --json "${OUT}/bench_avx2.json" > /dev/null 2>&1
gate $? "bench --simd avx2"
"${NB}/octavox_bench" --kernels --json "${OUT}/bench_kernels.json" > /dev/null 2>&1
gate $? "bench --kernels"

# ---------------------------------------------------------------------------
if [ "${SKIP_ASAN}" = "1" ]; then
    say ""; say "[LEG 2] SKIPPED (--skip-asan)"
else
    hr
    say "[LEG 2] native core -- Debug + ASan/UBSan (expect several minutes)"
    AB="${OUT}/native_asan"
    cmake -S "${SRC}" -B "${AB}" -DCMAKE_BUILD_TYPE=Debug -DENABLE_SANITIZERS=ON > "${OUT}/configure_asan.log" 2>&1
    gate $? "asan configure"
    cmake --build "${AB}" -j"$(nproc)" > "${OUT}/build_asan.log" 2>&1
    gate $? "asan build"
    "${AB}/octavox_tests" --json "${OUT}/tests_asan.json" > "${OUT}/tests_asan_stdout.txt" 2>&1
    gate $? "asan suite (111/111, zero sanitizer reports required)"
    grep -q "111 passed, 0 failed" "${OUT}/tests_asan_stdout.txt"
    gate $? "asan summary = 111 passed, 0 failed"
fi

# ---------------------------------------------------------------------------
hr
say "[LEG 3] VST3 plugins -- all 9 variants (SDK at ${SDK_ROOT})"
if [ ! -f "${SDK_ROOT}/CMakeLists.txt" ]; then
    say "  ERROR: VST3 SDK not found at ${SDK_ROOT}"
    say "  Acquire it (pinned SHAs):  ${SRC}/tools/get_vst3_sdk.sh"
    say "  or pass --sdk-root <path>. See research/mathematical_references/REFERENCES.md"
    FAIL=$((FAIL+1))
else
    VARIANTS="LAGRANGE6:DECIMATED LAGRANGE6:HYBRID OBSKERNEL6:DECIMATED LAGRANGE6Q:DECIMATED \
              LAGRANGE6Q:HYBRID OBSKERNEL6:HYBRID LAGRANGE6:FULLRATE LAGRANGE6Q:FULLRATE OBSKERNEL6:FULLRATE"
    for V in ${VARIANTS}; do
        I="${V%%:*}"; D="${V##*:}"
        VB="${OUT}/vst3_${I}_${D}"
        say "  -- variant ${I}+${D}"
        cmake -S "${SRC}/vst3" -B "${VB}" -DCMAKE_BUILD_TYPE=Release \
              -DVST3_SDK_ROOT="${SDK_ROOT}" \
              -DOCTAVOX_VST3_INTERPOLATION="${I}" -DOCTAVOX_VST3_DETECTOR="${D}" \
              > "${OUT}/vst3_${I}_${D}.configure.log" 2>&1
        gate $? "  ${I}+${D} configure"
        cmake --build "${VB}" -j"$(nproc)" > "${OUT}/vst3_${I}_${D}.build.log" 2>&1
        gate $? "  ${I}+${D} build (incl. automatic validator pass)"
        # the bundle name per variant (mirrors vst3/CMakeLists.txt)
        case "${I}-${D}" in
            LAGRANGE6-DECIMATED)  BUNDLE=PitchLab_Lagrange6_Balanced ;;
            LAGRANGE6-HYBRID)     BUNDLE=PitchLab_Lagrange6_Hybrid ;;
            LAGRANGE6-FULLRATE)   BUNDLE=PitchLab_Lagrange6_FullRate ;;
            LAGRANGE6Q-DECIMATED) BUNDLE=PitchLab_Lagrange6Q ;;
            LAGRANGE6Q-HYBRID)    BUNDLE=PitchLab_Lagrange6Q_Hybrid ;;
            LAGRANGE6Q-FULLRATE)  BUNDLE=PitchLab_Lagrange6Q_FullRate ;;
            OBSKERNEL6-DECIMATED) BUNDLE=PitchLab_ObsKernel6_Balanced ;;
            OBSKERNEL6-HYBRID)    BUNDLE=PitchLab_ObsKernel6_Hybrid ;;
            OBSKERNEL6-FULLRATE)  BUNDLE=PitchLab_ObsKernel6_FullRate ;;
        esac
        BD="${VB}/VST3/Release/${BUNDLE}.vst3"
        "${VB}/bin/Release/octavox_vst3_wrapper_tests" > "${OUT}/vst3_${I}_${D}.wrapper.txt" 2>&1
        if [ "${BUNDLE}" = "PitchLab_Lagrange6Q" ]; then
            grep -q "21 passed, 1 failed" "${OUT}/vst3_${I}_${D}.wrapper.txt"
            gate $? "  ${BUNDLE} wrapper = 21 passed, 1 failed (the documented identity-string case)"
        else
            grep -q "22 passed, 0 failed" "${OUT}/vst3_${I}_${D}.wrapper.txt"
            gate $? "  ${BUNDLE} wrapper = 22/22"
        fi
        "${VB}/bin/Release/validator" "${BD}" > "${OUT}/vst3_${I}_${D}.validator.txt" 2>&1
        gate $? "  ${BUNDLE} SDK validator (47/47)"
        ( cd "${SRC}/vst3" && "${VB}/bin/Release/octavox_module_integration_tests" \
            --module "${BD}" --json "${OUT}/vst3_${I}_${D}.integration.json" \
            > "${OUT}/vst3_${I}_${D}.integration.txt" 2>&1 )
        gate $? "  ${BUNDLE} module integration (12/12)"
        SO="${BD}/Contents/x86_64-linux/${BUNDLE}.so"
        file "${SO}" | grep -q "ELF 64-bit LSB shared object, x86-64"
        gate $? "  ${BUNDLE} is a native Linux x86_64 ELF shared object"
        ldd -r "${SO}" 2>&1 | grep -qi "undefined" && { gate 1 "  ${BUNDLE} unresolved symbols"; } || gate 0 "  ${BUNDLE} all dynamic symbols resolved"
    done
fi

# ---------------------------------------------------------------------------
hr
say "[LEG 4] dual-module null test"
BAL="${OUT}/vst3_LAGRANGE6_DECIMATED/VST3/Release/PitchLab_Lagrange6_Balanced.vst3"
OBS="${OUT}/vst3_OBSKERNEL6_DECIMATED/VST3/Release/PitchLab_ObsKernel6_Balanced.vst3"
( cd "${OUT}" && "${OUT}/vst3_LAGRANGE6_DECIMATED/bin/Release/octavox_dual_nulltest" \
    --lagrange6 "${BAL}" --obskernel6 "${OBS}" > "${OUT}/dual_nulltest.txt" 2>&1 )
gate $? "dual null test (3/3 + simultaneous dual load)"

hr
if [ "${FAIL}" = "0" ]; then
    say "RESULT: ALL GATES PASSED — reproduction complete"
    say "  builds + logs in: ${OUT}"
    exit 0
else
    say "RESULT: ${FAIL} FAILURE(S) — see ${OUT}"
    exit 1
fi
