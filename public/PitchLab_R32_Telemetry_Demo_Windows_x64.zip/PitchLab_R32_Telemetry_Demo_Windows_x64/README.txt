PitchLab R32 — Telemetry Demo VST3, Windows x64
================================================

WHAT THIS IS
------------
The R31 telemetry & latency-truth demo (built from the R26-R30 static
audit findings) ported to Windows x64. PitchLab Harmonizer "Balanced"
variant: Lagrange6 interpolation, decimated YIN detector, the 38-parameter
automation surface, the frozen v2 state blob, and:

  * IPitchTelemetry (vendor interface, IID D1A60F31-8C4B-4E39-9A67-
    31D1-8E4F5A21) served by the processor's queryInterface:
      id 7  = cents from C4 (1200/ln2 * ln(f0/261.6256); -65535 sentinel)
      id 8  = the voice's gliding frequency ratio
      id 9  = Q23-quantised n/(n+8)
      id 10 = sqrt(frac*(1-2^-23)) on the grain phase
      id 11 = labelled confidence (periodicity x control-state weight)
      id 12/13 = gated -/+ cents correction twins
  * per-voice block-rate polling with atomic dirty-bit fanout
    (bit = voice*8 + (id-7); 56 live bits; consumeDirtyBits() = the
    host-side read-and-clear)
  * latency-truth notification: restartComponent(kLatencyChanged)
    exactly when the reported value changes
  * the R24 SIMD capability layer: per-TU AVX2 / AVX2+FMA kernel units
    with runtime CPUID+XGETBV detection (Auto = bit-exact AVX2, FMA is
    an explicit opt-in; scalar fallback on older CPUs)

INSTALL
-------
Copy PitchLab_Lagrange6_Balanced.vst3 to your VST3 plug-ins folder:
  per-user : C:\Users\<you>\AppData\Local\Programs\Common\VST3\
  for all  : C:\Program Files\Common Files\VST3\
The .pdb beside the binary is debug symbols (optional to keep; useful
for crash stack resolution).

HOST / TOOL AUTHORS
------------------
Query IPitchTelemetry from the processor via queryInterface (it is
served before any other vendor interface; the standard Steinberg
interfaces are unaffected). The telemetry is a PULL interface: call
per-voice reads after processing; use consumeDirtyBits() to learn which
(voice, id) pairs changed since your last read. See
OCTAVOX_R31_TELEMETRY_DEMO.md in the R31 package for the full spec.

TOOLCHAIN HONESTY NOTE
----------------------
Cross-built on Linux with Zig 0.13.0 (clang/LLVM 18 frontend, lld,
mingw-w64 headers, static libc++): genuine PE32+ x64 modules with the
Microsoft x64 ABI importing only Windows system DLLs. This is the same
recorded toolchain deviation behind the accepted R21/R22/R24-W Windows
deliveries of this project. Native MSVC rebuild instructions are in the
R24-W package (build_configuration/README_WINDOWS_BUILD.md); the sources
are MSVC-ready.

The verification method (no Windows execution possible in the build
sandbox): identical sources + defines verified end-to-end on the Linux
twin (core 115/115 Release + ASan, wrapper 21/21, module integration
16/16 incl. the four telemetry cases, Steinberg validator 47/47), plus
machine-code and structural verification of the Windows module itself
(ISA instruction accounting, kernel byte presence, imports, export,
FUID/IID GUIDs, moduleinfo parity). See the verification_*.txt and
r32w_*.txt logs in this package.

FILES
-----
  PitchLab_Lagrange6_Balanced.vst3\  the plugin bundle (x86_64-win)
  OCTAVOX_R32_WINDOWS_BUILD.md       the round report
  verification_core_suite.txt        Linux twin: 115/115 Release
  verification_asan.txt              Linux twin: 115/115 ASan/UBSan
  verification_wrapper_tests.txt     Linux twin: 21/21 wrapper tests
  verification_module_integration.txt Linux twin: 16/16 module tests
  verification_validator.txt         Linux twin: validator 47/47
  r32w_cpuid_check.txt               explicit-vs-builtin detection AGREE
  r32w_machinecode_verification.txt  the Windows module machine-code record
  r32w_build_environment.txt         toolchain + method record
