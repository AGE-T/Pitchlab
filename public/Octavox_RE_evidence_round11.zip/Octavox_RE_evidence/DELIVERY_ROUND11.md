# Round-11 delivery note

This ZIP (`Octavox_RE_evidence_round11.zip`) is the round-11 edition of the Octavox
reverse-engineering evidence package. It supersedes
`Octavox_RE_evidence_round10.zip` (SHA-256
`e7f9067ababaa033493b7a08730ffbc279ca2aa5295b246831daab6bf2237d9a`) and is a complete,
self-verifiable snapshot: nothing else is required except the target binary.

Round 11 = **numerical consistency audit of round 10** (Phase A) + **independent validation of
the WAV→WAV DSP demo and its highest-value improvement** (Phase B). See
`docs/OCTAVOX_ROUND11_FINDINGS.md` for the narrative and the full correction changelog.

## Contents (255 files + `checksums.txt`)

| path | role |
|---|---|
| `README.md` | package front door — updated for round 11 (new round-11 section + reproduction commands) |
| `docs/OCTAVOX_ROUND11_FINDINGS.md` | **new** — the audit (all six round-10 claims reproduced; max-error location and residual-direction labels corrected; the one-`P`-ulp excess qualification), the demo validation (byte-identical reproduction; stereo defect found and fixed in v2), the acceptance suite and the improvement |
| `docs/OCTAVOX_ROUND10_FINDINGS.md` | **updated** — corrected §1/§2.2/§3.3/§4/§7 wording + new §8 round-11 correction changelog |
| `docs/` (canonical docs) | `OCTAVOX_ROUND9_FINDINGS.md` (audit note in the correction box + slew-range qualification), `OCTAVOX_DSP_ARCHITECTURE.md`, `OCTAVOX_CONTROL_FLOW_MATRIX.md`, `OCTAVOX_RESEARCH_EVIDENCE_MATRIX.md` (R-59–R-61 + round-11 correction log), `OCTAVOX_OPEN_QUESTIONS.md`, `OCTAVOX_DSP_DEMO_USAGE.md` (stereo-defect correction + v2 documentation + suite command) updated; every other doc unchanged from round 10 |
| `poc/octavox_v2.py` | **new** — the round-11 v2 demo module: `delayline_aligned` (period-aligned grain splicing) + stereo-safe per-channel engines + v2 CLI |
| `poc/example_output_aligned.wav` + `poc/example_aligned.json` | **new** — deterministic regression artifact of the improvement (+4 st, 3 voices, v2 CLI) |
| `evidence/analysis_round11/` | **new** — `r11_numeric_audit.py` + `_results.txt` + `_results.json` (independent numerical audit; exit-code gated); `r11_acceptance_tests.py` + `_results.txt` + `_results.json` (45/45 gated cases); `r11_dsp_improvement.md` (design + trade-offs + before/after) |
| `evidence/analysis_round10/` | `r10_verify.py` **corrected** (two output labels; docstring changelog) + `r10_verify_results.txt` **regenerated** (identical numbers, corrected labels only) + `r10_verify_results_v1_superseded.txt` **new** (the original round-10 output, preserved verbatim with a superseded banner); the other 13 round-10 artifacts unchanged |
| `evidence/` (records, decompiles, tools), `poc/` (reference files) | unchanged since round 10 — the reference demo files are deliberately untouched (baseline preservation); its five shipped WAV artifacts still reproduce byte-identically |
| `OCTAVOX_AGENT_HANDOVER_REPORT.md` | the round-8 environment acceptance report (status **GO**) — unchanged |
| `checksums.txt` | **regenerated** for this edition (CRLF sha256sum manifest, case-insensitive path order) |

## Manifest

Compared with the round-10 manifest: **232 files byte-identical**, **10 files updated** by
round 11 (`README.md`, the seven canonical docs `docs/OCTAVOX_ROUND10_FINDINGS.md`,
`docs/OCTAVOX_ROUND9_FINDINGS.md`, `docs/OCTAVOX_DSP_ARCHITECTURE.md`,
`docs/OCTAVOX_CONTROL_FLOW_MATRIX.md`, `docs/OCTAVOX_RESEARCH_EVIDENCE_MATRIX.md`,
`docs/OCTAVOX_OPEN_QUESTIONS.md`, `docs/OCTAVOX_DSP_DEMO_USAGE.md`, plus the corrected
`evidence/analysis_round10/r10_verify.py` and its regenerated output
`r10_verify_results.txt` — identical numbers, corrected labels only), **13 files new**
(`DELIVERY_ROUND11.md`, `docs/OCTAVOX_ROUND11_FINDINGS.md`, `poc/octavox_v2.py`,
`poc/example_output_aligned.wav`, `poc/example_aligned.json`, the seven
`evidence/analysis_round11/` artifacts, and
`evidence/analysis_round10/r10_verify_results_v1_superseded.txt`), and **1 removed** (the
superseded `DELIVERY_ROUND10.md`, replaced by this note). The round-10 manifest is preserved
inside `Octavox_RE_evidence_round10.zip`.

## Verification

```sh
unzip Octavox_RE_evidence_round11.zip
cd Octavox_RE_evidence
sha256sum -c checksums.txt        # 255/255 OK expected

# re-run the round-11 gates (Python 3.11+, numpy):
python3 evidence/analysis_round11/r11_numeric_audit.py        # exit 0; 14 checks PASS
python3 evidence/analysis_round11/r11_acceptance_tests.py     # exit 0; 45/45 cases PASS (~2.5 min)
```

The SHA-256 of the ZIP itself is published alongside it (sidecar file
`Octavox_RE_evidence_round11.zip.sha256`).

## Delivery report (round 11)

**Test commands** (Python 3.11+, `numpy`; from the package root after extraction):

| command | result on the delivery machine (2026-10-24) |
|---|---|
| `sha256sum -c checksums.txt` | **255/255 OK** (independent re-extraction) |
| `python3 evidence/analysis_round11/r11_numeric_audit.py` | **exit 0 — 14/14 gate checks PASS** (the one non-gate item, `excess_universally_bit_exact`, is reported as INFO = the documented 11-of-201 one-ulp exceptions) |
| `python3 evidence/analysis_round11/r11_acceptance_tests.py` | **exit 0 — 45/45 cases PASS** (~2.5 min: io 1/1, reference 28/28, v2 12/12, cli 4/4) |
| `python3 poc/octavox_offline.py --make-example /tmp/e.wav` + the four example runs | all five shipped WAV artifacts **byte-identical** (SHA-256 e.g. input `30596b4c…`) |
| `python3 poc/octavox_offline.py --compare` | metrics reproduce to ≤ 1e-10 relative (cost rows machine-dependent) |

**Remaining unknowns** (unchanged policy; see `docs/OCTAVOX_ROUND11_FINDINGS.md` §6): every
runtime question about the target — walk statistics, the audible character of the one-sided
(upward-from-base) modulation, correction convergence, whether the `m02` 12/13 gate ever opens,
the host-reported latency value (Q-8), the unity-ratio comb audibility (Q-14) — stays **UNK**;
the original target was never executed and no PoC result is substituted for a target
measurement. The five controlled Windows-host tests that would close them are listed in the
findings §6. For our demo: the vocoder pre-echo (14–29 ms onset delay) and the
short-input-vocoder silence edge remain open engineering directions; the aligned design's
unison comb is a documented limitation.

**The delivered archive:** `Octavox_RE_evidence_round11.zip` (256 entries = 255 files +
`checksums.txt`). The exact SHA-256 digest is published **alongside the archive** in the sidecar
file `Octavox_RE_evidence_round11.zip.sha256` (self-referential digests cannot live inside the
archive itself); the same digest is quoted in the web delivery report for this round.

## Not included (by design)

* **The target binary `Ox.vst3`** (5 307 392 bytes, SHA-256
  `7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2`) — transfer it from the
  round-8 handover channel; it is byte-identical to the image every record in this package was
  produced from. It was never modified and never executed. **Round-11 note:** the binary was
  not present in the round-11 environment either; all numerical inputs are the OBS bit patterns
  recorded in `evidence/records/rea8_rate_constants.txt` and
  `evidence/analysis_round10/r10_decode.txt`, both verified byte-exact against the image in
  rounds 8–10, and the recorded digests are unchanged.
* Environment/acceptance scripts — environment-specific; the acceptance report documents the
  environment and the tool versions (REA 6.7.0, Ghidra 12.1.4).

## Provenance

* Built 2026-10-24 from the working tree `/home/z/octavox/work/Octavox_RE_evidence/` after round 11
  (numerical audit + demo validation + improvement).
* Originals preserved read-only throughout and re-verified at delivery time: the round-10 ZIP
  `e7f9067a…` (intact on arrival this round); the target digest `7bb260f6…` on record (binary
  not present this environment); the original round-10 verification output preserved verbatim
  as `r10_verify_results_v1_superseded.txt`; no file under `evidence/records/`,
  `evidence/decompiles/`, `evidence/tools/` or the reference demo files was modified.
* Static analysis + numerical evaluation only (no target execution; no REA/Ghidra runs this
  round — the binary is absent and no static question required it). The target was never
  executed; runtime questions remain open exactly as documented in
  `docs/OCTAVOX_OPEN_QUESTIONS.md` and `docs/OCTAVOX_ROUND11_FINDINGS.md` §6 — no PoC result
  is substituted for a target measurement.
