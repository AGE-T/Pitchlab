@echo off
rem PitchLab R22 validation: lagrange6_balanced A/B null test
setlocal
set KIT=%~dp0
octavox_dual_nulltest.exe --lagrange6 "%KIT%..\Builds\Lagrange6_lagrange6_Balanced\PitchLab_Lagrange6_lagrange6_Balanced.vst3" --obskernel6 "%KIT%..\Builds\ObsKernel6_Balanced\PitchLab_ObsKernel6_Balanced.vst3"
endlocal
