# OCTAVOX Native DSP Core (15.0.0)

Our own C++17 port of the round-11 `delayline_aligned` design plus the
round-12 unity engagement fix, the recovered round-13/14 scope (cold-start
alignment law, sample-rate-relative detector window, zero-allocation
re-prepare), and the round-15 P1 **per-voice harmonizer parameter surface**:
per-voice pitch ratio / gain / mute / base-delay overrides, a wet/dry mix
with the latency-aligned dry path, and a click-free state-transparent
bypass — all audio-thread-safe with block-boundary application semantics.
**Not a VST3 plugin and not a reproduction of the original plugin's runtime
behaviour** — see `ARCHITECTURE.md` for the full note (state, memory
ownership, threading, channel isolation, limitations) and
`../docs/OCTAVOX_ROUND15_FINDINGS.md` for the research context.

[R16-P1 correction, 2026-10-28: the title and intro previously described
the round-12 state ("Round 12", 51 cases); superseded to the actual 15.0.0
state — see evidence/analysis_round16/R16_P1_RECONCILIATION_LOG.md.]
[R17 addendum, 2026-10-29: the harness gained a `--reverse` order-
independence flag (JSON `environment.reverse_order`); the CMakeLists and
both harness sources carry MSVC portability guards (Linux-neutral — the
release suite, the four hashes and the module hash are unchanged); the
wrapper tests are 15/15; see docs/OCTAVOX_ROUND17_FINDINGS.md.]

## Layout

```
include/octavox/dsp.hpp   public API (AlignedDelayLine, MultichannelShifter;
                         the ROUND-15 PARAMETER SURFACE contract is normative)
src/dsp.cpp               implementation (15.0.0, R15-REB1 rebuild)
src/obs_kernel_table.h    OBSERVED target .rdata kernel (opt-in mode; data, not code)
tests/test_main.cpp       correctness + unity + acceptance suite (85 cases)
tests/r15_acceptance_cases.cpp.inc  the 7 r15acc_* acceptance case definitions
tests/wav_io.*            WAV I/O (harness only; mirrors the Python CLI)
tests/alloc_counter.cpp   global-new counter for the no-alloc gate
bench/bench_main.cpp      release benchmark, 12 cases (deterministic LCG input;
                         incl. 96 kHz variants + the active-surface case)
cli/octavox_cli.cpp       WAV->WAV demo CLI (cross-language metrics driver)
cli/r15ref_capture.cpp    neutrality reference capture (octavox_r15refcap)
r15_reference_hashes.txt  the four default-neutrality regression hashes
VST3_READINESS.md         wrapper readiness assessment
tools/                    R17-P2: pinned-SHA SDK acquisition + full build/test
                          chains (get_vst3_sdk.{sh,ps1}, build_and_test.{sh,ps1})
ARCHITECTURE.md           architecture note (round-15 surface mechanisms)
```

## Build

Requires CMake ≥ 3.16 and a C++17 compiler (developed with GCC 14.2).

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

Sanitizer build (address + undefined):

```sh
cmake -S . -B build-asan -DCMAKE_BUILD_TYPE=Debug -DENABLE_SANITIZERS=ON
cmake --build build-asan -j
```

## Test / benchmark

```sh
./build/octavox_tests --json results.json      # exit 0 = all pass
./build-asan/octavox_tests --json results_asan.json
./build/octavox_bench --json bench.json
./build/octavox_cli --in ../poc/example_input.wav --out out.wav --cents 400 --voices 3
```

The authoritative cross-language measurements (native vs the preserved Python
reference) are produced by
`../evidence/analysis_round12/r12_native_metrics.py`.

## Recorded results (this round's environment)

* `octavox_tests` (release, 15.0.0): **85/85 pass** — the 51 frozen round-12
  cases (unity bit-exactness, the cent battery, 1/8 voices, mono/stereo,
  channel isolation, block-size invariance, repeated prepare, reset
  determinism, long runs, NaN/clip gates, steady-state allocation-freedom)
  + 19 R13-recovery cases (cold-start alignment, 96 kHz/44.1 kHz detector
  batteries, estimate tracking, RT re-prepare/reset/setters) + 7 P1 surface
  cases + 7 r15acc acceptance cases; machine-readable JSON
  (`../evidence/analysis_round15/r15_acceptance_results.json`).
* ASan+UBSan build: **85/85 pass, zero sanitizer reports**.
* Default-path neutrality: the four reference hashes in
  `r15_reference_hashes.txt` (12.0.0 == 15.0.0 bit-identical; re-verified
  by `octavox_r15refcap` before any round-16 edit).
* Benchmark (12 cases, mono/stereo 48 kHz + 96 kHz + active surface, best
  of 3): ≈ 15.5–15.9× realtime (1 voice) / ≈ 13.4–13.8× (8 voices) at the
  default 64-sample control interval; ≈ 50× realtime with the interval at
  512 (the YIN detector is ~73 % of the cost); 96 kHz ≈ 2.0–2.1× realtime
  (the R13-b window law price); stereo ≈ 6.4–7.9×. Zero steady-state
  allocations in every case.
* Cross-language (identical input, round-12 record): the Python reference
  runs at 0.42× (1 voice) / 0.25× (8 voices) realtime — the native core is
  ≈ 35–55× faster on the same machine.

## Version history (recovery record)

- **14.0.0** — recovered round-13/14 scope rebuilt on the round-12 baseline
  after an environment reset (see worklog R15-R0/E1/E1a/E1b/EV1): cold-start
  alignment law, the R13-b detector window law (`win = max(2048,
  ceil(2.5·τmax))` — the round-12 core was blind at 96 kHz), zero-allocation
  re-prepare, RT contract, tracker/rate-limiter parity evidence, four-mode
  interpolation comparison (Lagrange6 stays default), 14.0.0 baseline bench.
  The original rounds-13/14 artifacts were lost in the reset.
- **15.0.0** — round-15 P1 per-voice harmonizer parameter surface: per-voice
  pitch ratio / gain / mute / base delay, wet/dry mix with the dry path
  aligned to the intrinsic latency, click-free bypass; block-boundary
  parameter application. Re-implemented after a SECOND environment reset
  (worklog R15-R1/REB-1) and verified bit-neutral vs 12.0.0 by the four
  reference hashes in `r15_reference_hashes.txt` (tool `octavox_r15refcap`:
  re-run after any core change and check the hashes). Suite: 85 cases
  (51 frozen round-12 + 19 R13 + 7 P1 + 7 r15acc acceptance); see
  `../evidence/analysis_round15/r15_acceptance_results.json` and
  `r15_bench_comparison.md` for the P5 regression verdict.

## Round 16 additions (test/bench harness + the VST3 wrapper)

- **Harness (R16-P2):** per-case wall durations with live progress output,
  `--list` / `--filter <substr>` / `--group <id>` / `--category unit|long`
  selection, `--durations` table column, machine-readable JSON with an
  environment record and per-group subtotals; the benchmark gained
  `--case/--cases` named selection and a 13th row
  (`mono_8v_b128_96k_ctrl512`, the 96 kHz detector-cost isolation
  measurement). All 85 tests remain in the default full run; the gates are
  unchanged (220 `check(...)` calls textually identical; pre-edit sources
  preserved in `../evidence/analysis_round16/`). Measured here: release
  85/85 in ~41 s; ASan+UBSan 85/85 in ~6.2 min.
- **VST3 wrapper (R16-P4b, extended R17-P3):** `native/vst3/` — a REAL
  minimal VST3 plug-in around this core (module `OctavoxNative.vst3`,
  validator 47/47, wrapper tests **15/15** — the R16 eight incl. the
  bit-exact sample-accurate-vs-block-boundary equivalence proof and the
  state roundtrips, plus the R17 seven: the 38-parameter metadata
  audit/conversion roundtrips, block start/middle/last/end events,
  simultaneous multi-voice events, clickless bypass+wet/dry automation
  with 0 allocations, full-surface save/restore, cross-rate/cross-layout
  restore, and invalid/truncated state blobs). Requires the VST3 SDK
  v3.7.12_build_20 (NOT redistributed; acquire+verify it with
  `tools/get_vst3_sdk.sh` / `.ps1` — executed this round — or follow the
  pinned-SHA record in `vst3/VST3_WRAPPER.md`; the full chain:
  `tools/build_and_test.sh`, executed end-to-end, and
  `tools/build_and_test.ps1` for Windows/MSVC — **authored, not executed:
  no Windows runtime here**). The core itself is unchanged; the wrapper
  compiles it from `../src` independently. The module rebuilds
  byte-identically (SHA-256 b293cecb...).
[R18 addendum, 2026-10-30: the test harness gained the `--diag <path>`
forensic trace (case start/completion records with per-case wall time,
process RSS, the always-on allocation-counter totals and an FP-environment
probe — designed for post-mortem analysis when a constrained environment
kills a run inside a window) and the `--isolate` group-isolated fallback
mode (one fresh forked process per group; POSIX only; explicitly NOT
equivalent to the single-process full run). The 85-case default suite and
all gates are unchanged; the four reference hashes still match (re-verified
this round in the release, ASan and -O0 legs). The aggregate-suite timing
anomaly reported by the independent verification environment is
quantitatively reconciled (one uniform slowdown factor
F ∈ [12.42, 15.85]) and positively reproduced under CPU contention — see
`../evidence/analysis_round18/r18_suite_diagnostics.md`. The VST3 side
gained the compiled-module integration harness (12/12, bit-exact vs this
core) — see `vst3/VST3_WRAPPER.md` §7.]

---

## ROUND 19 (16.0.0) — real-time, clicks, dual-interpolation verification

The core version is 16.0.0 (dsp.hpp ROUND-19 CONTRACT; every behavioural
change is config-gated and the 15.0.0 behaviour reproduces BIT-EXACTLY
under the legacy pins — gated by the 4+4 legacy hash records and the
legacy-pinned default_neutrality case):

* **Decimated control-rate pitch detector** (`DetectorMode::Decimated`,
  the new default): 6th-order Butterworth anti-alias + decimation to
  ~24 kHz, time-equivalent window law, identical cadence; 96 kHz stereo
  8 voices drops from 100.6% to **13.2% CPU (86.8% headroom)**. FullRate
  retained as the bit-exact reference mode. Worst battery error 0.19 cent.
* **Click-free transitions**: spacing commits crossfade through a frozen
  shadow grain (initial-lock/retune steps 0.55-0.79 -> 0.011-0.018,
  32-67x), base-delay changes crossfade, voice activation rides the gain
  ramps; the wet/dry instant mix step is bounded and documented.
* **Read suppression** (bypass/zero-wet, fb==0): bit-identical by
  construction, gated by a dedicated test.
* **Stage profiler** (`OCTAVOX_STAGE_TIMERS`, opt-in compile definition)
  + VoiceStats wrap/commit stream timestamps.
* Suite: 85 -> **93 cases** (8 new r19 cases; no gate weakened). Release
  93/93; ASan+UBSan 93/93 with zero sanitizer reports. New reference
  record: r19_reference_hashes.txt (+ the r15/r18-obs legacy records still
  reproduce exactly).
* New tools: octavox_r19_clickscan (offline click suite), r19_nulltest
  (dual-interpolation A/B, 32-bit float WAVs), r19_variant_metrics
  (variant performance comparison), vst3/octavox_dual_nulltest (loads BOTH
  variant bundles in one process). State blob v2 (v1-compatible). VST3
  plugin version 1.1.0; wrapper/integration/validator 15/15, 12/12, 47/47
  per variant.

See docs/OCTAVOX_ROUND19_FINDINGS.md for the full measured record.
