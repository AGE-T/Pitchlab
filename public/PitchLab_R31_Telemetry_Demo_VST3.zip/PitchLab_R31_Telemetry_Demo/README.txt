# PitchLab Harmonizer — R31 Telemetry & Latency-Truth Demo (Linux VST3)

**What this is:** a fresh build of the PitchLab Harmonizer VST3
(Lagrange6 "Balanced" variant, Linux x86-64) that carries the features
derived from the R26-R30 static-audit findings of the original Eventide
Octavox binary — the m02-style pitch telemetry, the block-rate poller with
dirty-bit fanout, the vendor-interface pattern and the latency-truth
notification.

**Clean-room note:** PitchLab is our own independent harmonizer built around
our own DSP core. No code from the original plug-in is contained; the
original binary was never executed. The audit findings used here are
behavioural facts (formulas + architecture), documented in the repository's
OCTAVOX_R26..R30 reports.

## Install (Linux, VST3 host)
1. Copy `PitchLab_Lagrange6_Balanced.vst3` to your VST3 bundle folder:
   `~/.vst3/` (user) or `/usr/lib/vst3/` (system), or any folder your DAW
   scans.
2. Rescan plug-ins in your DAW. The plug-in appears as
   **"PitchLab Harmonizer Lagrange6 Balanced"** (vendor: PitchLab Project).
3. I/O: mono or stereo Main bus; 38 automatable parameters (6 global +
   4 per voice × 8 voices: pitch ±24 st, spread, feedback, wet/dry, and
   per-voice offset/gain/mute/delay).

Reported latency: base_delay + grain/2 samples (the dry path is
latency-aligned); the host is notified via kLatencyChanged whenever the
reported value changes.

## For host/tool authors: the vendor telemetry interface
The processor answers a CUSTOM interface via queryInterface (the same
architectural pattern the original plug-in uses for its vendor
functionality — no extra parameters, the automation surface stays frozen):

```
IID IPitchTelemetry = {D1A60F31-8C4B-4E39-9A67-31D1-8E4F5A21}

getVoiceFrame(voice, double frame14)  // per-voice frame, id-indexed cells
getCellId(cell, int32* idOut)         // self-describing id map (7..13)
consumeDirtyBits() -> uint64          // read-and-clear the change mask
getDirtyBits()    -> uint64           // peek without clearing
```

Frame cell semantics (the m02-style id space; ids 0..6 reserved):
| id | meaning | source in PitchLab |
|---|---|---|
| 7 | cents from C4 (1200/ln2 · ln(f0/261.6256)); **−65535 = no pitch** | control layer's tracked Hz when locked, else the raw detector estimate |
| 8 | the voice's current gliding shift ratio | per-voice engine state |
| 9 | Q23-quantised ratio n/(n+8), n = llround(ratio·2²³) | computed from id 8 |
| 10 | sqrt(frac·(1−2⁻²³)), frac = the voice's grain phase | per-voice engine state |
| 11 | confidence-like combination (periodicity × control-state weight; labelled PitchLab mapping) | CMNDF minimum + control state |
| 12 | −cents of the applied shift vs unity (gated: a live pitch is shifted) | computed from id 8 |
| 13 | +cents twin of id 12 | computed from id 8 |

Dirty-bit contract: bit `voice*8 + (id−7)` sets when that cell CHANGED at a
block-rate poll (the poller runs once per process() call); `consumeDirtyBits`
returns and clears the mask. 8 voices × 7 ids = 56 live bits.

Reference C++ usage (SDK types):
```cpp
if (auto* tel = Steinberg::FCast<IPitchTelemetry>(audioProcessor)) {
    double frame[14];
    tel->getVoiceFrame(0, frame);        // voice 0
    uint64 changed = tel->consumeDirtyBits();
    // bit 0 = voice 0 / id 7 (cents) changed, bit 3 = voice 0 / id 10, ...
}
```

## Verification (this build)
- core suite: 115/115 (Release) — 4/4 reference hashes bit-exact
- core suite: ASan/UBSan — see verification_asan.txt (if present)
- VST3 wrapper tests: 21/21
- module integration (compiled bundle through the SDK loader): 16/16
  (12 previous + 4 new R31 cases: telemetry_vendor_interface,
  telemetry_values_sentinel, telemetry_dirty_bits, latency_notification)
- Steinberg VST3 validator: 47/47

Measured highlight: a 220 Hz sine reads id 7 = −300.009 cents
(0.009 cent tracker precision).

## Honest limits
- Linux x86-64 binary only this round (the Windows cross-toolchain was not
  re-acquired after the sandbox resets; the MinGW build paths remain
  authored in the tree, green at R24-W).
- No GUI: the telemetry is reachable through the vendor interface, not on
  screen. Point a host tool or a small SDK-based reader at it.
- No DAW was involved in verification; the SDK validator + module loader
  are the compatibility evidence.
