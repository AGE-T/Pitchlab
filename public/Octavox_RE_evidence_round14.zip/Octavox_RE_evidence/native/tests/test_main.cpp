// OCTAVOX round 12 -- native test harness: correctness + unity regression.
//
// Gated by the process exit code (0 = all pass, 1 = any failure).
// Machine-readable results: --json <path> writes a JSON report; a summary
// table goes to stdout. Every case records the measured values so the
// report is evidence, not just a boolean.
//
// Deterministic by construction: every generator is a fixed formula or the
// shared 64-bit LCG (identical implementation exists on the Python side for
// the cross-language benchmark: evidence/analysis_round12/r12_native_metrics.py).

#include <algorithm>
#include <cmath>
#include <sys/resource.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "octavox/dsp.hpp"
#include "wav_io.hpp"

using namespace octavox;

// ---------------------------------------------------------------------------
// Allocation counter interface (defined in alloc_counter.cpp)
// ---------------------------------------------------------------------------
namespace octavox {
namespace allocs {
long count();
void arm(bool on);
void reset();
}  // namespace allocs
}  // namespace octavox

// ---------------------------------------------------------------------------
// Deterministic generators (shared spec with the Python metrics script)
// ---------------------------------------------------------------------------
namespace gen {

/// 64-bit LCG, identical on the Python side. u in [0,1); sample = (2u-1)*amp.
struct Lcg {
    uint64_t s;
    explicit Lcg(uint64_t seed) : s(seed * 6364136223846793005ULL +
                                     1442695040888963407ULL) {}
    double next() {
        s = s * 6364136223846793005ULL + 1442695040888963407ULL;
        const uint64_t m = (s >> 11) & ((1ULL << 53) - 1);
        return static_cast<double>(m) / 9007199254740992.0;
    }
    double noise(double amp) { return (2.0 * next() - 1.0) * amp; }
};

std::vector<float> tone(double f, int sr, int n, double amp) {
    std::vector<float> x(n);
    for (int i = 0; i < n; ++i)
        x[i] = static_cast<float>(amp * std::sin(2.0 * M_PI * f * i / sr));
    return x;
}

std::vector<float> chord(const std::vector<double>& fs, int sr, int n,
                         double amp) {
    std::vector<float> x(n, 0.0f);
    for (double f : fs)
        for (int i = 0; i < n; ++i)
            x[i] += static_cast<float>(amp / fs.size() *
                                       std::sin(2.0 * M_PI * f * i / sr));
    return x;
}

std::vector<float> noise(uint64_t seed, int n, double amp) {
    Lcg rng(seed);
    std::vector<float> x(n);
    for (int i = 0; i < n; ++i) x[i] = static_cast<float>(rng.noise(amp));
    return x;
}

std::vector<float> impulse(int n) {
    std::vector<float> x(n, 0.0f);
    x[0] = 1.0f;
    return x;
}

/// Percussive burst train: exponential decays.
std::vector<float> bursts(int sr, int n, double period_s, double amp) {
    std::vector<float> x(n, 0.0f);
    Lcg rng(99);
    const int per = static_cast<int>(period_s * sr);
    for (int i = 0; i < n; ++i) {
        const int t = i % per;
        if (t < 200)
            x[i] = static_cast<float>(amp * std::exp(-t / 40.0) *
                                      (t == 0 ? 1.0 : rng.noise(1.0)));
    }
    return x;
}

std::vector<float> chirp(double f0, double f1, int sr, int n, double amp) {
    std::vector<float> x(n);
    const double T = static_cast<double>(n) / sr;
    for (int i = 0; i < n; ++i) {
        const double t = static_cast<double>(i) / sr;
        const double f = f0 * std::pow(f1 / f0, t / T);
        x[i] = static_cast<float>(amp * std::sin(2.0 * M_PI * f * t));
    }
    return x;
}

}  // namespace gen

// ---------------------------------------------------------------------------
// Measurement helpers
// ---------------------------------------------------------------------------
namespace meas {

/// Radix-2 complex FFT (in-place, n a power of two).
void fft(double* re, double* im, int n) {
    for (int i = 1, j = 0; i < n; ++i) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) {
            std::swap(re[i], re[j]);
            std::swap(im[i], im[j]);
        }
    }
    for (int len = 2; len <= n; len <<= 1) {
        const double ang = -2.0 * M_PI / len;
        const double wr = std::cos(ang), wi = std::sin(ang);
        for (int i = 0; i < n; i += len) {
            double cr = 1.0, ci = 0.0;
            for (int k = 0; k < len / 2; ++k) {
                const double ur = re[i + k], ui = im[i + k];
                const double vr = re[i + k + len / 2] * cr -
                                  im[i + k + len / 2] * ci;
                const double vi = re[i + k + len / 2] * ci +
                                  im[i + k + len / 2] * cr;
                re[i + k] = ur + vr;
                im[i + k] = ui + vi;
                re[i + k + len / 2] = ur - vr;
                im[i + k + len / 2] = ui - vi;
                const double nr = cr * wr - ci * wi;
                ci = cr * wi + ci * wr;
                cr = nr;
            }
        }
    }
}

/// FFT peak pitch with parabolic interpolation (Hann window).
/// Returns 0.0 when no peak above the threshold is found.
double pitchFFT(const float* x, int n, int sr, double fmin, double fmax) {
    int N = 1;
    while (N < n && N < 262144) N <<= 1;  // round 13: 2^18 zero-pad (low-f0
    // pitch at 96/192 kHz needs ~4x finer bins than the round-12 2^16 cap)
    if (N < 16) return 0.0;
    std::vector<double> re(N, 0.0), im(N, 0.0);
    // Round 14 fix: when n is NOT a power of two (and n <= 262144) the FFT
    // size N = next_pow2(n) EXCEEDS n, and the round-13 form `off = n - N`
    // went NEGATIVE -- reading samples BEFORE the pointer handed to the
    // meter (out-of-window material; probe evidence: a quiet 220 Hz window
    // preceded by a loud 440 Hz region measured 440 Hz = +1200 c error).
    // Corrected semantics: place the n given samples at the END of the
    // window ("newest N samples" with zero head-padding). Round-13 gate
    // outcomes were unaffected in practice because every affected window
    // was preceded by the same sustained signal it measured (verified by
    // the round-14 re-run: 105/105 with identical verdicts; the numeric
    // deltas are recorded in r14_native_tests_vs_r13.txt).
    const int off = n - N;  // use the newest N samples; zero-pad if negative
    for (int i = 0; i < N; ++i) {
        const int j = off + i;
        const double s = (j >= 0 && j < n) ? static_cast<double>(x[j]) : 0.0;
        const double w = 0.5 - 0.5 * std::cos(2.0 * M_PI * i / N);
        re[i] = s * w;
    }
    fft(re.data(), im.data(), N);
    const int kmin = std::max(1, static_cast<int>(fmin * N / sr));
    const int kmax = std::min(N / 2 - 2, static_cast<int>(fmax * N / sr));
    if (kmax <= kmin) return 0.0;
    int kpeak = kmin;
    double best = 0.0;
    for (int k = kmin; k <= kmax; ++k) {
        const double m = re[k] * re[k] + im[k] * im[k];
        if (m > best) {
            best = m;
            kpeak = k;
        }
    }
    if (best <= 0.0) return 0.0;
    // Round 13: log-domain parabolic peak interpolation. The round-12
    // linear-power parabola carries a systematic, bin-fraction-dependent
    // bias of up to ~5 cents (measured on pure reference tones: +1.9 c at
    // 69.3 Hz, -5.2 c at 75.6 Hz/44.1 kHz); the log-domain form is
    // analytically matched to the Hann window and measures pure tones to
    // within 0.25 cents across the battery's frequencies and rates
    // (probe evidence: evidence/analysis_round13/r13_meter_bias.txt).
    const double la = std::log(re[kpeak - 1] * re[kpeak - 1] +
                               im[kpeak - 1] * im[kpeak - 1] + 1e-300);
    const double lb = std::log(best);
    const double lc = std::log(re[kpeak + 1] * re[kpeak + 1] +
                               im[kpeak + 1] * im[kpeak + 1] + 1e-300);
    double d = 0.0;
    const double den = la - 2.0 * lb + lc;
    if (std::abs(den) > 1e-300) d = 0.5 * (la - lc) / den;
    if (d > 0.5) d = 0.5;
    if (d < -0.5) d = -0.5;
    return static_cast<double>(sr) * (kpeak + d) / N;
}

double rms(const float* x, int n) {
    double s = 0.0;
    for (int i = 0; i < n; ++i) s += static_cast<double>(x[i]) * x[i];
    return n ? std::sqrt(s / n) : 0.0;
}

double peak(const float* x, int n) {
    double p = 0.0;
    for (int i = 0; i < n; ++i) p = std::max(p, std::abs(static_cast<double>(x[i])));
    return p;
}

bool allFinite(const float* x, int n) {
    for (int i = 0; i < n; ++i)
        if (!std::isfinite(x[i])) return false;
    return true;
}

/// Envelope modulation in dB: max/min of RMS windows of `w` samples over the
/// steady region (skip the first skip samples). w = sr/1000 gives the 1 ms
/// metric; w = period gives the period-synchronous metric (the r11 lesson:
/// a 1 ms window phase-breathes several dB on a plain tone).
double envModulationDb(const float* x, int n, int sr, int skip, int w) {
    std::vector<double> env;
    for (int i0 = skip; i0 + w <= n; i0 += w) {
        env.push_back(rms(x + i0, w));
    }
    if (env.empty()) return 0.0;
    double lo = 1e300, hi = 0.0;
    for (double v : env) {
        if (v < lo) lo = v;
        if (v > hi) hi = v;
    }
    if (lo <= 0.0) return hi > 0.0 ? 999.0 : 0.0;
    return 20.0 * std::log10(hi / lo);
}

double centsBetween(double fMeasured, double fNominal) {
    if (fMeasured <= 0.0 || fNominal <= 0.0) return 999.0;
    return 1200.0 * std::log2(fMeasured / fNominal);
}

/// Max absolute sample-to-sample difference (transition click meter).
double maxStep(const float* x, int n, int i0 = 0) {
    double m = 0.0;
    for (int i = std::max(1, i0 + 1); i < n; ++i)
        m = std::max(m, std::abs(static_cast<double>(x[i]) - x[i - 1]));
    return m;
}

}  // namespace meas

// ---------------------------------------------------------------------------
// Case framework + JSON report
// ---------------------------------------------------------------------------
struct CaseResult {
    std::string name;
    bool pass = false;
    std::string note;
    std::vector<std::pair<std::string, double>> values;
    double duration_ms = 0.0;  // round 13: per-case CPU time (P4 profiling)
    double cpu_t0 = 0.0;       // getrusage user+sys at construction
};

// Round 13: CPU time (user+sys) via getrusage -- a real syscall, immune to
// the vDSO clock_gettime livelock observed intermittently in the development
// sandbox. For this single-threaded suite CPU time is the honest duration
// metric (scheduler noise excluded); total wall time is measured externally.
double cpuNowMs() {
    struct rusage ru;
    getrusage(RUSAGE_SELF, &ru);
    return (ru.ru_utime.tv_sec + ru.ru_stime.tv_sec) * 1e3 +
           (ru.ru_utime.tv_usec + ru.ru_stime.tv_usec) * 1e-3;
}

// Finishes a case: records the CPU time, sets pass from the accumulated
// notes and appends to the result list (round 13).
void finishCase(std::vector<CaseResult>& R, CaseResult& c) {
    c.duration_ms = cpuNowMs() - c.cpu_t0;
    c.pass = c.note.empty();
    R.push_back(std::move(c));
}

static std::vector<CaseResult> g_results;

void addValue(CaseResult& c, const std::string& k, double v) {
    c.values.emplace_back(k, v);
}

bool check(CaseResult& c, bool ok, const std::string& what) {
    if (!ok) c.note += (c.note.empty() ? "" : "; ") + what;
    return ok;
}

double semitoneRatio(double cents) { return std::pow(2.0, cents / 1200.0); }

// Runs the engine over a full signal in one go (64-aligned internally is
// irrelevant -- process takes the whole block).
std::vector<float> run(const Config& cfg, const std::vector<float>& in,
                       int block = 1 << 20) {
    AlignedDelayLine e;
    if (!e.prepare(cfg)) {
        return {};
    }
    std::vector<float> out(in.size(), 0.0f);
    int done = 0;
    while (done < static_cast<int>(in.size())) {
        const int n = std::min(block, static_cast<int>(in.size()) - done);
        e.process(in.data() + done, out.data() + done, n);
        done += n;
    }
    return out;
}

// ---------------------------------------------------------------------------
// The cases
// ---------------------------------------------------------------------------
void casesPrepareReset(std::vector<CaseResult>& R) {
    {  // 1. default prepare
        CaseResult c{"prepare_default"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        AlignedDelayLine e;
        const bool ok = e.prepare(cfg);
        check(c, ok, "prepare failed");
        check(c, e.latencySamples() == 2304, "latency != 2304");
        check(c, e.ready(), "not ready");
        finishCase(R, c);
    }
    {  // 2. invalid configs rejected
        CaseResult c{"prepare_invalid_rejected"}; c.cpu_t0 = cpuNowMs();
        int rejected = 0, total = 0;
        Config bad;
        auto tryCfg = [&](const Config& cfg) {
            ++total;
            AlignedDelayLine e;
            if (!e.prepare(cfg)) ++rejected;
        };
        bad = Config();
        bad.sample_rate = 0.0;
        tryCfg(bad);
        bad = Config();
        bad.voices = 9;
        tryCfg(bad);
        bad = Config();
        bad.grain = 0.0;
        tryCfg(bad);
        bad = Config();
        bad.feedback = 1.0;
        tryCfg(bad);
        bad = Config();
        bad.base_delay = 0.0;
        tryCfg(bad);
        addValue(c, "rejected", rejected);
        addValue(c, "total", total);
        check(c, rejected == total, "some invalid configs accepted");
        finishCase(R, c);
    }
    {  // 3. reset determinism
        CaseResult c{"reset_determinism"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(400.0);
        const auto in = gen::tone(220.0, 48000, 48000, 0.5);
        AlignedDelayLine a, b;
        a.prepare(cfg);
        b.prepare(cfg);
        std::vector<float> oa(in.size(), 0.f), ob(in.size(), 0.f),
            ob2(in.size(), 0.f);
        a.process(in.data(), oa.data(), in.size());
        b.process(in.data(), ob.data(), in.size());
        b.reset();
        b.process(in.data(), ob2.data(), in.size());
        double d1 = 0.0, d2 = 0.0;
        for (size_t i = 0; i < in.size(); ++i) {
            d1 = std::max(d1, std::abs((double)oa[i] - ob[i]));
            d2 = std::max(d2, std::abs((double)ob[i] - ob2[i]));
        }
        addValue(c, "fresh_vs_fresh", d1);
        addValue(c, "reset_vs_fresh", d2);
        check(c, d1 == 0.0, "two fresh engines differ");
        check(c, d2 == 0.0, "reset engine differs from fresh");
        finishCase(R, c);
    }
    {  // 4. repeated prepare
        CaseResult c{"repeated_prepare"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(500.0);
        const auto in = gen::tone(330.0, 48000, 24000, 0.4);
        AlignedDelayLine a, b;
        a.prepare(cfg);
        std::vector<float> oa(in.size(), 0.f), ob(in.size(), 0.f);
        a.process(in.data(), oa.data(), in.size());
        a.prepare(cfg);  // re-prepare
        a.process(in.data(), ob.data(), in.size());
        b.prepare(cfg);
        std::vector<float> oc(in.size(), 0.f);
        b.process(in.data(), oc.data(), in.size());
        double d = 0.0;
        for (size_t i = 0; i < in.size(); ++i)
            d = std::max(d, std::abs((double)ob[i] - oc[i]));
        addValue(c, "reprepared_vs_fresh", d);
        check(c, d == 0.0, "re-prepared engine differs from fresh");
        finishCase(R, c);
    }
    {  // 5. block-size invariance
        CaseResult c{"block_size_invariance"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(700.0);
        const auto in = gen::tone(196.0, 48000, 48000, 0.4);
        const auto ref = run(cfg, in, 1 << 20);
        const int splits[] = {1, 7, 16, 64, 128, 512, 1024, 4096};
        double worst = 0.0;
        for (int s : splits) {
            const auto got = run(cfg, in, s);
            double d = 0.0;
            for (size_t i = 0; i < in.size(); ++i)
                d = std::max(d, std::abs((double)ref[i] - got[i]));
            worst = std::max(worst, d);
        }
        // mixed split pattern
        {
            AlignedDelayLine e;
            e.prepare(cfg);
            std::vector<float> got(in.size(), 0.f);
            size_t i = 0;
            int pat[] = {1, 64, 7, 512, 16, 4096, 3};
            int pi = 0;
            while (i < in.size()) {
                int n = std::min(pat[pi % 7], (int)(in.size() - i));
                e.process(in.data() + i, got.data() + i, n);
                i += n;
                ++pi;
            }
            double d = 0.0;
            for (size_t k = 0; k < in.size(); ++k)
                d = std::max(d, std::abs((double)ref[k] - got[k]));
            worst = std::max(worst, d);
        }
        addValue(c, "worst_split_diff", worst);
        check(c, worst == 0.0, "block split changed the output");
        finishCase(R, c);
    }
    {  // 6. steady-state allocation-free
        CaseResult c{"steady_state_no_allocation"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(400.0);
        cfg.voices = 8;
        cfg.feedback = 0.35;
        const auto in = gen::noise(1234, 48000, 0.5);
        AlignedDelayLine e;
        e.prepare(cfg);
        std::vector<float> out(in.size(), 0.f);
        e.process(in.data(), out.data(), 24000);  // warm-up (tables, paths)
        allocs::reset();
        allocs::arm(true);
        e.process(in.data() + 24000, out.data() + 24000,
                  static_cast<int>(in.size()) - 24000);
        allocs::arm(false);
        const long n = allocs::count();
        addValue(c, "allocations_during_process", static_cast<double>(n));
        check(c, n == 0, "allocations during steady-state process()");
        finishCase(R, c);
    }
}

void casesUnity(std::vector<CaseResult>& R) {
    const int sr = 48000;

    // bit-exact delayed-copy gate used by the unity battery
    auto unityExact = [&](const std::string& name, const std::vector<float>& in,
                          bool arrive_from_shift = false) {
        CaseResult c{name}; c.cpu_t0 = cpuNowMs();
        Config cfg;  // ratio exactly 1.0, 1 voice, neutral
        AlignedDelayLine e;
        e.prepare(cfg);
        if (arrive_from_shift) {
            // arrive from +4 st first: 1 s shifted, then unity, then settle
            e.setRatio(semitoneRatio(400.0));
            std::vector<float> pre(sr, 0.f);
            e.process(in.data(), pre.data(), sr);
            e.setRatio(1.0);
            std::vector<float> mid(static_cast<int>(0.3 * sr), 0.f);
            if ((int)in.size() > sr)
                e.process(in.data() + sr, mid.data(),
                           std::min((int)in.size() - sr, (int)mid.size()));
        }
        const int d_park = e.voiceStats(0).parked_delay;
        addValue(c, "d_park", d_park);
        check(c, d_park >= 256 && d_park < 256 + 4096, "d_park out of range");
        check(c, e.voiceStats(0).parked == 1, "voice not parked");
        const int skip = arrive_from_shift ? static_cast<int>(0.05 * sr) : 0;
        std::vector<float> out(in.size(), 0.f);
        e.process(in.data(), out.data(), in.size());
        // Reference ring semantics: a read at delay d returns the sample
        // pushed d-1 samples earlier, so the parked copy is in[k-d_park+1].
        double worst = 0.0;
        int worst_k = -1;
        // an engine that arrived from a shift has legitimate ring history:
        // bit-exactness is only decidable once the read reaches the current
        // run's own input (k >= d_park-1)
        const int k0 = std::max(skip, d_park - 1);
        for (int k = k0; k < (int)in.size(); ++k) {
            const int src = k - d_park + 1;
            const double expect = (src >= 0) ? static_cast<double>(in[src]) : 0.0;
            const double d = std::abs(static_cast<double>(out[k]) - expect);
            if (d > worst) {
                worst = d;
                worst_k = k;
            }
        }
        addValue(c, "max_abs_diff", worst);
        addValue(c, "worst_k", worst_k);
        check(c, worst == 0.0, "unity output is not the bit-exact delayed copy");
        // the pre-delay region is exactly zero (fresh engines only -- an
        // engine that arrived from a shift legitimately has ring history)
        if (!arrive_from_shift) {
            double pre_max = 0.0;
            for (int k = 0; k < d_park - 1 && k < (int)in.size(); ++k)
                pre_max = std::max(pre_max, std::abs((double)out[k]));
            addValue(c, "pre_delay_region_max", pre_max);
            check(c, pre_max == 0.0, "output before d_park not silent");
        }
        finishCase(R, c);
    };

    unityExact("unity_tone_220_bitexact", gen::tone(220.0, sr, 48000, 0.5));
    unityExact("unity_tone_1100_bitexact", gen::tone(1100.0, sr, 48000, 0.5));
    unityExact("unity_noise_bitexact", gen::noise(42, 48000, 0.8));
    unityExact("unity_chord_bitexact",
               gen::chord({196.0, 294.0, 392.0, 494.0}, sr, 48000, 0.8));
    {
        std::vector<float> sil(48000, 0.0f);
        unityExact("unity_silence_bitexact", sil);
    }
    unityExact("unity_lowlevel_bitexact", gen::tone(220.0, sr, 48000, 0.001));
    unityExact("unity_enter_from_+400c_bitexact",
               gen::tone(220.0, sr, 96000, 0.5), true);

    {  // unity gain exactly 1 (follows from bit-exactness, measured anyway)
        CaseResult c{"unity_gain_exact"}; c.cpu_t0 = cpuNowMs();
        const auto in = gen::tone(220.0, sr, 48000, 0.5);
        Config cfg;
        AlignedDelayLine e;
        e.prepare(cfg);
        std::vector<float> out(in.size(), 0.f);
        e.process(in.data(), out.data(), in.size());
        const int d = e.voiceStats(0).parked_delay - 1;
        // out[d..] is an exact copy of in[0..n-d): compare matching segments
        const double ri = meas::rms(in.data(), in.size() - d);
        const double ro = meas::rms(out.data() + d, out.size() - d);
        addValue(c, "gain_db", 20.0 * std::log10(ro / ri));
        check(c, ro == ri, "unity RMS changed");
        finishCase(R, c);
    }

    {  // entry continuity (from +400 cents into unity): no click
        CaseResult c{"unity_entry_continuity"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        AlignedDelayLine e;
        e.prepare(cfg);
        e.setRatio(semitoneRatio(400.0));
        const int preN = 2 * sr;
        const int postN = 1 * sr;
        const auto in = gen::tone(220.0, sr, preN + postN, 0.5);
        std::vector<float> out(in.size(), 0.f);
        e.process(in.data(), out.data(), preN);
        e.setRatio(1.0);
        e.process(in.data() + preN, out.data() + preN, postN);
        // during the transition (first 60 ms after the change)
        const int trans = static_cast<int>(0.06 * sr);
        const double step = meas::maxStep(out.data() + preN, trans);
        const double stepBefore = meas::maxStep(out.data() + preN - trans, trans);
        addValue(c, "transition_max_step", step);
        addValue(c, "pre_transition_max_step", stepBefore);
        check(c, step <= std::max(0.35, 2.0 * stepBefore + 1e-9),
              "transition click");
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        finishCase(R, c);
    }

    // near-unity battery: fresh-start vs via-unity-exit
    auto nearUnity = [&](const std::string& tag, double cents, bool viaUnity) {
        CaseResult c{"near_unity_" + tag + "_" +
                     (viaUnity ? "via_unity" : "fresh")}; c.cpu_t0 = cpuNowMs();
        const double ratio = semitoneRatio(cents);
        Config cfg;
        cfg.ratio = viaUnity ? 1.0 : ratio;
        AlignedDelayLine e;
        e.prepare(cfg);
        const auto in = gen::tone(220.0, sr, 3 * sr, 0.5);
        std::vector<float> out(in.size(), 0.f);
        if (viaUnity) {
            // 1 s at unity (parked), then depart
            e.process(in.data(), out.data(), sr);
            e.setRatio(ratio);
            e.process(in.data() + sr, out.data() + sr, 2 * sr);
        } else {
            e.process(in.data(), out.data(), in.size());
        }
        const double f0nom = 220.0;
        const double fm = meas::pitchFFT(out.data() + static_cast<int>(1.5 * sr),
                                         static_cast<int>(1.5 * sr), sr, 50.0,
                                         4000.0);
        const double err = meas::centsBetween(fm, f0nom) - cents;
        const double gainDb = 20.0 * std::log10(
            meas::rms(out.data() + sr, 2 * sr) /
            meas::rms(in.data() + sr, 2 * sr));
        const int perW = std::max(1, static_cast<int>(std::lround(sr / 220.0)));
        const double mod = meas::envModulationDb(out.data(), out.size(), sr,
                                                 static_cast<int>(1.5 * sr), perW);
        const double commits = static_cast<double>(e.voiceStats(0).commits);
        addValue(c, "measured_f0", fm);
        addValue(c, "pitch_error_cents", err);
        addValue(c, "gain_db", gainDb);
        addValue(c, "env_modulation_db", mod);
        addValue(c, "spacing", e.voiceStats(0).spacing);
        addValue(c, "commits", commits);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        check(c, std::abs(err) <= 2.0, "pitch error > 2 cents");
        // Round 13: the splice commit aligns FRESH near-unity engines within
        // ~50 ms, so the fresh gates equal the via-unity ones (round 12
        // allowed [-4, +2] dB for the documented static comb).
        check(c, gainDb >= -0.75 && gainDb <= 0.75,
              "gain outside +-0.75 dB (cold-start comb not aligned)");
        // Envelope modulation: at near-unity ratios the aligned blend is
        // essentially motionless (<= 0.75 dB); at large shifts the rotating
        // crossfade weight modulates by the design's inherent amount (the
        // r11/r12 battery class: 0.0-1.9 dB at +-500 c), gated accordingly.
        check(c, mod <= (std::abs(cents) <= 100.0 ? 0.75 : 2.0),
              "envelope modulation too high");
        finishCase(R, c);
    };

    const double centsList[] = {1.0,  -1.0, 10.0, -10.0, 50.0,  -50.0,
                                100.0, -100.0, 500.0, -500.0, 1200.0, -1200.0};
    for (double cents : centsList) {
        char tag[32];
        std::snprintf(tag, sizeof(tag), "%+gc", cents);
        nearUnity(tag, cents, false);
    }
    // via-unity for the small shifts where the exit-commit matters most
    nearUnity("+1c", 1.0, true);
    nearUnity("-1c", -1.0, true);
    nearUnity("+10c", 10.0, true);
    nearUnity("-10c", -10.0, true);
    nearUnity("+50c", 50.0, true);
    nearUnity("-50c", -50.0, true);

    {  // no-bypass: +-1 cent really shifts (measured change in pitch)
        CaseResult c{"no_bypass_region"}; c.cpu_t0 = cpuNowMs();
        const auto in = gen::tone(220.0, sr, 3 * sr, 0.5);
        Config cfg;
        cfg.ratio = semitoneRatio(1.0);
        const auto outP = run(cfg, in);
        cfg.ratio = semitoneRatio(-1.0);
        const auto outN = run(cfg, in);
        const double fp = meas::pitchFFT(outP.data() + sr, 2 * sr, sr, 50.0, 4000.0);
        const double fn = meas::pitchFFT(outN.data() + sr, 2 * sr, sr, 50.0, 4000.0);
        const double cp = meas::centsBetween(fp, 220.0);
        const double cn = meas::centsBetween(fn, 220.0);
        addValue(c, "plus_1c_measured_cents", cp);
        addValue(c, "minus_1c_measured_cents", cn);
        check(c, cp > 0.5, "+1 cent did not shift (bypass?)");
        check(c, cn < -0.5, "-1 cent did not shift (bypass?)");
        check(c, cp - cn > 1.0, "+/-1 cent outputs indistinguishable");
        finishCase(R, c);
    }

    {  // unity with feedback: bounded + finite (comb is expected behaviour)
        CaseResult c{"unity_feedback_stability"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.feedback = 0.35;
        AlignedDelayLine e;
        e.prepare(cfg);
        const auto in = gen::noise(7, 5 * sr, 0.5);
        std::vector<float> out(in.size(), 0.f);
        e.process(in.data(), out.data(), in.size());
        const double pk = meas::peak(out.data(), out.size());
        addValue(c, "peak", pk);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        check(c, pk < 4.0, "unstable growth with feedback 0.35 at unity");
        finishCase(R, c);
    }

    {  // 8 voices, spread off, all at unity: exact mean of the parked delays
        CaseResult c{"unity_8voice_unison_exact_mix"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.voices = 8;
        cfg.spread = false;
        AlignedDelayLine e;
        e.prepare(cfg);
        const auto in = gen::tone(220.0, sr, 48000, 0.5);
        std::vector<float> out(in.size(), 0.f);
        e.process(in.data(), out.data(), in.size());
        int d[8];
        for (int v = 0; v < 8; ++v) {
            d[v] = e.voiceStats(v).parked_delay;
            check(c, e.voiceStats(v).parked == 1, "voice not parked");
        }
        double worst = 0.0;
        for (int k = 4800; k < (int)in.size(); ++k) {
            double expect = 0.0;
            for (int v = 0; v < 8; ++v)
                expect += (k - d[v] + 1 >= 0) ? in[k - d[v] + 1] : 0.0f;
            expect /= 8.0;
            // the engine output is the float32 rounding of the double mean
            const float expected_f = static_cast<float>(expect);
            worst = std::max(worst, std::abs((double)out[k] - (double)expected_f));
        }
        addValue(c, "max_abs_diff_vs_exact_mean", worst);
        check(c, worst == 0.0, "8-voice unison mix is not the exact mean");
        finishCase(R, c);
    }
}

void casesVoices(std::vector<CaseResult>& R) {
    const int sr = 48000;
    {  // 8 voices spread +700c: finite, bounded, dominant pitch present
        CaseResult c{"voices_8_spread_+700c"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(700.0);
        cfg.voices = 8;
        const auto in = gen::tone(220.0, sr, 3 * sr, 0.4);
        const auto out = run(cfg, in);
        check(c, !out.empty(), "no output");
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        const double pk = meas::peak(out.data(), out.size());
        addValue(c, "peak", pk);
        check(c, pk < 2.5, "peak too high");
        const double f = meas::pitchFFT(out.data() + sr, 2 * sr, sr, 50.0, 4000.0);
        addValue(c, "dominant_f0", f);
        check(c, f > 150.0 && f < 800.0, "no dominant pitch found");
        finishCase(R, c);
    }
    {  // setVoices mid-stream: ramped normalisation, no NaN
        CaseResult c{"setvoices_midstream"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(400.0);
        AlignedDelayLine e;
        e.prepare(cfg);
        const auto in = gen::tone(220.0, sr, 3 * sr, 0.5);
        std::vector<float> out(in.size(), 0.f);
        e.process(in.data(), out.data(), sr);
        e.setVoices(8);
        e.process(in.data() + sr, out.data() + sr, sr);
        e.setVoices(1);
        e.process(in.data() + 2 * sr, out.data() + 2 * sr, sr);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        const double step = meas::maxStep(out.data() + sr, 48000);
        addValue(c, "max_step_after_voice_change", step);
        check(c, step < 0.5, "click on voice-count change");
        finishCase(R, c);
    }
}

void casesStereo(std::vector<CaseResult>& R) {
    const int sr = 48000;
    {  // L tone / R silence at unity: R exactly zero, L bit-exact
        CaseResult c{"stereo_isolation_unity"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        MultichannelShifter m;
        check(c, m.prepare(cfg, 2), "prepare failed");
        const auto tin = gen::tone(220.0, sr, sr, 0.5);
        std::vector<float> chL = tin, chR(sr, 0.0f);
        std::vector<float> Lo(sr, 0.f), Ro(sr, 0.f);
        const float* in[2] = {chL.data(), chR.data()};
        float* out[2] = {Lo.data(), Ro.data()};
        m.process(in, out, 2, sr);
        const double rmax = meas::peak(Ro.data(), sr);
        addValue(c, "R_peak", rmax);
        check(c, rmax == 0.0, "right channel contaminated at unity");
        const int d = m.voiceStats(0, 0).parked_delay;
        double worst = 0.0;
        for (int k = d - 1; k < sr; ++k)
            worst = std::max(worst, std::abs((double)Lo[k] - chL[k - d + 1]));
        addValue(c, "L_bitexact_diff", worst);
        check(c, worst == 0.0, "left channel not bit-exact at unity");
        finishCase(R, c);
    }
    {  // L tone / R silence at +700c: R exactly zero
        CaseResult c{"stereo_isolation_shifted"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(700.0);
        MultichannelShifter m;
        m.prepare(cfg, 2);
        const auto tin = gen::tone(220.0, sr, 2 * sr, 0.5);
        std::vector<float> chL = tin, chR(2 * sr, 0.0f);
        std::vector<float> Lo(2 * sr, 0.f), Ro(2 * sr, 0.f);
        const float* in[2] = {chL.data(), chR.data()};
        float* out[2] = {Lo.data(), Ro.data()};
        m.process(in, out, 2, 2 * sr);
        const double rmax = meas::peak(Ro.data(), 2 * sr);
        addValue(c, "R_peak", rmax);
        check(c, rmax == 0.0, "right channel contaminated while shifting");
        finishCase(R, c);
    }
    {  // independence: R output identical whether L is processed or not
        CaseResult c{"stereo_independence"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(400.0);
        MultichannelShifter m;
        m.prepare(cfg, 2);
        const auto tl = gen::tone(220.0, sr, sr, 0.5);
        const auto tr = gen::tone(330.0, sr, sr, 0.5);
        std::vector<float> Lo(sr, 0.f), Ro(sr, 0.f);
        const float* in[2] = {tl.data(), tr.data()};
        float* out[2] = {Lo.data(), Ro.data()};
        m.process(in, out, 2, sr);
        // mono run on R alone
        AlignedDelayLine solo;
        solo.prepare(cfg);
        std::vector<float> Ro2(sr, 0.f);
        solo.process(tr.data(), Ro2.data(), sr);
        double worst = 0.0;
        for (int k = 0; k < sr; ++k)
            worst = std::max(worst, std::abs((double)Ro[k] - Ro2[k]));
        addValue(c, "R_diff_vs_solo", worst);
        check(c, worst == 0.0, "R output depends on L processing");
        finishCase(R, c);
    }
}

void casesRatesFormats(std::vector<CaseResult>& R) {
    {  // 44.1 kHz
        CaseResult c{"rate_44100_+400c"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.sample_rate = 44100.0;
        cfg.ratio = semitoneRatio(400.0);
        const int sr = 44100;
        const auto in = gen::tone(220.0, sr, 3 * sr, 0.5);
        const auto out = run(cfg, in);
        const double f = meas::pitchFFT(out.data() + sr, 2 * sr, sr, 50.0, 4000.0);
        const double err = meas::centsBetween(f, 220.0) - 400.0;
        addValue(c, "pitch_error_cents", err);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        check(c, std::abs(err) <= 2.0, "pitch error > 2 cents at 44.1 kHz");
        finishCase(R, c);
    }
    {  // 96 kHz -- round 13: the decimated analysis path supports the full
       // detector range at this rate (round 12 fell back to S = G here and
       // the gate was a permissive 25 cents; the fix tightens it to the same
       // 2-cent gate as 44.1/48 kHz)
        CaseResult c{"rate_96000_+400c"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.sample_rate = 96000.0;
        cfg.ratio = semitoneRatio(400.0);
        const int sr = 96000;
        const auto in = gen::tone(220.0, sr, 3 * sr, 0.5);
        const auto out = run(cfg, in);
        const double f = meas::pitchFFT(out.data() + sr, 2 * sr, sr, 50.0, 4000.0);
        const double err = meas::centsBetween(f, 220.0) - 400.0;
        addValue(c, "pitch_error_cents", err);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        check(c, std::abs(err) <= 2.0, "pitch error > 2 cents at 96 kHz");
        finishCase(R, c);
    }
    {  // WAV round trip on the shipped example input (if present)
        CaseResult c{"wav_roundtrip_example_input"}; c.cpu_t0 = cpuNowMs();
        const char* candidates[] = {"../poc/example_input.wav",
                                    "../../poc/example_input.wav",
                                    "../../../poc/example_input.wav"};
        int sr = 0, ch = 0;
        std::vector<float> x;
        bool loaded = false;
        for (const char* pocPath : candidates) {
            try {
                x = wav::readWav(pocPath, sr, ch);
                loaded = true;
                break;
            } catch (const std::exception&) {
            }
        }
        if (!loaded || x.empty()) {
            c.note = "example_input.wav not found (running outside tree)";
            c.pass = true;  // environment-dependent skip, reported honestly
            addValue(c, "skipped", 1);
        } else {
            Config cfg;
            cfg.ratio = semitoneRatio(400.0);
            const auto out = run(cfg, x);
            check(c, meas::allFinite(out.data(), out.size()), "non-finite");
            wav::writeWav("/tmp/octavox_native_example_out.wav", out.data(),
                          out.size(), ch, sr);
            int sr2 = 0, ch2 = 0;
            const auto back = wav::readWav("/tmp/octavox_native_example_out.wav",
                                           sr2, ch2);
            check(c, sr2 == sr && ch2 == ch, "round-trip format changed");
            double worst = 0.0;
            for (size_t i = 0; i < out.size(); ++i)
                worst = std::max(worst, std::abs((double)out[i] - back[i]));
            addValue(c, "quant_error_max", worst);
            check(c, worst <= 2.0 / 32767.0,
                  "16-bit round-trip error too large (write/read asymmetry is "
                  "reference parity: round(y*32767) then /32768)");
            c.pass = c.note.empty();
        }
        finishCase(R, c);
    }
    {  // 24-bit WAV read
        CaseResult c{"wav_24bit_read"}; c.cpu_t0 = cpuNowMs();
        // write a minimal 24-bit WAV by hand
        const int sr = 48000, n = 256;
        std::vector<int32_t> vals(n);
        for (int i = 0; i < n; ++i) vals[i] = (i * 7919) % 4000000 - 2000000;
        std::vector<unsigned char> bytes(44 + 3 * n);
        std::memcpy(bytes.data(), "RIFF", 4);
        const uint32_t riffSz = 36 + 3 * n;
        std::memcpy(bytes.data() + 4, &riffSz, 4);
        std::memcpy(bytes.data() + 8, "WAVE", 4);
        std::memcpy(bytes.data() + 12, "fmt ", 4);
        const uint32_t fsz = 16;
        std::memcpy(bytes.data() + 16, &fsz, 4);
        const uint16_t af = 1, ch = 1, bits = 24;
        const uint32_t rate = sr, br = sr * 3;
        const uint16_t block = 3;
        std::memcpy(bytes.data() + 20, &af, 2);
        std::memcpy(bytes.data() + 22, &ch, 2);
        std::memcpy(bytes.data() + 24, &rate, 4);
        std::memcpy(bytes.data() + 28, &br, 4);
        std::memcpy(bytes.data() + 32, &block, 2);
        std::memcpy(bytes.data() + 34, &bits, 2);
        std::memcpy(bytes.data() + 36, "data", 4);
        const uint32_t dsz = 3 * n;
        std::memcpy(bytes.data() + 40, &dsz, 4);
        for (int i = 0; i < n; ++i) {
            bytes[44 + 3 * i] = vals[i] & 0xFF;
            bytes[45 + 3 * i] = (vals[i] >> 8) & 0xFF;
            bytes[46 + 3 * i] = (vals[i] >> 16) & 0xFF;
        }
        FILE* f = std::fopen("/tmp/octavox_24bit.wav", "wb");
        std::fwrite(bytes.data(), 1, bytes.size(), f);
        std::fclose(f);
        int sr2 = 0, ch2 = 0;
        auto x = wav::readWav("/tmp/octavox_24bit.wav", sr2, ch2);
        check(c, sr2 == sr && ch2 == 1 && (int)x.size() == n, "bad header");
        double worst = 0.0;
        for (int i = 0; i < n && i < (int)x.size(); ++i)
            worst = std::max(worst,
                             std::abs((double)x[i] - vals[i] / 8388608.0));
        addValue(c, "max_read_error", worst);
        check(c, worst == 0.0, "24-bit values wrong");
        finishCase(R, c);
    }
}

void casesStability(std::vector<CaseResult>& R) {
    const int sr = 48000;
    {  // long run: 60 s noise, 8 voices, feedback
        CaseResult c{"longrun_60s_8voice_feedback"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(1200.0);
        cfg.voices = 8;
        cfg.feedback = 0.35;
        const auto in = gen::noise(2025, 60 * sr, 0.5);
        const auto out = run(cfg, in);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        const double pk = meas::peak(out.data(), out.size());
        addValue(c, "peak", pk);
        check(c, pk < 4.0, "unstable growth");
        // tail RMS must not exceed head RMS by much (no divergence)
        const double rh = meas::rms(out.data(), 5 * sr);
        const double rt = meas::rms(out.data() + 55 * sr, 5 * sr);
        addValue(c, "head_rms", rh);
        addValue(c, "tail_rms", rt);
        check(c, rt < 4.0 * rh + 1e-9, "diverging tail");
        finishCase(R, c);
    }
    {  // 30 s chirp +700c
        CaseResult c{"chirp_30s_+700c"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(700.0);
        const auto in = gen::chirp(100.0, 1000.0, sr, 30 * sr, 0.5);
        const auto out = run(cfg, in);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        const double pk = meas::peak(out.data(), out.size());
        addValue(c, "peak", pk);
        check(c, pk < 3.0, "peak too high on chirp");
        finishCase(R, c);
    }
    {  // impulse latency
        CaseResult c{"impulse_latency"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(400.0);
        const auto in = gen::impulse(sr);
        const auto out = run(cfg, in);
        int first = -1;
        for (int k = 0; k < (int)out.size(); ++k)
            if (out[k] != 0.0f) {
                first = k;
                break;
            }
        addValue(c, "first_nonzero_sample", first);
        addValue(c, "nominal_latency", cfg.base_delay + cfg.grain * 0.5);
        check(c, first >= 250, "responds before base_delay");
        check(c, first <= 256 + 32 + 4400, "responds too late");
        finishCase(R, c);
    }
    {  // unity impulse: first nonzero exactly at d_park
        CaseResult c{"impulse_latency_unity"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        const auto in = gen::impulse(sr);
        const auto out = run(cfg, in);
        AlignedDelayLine e;
        e.prepare(cfg);
        const int d = e.voiceStats(0).parked_delay;
        int first = -1;
        for (int k = 0; k < (int)out.size(); ++k)
            if (out[k] != 0.0f) {
                first = k;
                break;
            }
        addValue(c, "first_nonzero_sample", first);
        addValue(c, "d_park", d);
        check(c, first == d - 1, "unity impulse not at d_park-1");
        finishCase(R, c);
    }
    {  // DC input: finite (guards div-by-zero in spacing/median paths)
        CaseResult c{"dc_input_finite"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(400.0);
        std::vector<float> in(10 * sr, 1.0f);
        const auto out = run(cfg, in);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite on DC");
        finishCase(R, c);
    }
    {  // clipping behaviour: hot input stays finite; WAV writer clips
        CaseResult c{"clipping_behaviour"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(1200.0);
        cfg.voices = 8;
        std::vector<float> in(sr, 0.0f);
        for (int i = 0; i < sr; ++i)
            in[i] = (i % 480 < 240) ? 1.0f : -1.0f;  // full-scale square
        const auto out = run(cfg, in);
        const double pk = meas::peak(out.data(), out.size());
        addValue(c, "float_domain_peak", pk);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        check(c, pk < 8.0, "float peak beyond sane bound");
        wav::writeWav("/tmp/octavox_clip.wav", out.data(), out.size(), 1, sr);
        int sr2 = 0, ch2 = 0;
        auto back = wav::readWav("/tmp/octavox_clip.wav", sr2, ch2);
        const double pkq = meas::peak(back.data(), back.size());
        addValue(c, "wav_peak_after_clip", pkq);
        check(c, pkq <= 1.0, "WAV writer did not clip-guard");
        finishCase(R, c);
    }
}

// ---------------------------------------------------------------------------
// Round 13, Priority 3: deterministic real-time preparation
// ---------------------------------------------------------------------------
void casesRealtimeSafety(std::vector<CaseResult>& R) {
    {  // The interpolation tables must be initialised by prepare(), never on
       // the audio path. This suite runs FIRST, so the first prepare() below
       // is the process's first -- the count must go to exactly 1 here and
       // stay there for the whole process (checked again at the end).
        CaseResult c{"tables_init_at_prepare"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        AlignedDelayLine e;
        const long before = diagnostics::interpTableInitCount();
        e.prepare(cfg);
        const long after = diagnostics::interpTableInitCount();
        addValue(c, "init_count_before_prepare", static_cast<double>(before));
        addValue(c, "init_count_after_prepare", static_cast<double>(after));
        check(c, after == 1 && before == 0,
              "tables not constructed exactly once at the first prepare()");
        check(c, diagnostics::interpTablesReady(),
              "tables not ready immediately after prepare()");
        check(c, diagnostics::interpTableInitDuringProcess() == 0,
              "table construction reported inside process()");
        finishCase(R, c);
    }
    {  // First process() call: no initialisation spike, no allocation. Runs
       // BEFORE any other processing in this process, so a reintroduced lazy
       // init would show up as a second table construction here.
        CaseResult c{"first_process_clean"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(400.0);
        AlignedDelayLine e;
        e.prepare(cfg);
        const long ic0 = diagnostics::interpTableInitCount();
        const int n = 32768;
        const auto in = gen::tone(220.0, 48000, n, 0.5);
        std::vector<float> out(n, 0.f);
        allocs::reset();
        allocs::arm(true);
        const double t0 = cpuNowMs();
        e.process(in.data(), out.data(), n);
        const double firstMs = cpuNowMs() - t0;
        allocs::arm(false);
        const long ic1 = diagnostics::interpTableInitCount();
        double medMs = 0.0;
        for (int rep = 0; rep < 5; ++rep) {
            const double a = cpuNowMs();
            e.process(in.data(), out.data(), n);
            medMs += (cpuNowMs() - a) / 5.0;
        }
        addValue(c, "init_count_before", static_cast<double>(ic0));
        addValue(c, "init_count_after", static_cast<double>(ic1));
        addValue(c, "first_call_ms", firstMs);
        addValue(c, "steady_median_ms", medMs);
        check(c, ic1 == ic0, "first process() constructed the tables");
        check(c, allocs::count() == 0, "allocation during the FIRST process()");
        check(c, firstMs <= 2.0 * medMs + 20.0, "first call much slower than steady");
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        finishCase(R, c);
    }
}

// ---------------------------------------------------------------------------
// Round 13, Priority 1: cold-start alignment
// ---------------------------------------------------------------------------
void casesColdStart(std::vector<CaseResult>& R) {
    const int sr = 48000;
    const double centsList[] = {0.0,  1.0,  -1.0,  10.0, -10.0, 50.0,  -50.0,
                                100.0, -100.0, 500.0, -500.0, 1200.0, -1200.0};
    for (double cents : centsList) {
        CaseResult c{"coldstart"}; c.cpu_t0 = cpuNowMs();
        char tag[32];
        std::snprintf(tag, sizeof(tag), "%+gc", cents);
        c.name = std::string("coldstart_") + tag;
        Config cfg;
        cfg.ratio = semitoneRatio(cents);
        const int n = 3 * sr;
        const auto in = gen::tone(220.0, sr, n, 0.5);
        AlignedDelayLine e;
        e.prepare(cfg);
        std::vector<float> out(n, 0.f);
        e.process(in.data(), out.data(), n);
        const VoiceStats st = e.voiceStats(0);
        // Onset-aware windows (round 13 revision): the honest startup
        // latency is ratio-dependent (at -1200 cents the half-speed read
        // point starts beyond the recorded data and the first valid output
        // arrives ~87 ms in; at +1200 cents the first wrap guard re-anchors
        // early). The artifact windows start after the output's first
        // non-zero sample plus a 10 ms ramp margin.
        int onset = 0;
        while (onset < n && out[onset] == 0.0f) ++onset;
        const int lat = std::max(onset + 480, e.latencySamples());
        addValue(c, "output_onset_sample", onset);
        const int w100 = sr / 10, w1s = sr;
        const double ri100 = meas::rms(in.data() + lat + 480, w100);
        const double ro100 = meas::rms(out.data() + lat + 480, w100);
        const double ri1s = meas::rms(in.data() + lat, w1s);
        const double ro1s = meas::rms(out.data() + lat, w1s);
        const double riSt = meas::rms(in.data() + 2 * sr, sr);
        const double roSt = meas::rms(out.data() + 2 * sr, sr);
        addValue(c, "cents", cents);
        addValue(c, "gain_db_postlat_100ms", 20.0 * std::log10(ro100 / ri100));
        addValue(c, "gain_db_1s", 20.0 * std::log10(ro1s / ri1s));
        addValue(c, "gain_db_steady", 20.0 * std::log10(roSt / riSt));
        const double fm = meas::pitchFFT(out.data() + static_cast<int>(1.5 * sr),
                                         static_cast<int>(1.5 * sr), sr, 50.0, 4000.0);
        addValue(c, "pitch_error_cents", meas::centsBetween(fm, 220.0) - cents);
        const int perW = std::max(2, (int)std::lround(sr / 220.0));
        const double mod = meas::envModulationDb(out.data(), out.size(), sr,
                                                 sr / 5, perW);
        addValue(c, "env_mod_db", mod);
        addValue(c, "first_commit_sample", static_cast<double>(st.last_commit_sample));
        addValue(c, "first_commit_ms",
                 st.last_commit_sample < 0 ? -1.0
                                            : 1000.0 * st.last_commit_sample / sr);
        addValue(c, "splices", static_cast<double>(st.splices));
        addValue(c, "commits", static_cast<double>(st.commits));
        addValue(c, "spacing", st.spacing);
        // continuity: steps AFTER the onset ramp (the onset itself is the
        // legitimate startup event, not a click)
        const int stepFrom = std::min(n - 2, onset + 480);
        addValue(c, "max_step_out", meas::maxStep(out.data(), sr, stepFrom));
        addValue(c, "max_step_in", meas::maxStep(in.data(), sr));
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        check(c, std::abs(meas::centsBetween(fm, 220.0) - cents) <= 2.0,
              "pitch error > 2 cents");
        check(c, 20.0 * std::log10(roSt / riSt) >= -0.1 &&
                  20.0 * std::log10(roSt / riSt) <= 0.1,
              "steady gain outside +-0.1 dB");
        check(c, 20.0 * std::log10(ro1s / ri1s) >= -0.75 &&
                  20.0 * std::log10(ro1s / ri1s) <= 0.75,
              "first-second gain outside +-0.75 dB");
        check(c, 20.0 * std::log10(ro100 / ri100) >= -1.5,
              "post-latency 100 ms gain below -1.5 dB (comb exposure)");
        check(c, meas::maxStep(out.data(), sr, std::min(n - 2, onset + 480)) <=
                      2.5 * meas::maxStep(in.data(), sr) + 1e-4,
              "continuity: output step > 2.5x input step after the onset");
        check(c, mod <= (std::abs(cents) <= 100.0 ? 0.75 : 2.0),
              "envelope modulation too high");
        if (cents == 0.0) {
            check(c, st.parked == 1, "exact unity did not park");
            check(c, st.commits == 0, "unity cold start should not need commits");
        } else {
            check(c, st.commits >= 1, "no alignment commit happened");
            check(c, st.last_commit_sample >= 0 &&
                      st.last_commit_sample <= 60 * (sr / 1000),
                  "first spacing commit later than 60 ms");
            check(c, st.splices <= 3, "more than 3 splice commits (churn)");
        }
        finishCase(R, c);
    }

    {  // reset/restart at each ratio: bit-identical to a fresh engine
        CaseResult c{"coldstart_reset_restart"}; c.cpu_t0 = cpuNowMs();
        int bad = 0;
        for (double cents : centsList) {
            if (cents == 0.0) continue;
            Config cfg;
            cfg.ratio = semitoneRatio(cents);
            const auto in = gen::tone(220.0, sr, 2 * sr, 0.5);
            AlignedDelayLine a, b;
            a.prepare(cfg);
            b.prepare(cfg);
            std::vector<float> oa(2 * sr, 0.f), ob(2 * sr, 0.f), ob2(2 * sr, 0.f);
            a.process(in.data(), oa.data(), 2 * sr);
            b.process(in.data(), ob.data(), 2 * sr);
            b.reset();
            b.process(in.data(), ob2.data(), 2 * sr);
            double d1 = 0.0, d2 = 0.0;
            for (int i = 0; i < 2 * sr; ++i) {
                d1 = std::max(d1, std::abs((double)oa[i] - ob[i]));
                d2 = std::max(d2, std::abs((double)ob[i] - ob2[i]));
            }
            if (d1 != 0.0 || d2 != 0.0) ++bad;
        }
        addValue(c, "ratios_failing", bad);
        check(c, bad == 0, "reset/restart output differs from fresh at some ratio");
        finishCase(R, c);
    }

    {  // reset DURING the splice blend: deterministic restart mid-splice
        CaseResult c{"coldstart_reset_midsplice"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(10.0);
        const auto in = gen::tone(220.0, sr, 2 * sr, 0.5);
        const int split = sr / 12;  // ~83 ms: inside/just after the splice blend
        AlignedDelayLine a, b, fresh;
        a.prepare(cfg);
        b.prepare(cfg);
        fresh.prepare(cfg);
        std::vector<float> oa(2 * sr, 0.f), ob(2 * sr, 0.f), oc(2 * sr, 0.f);
        a.process(in.data(), oa.data(), split);
        a.process(in.data() + split, oa.data() + split, 2 * sr - split);
        b.process(in.data(), ob.data(), split);
        b.reset();
        b.process(in.data() + split, ob.data() + split, 2 * sr - split);
        // a fresh engine fed only the second segment: the ring starts zeroed
        // exactly like the reset engine's, so the outputs must be identical
        fresh.process(in.data() + split, oc.data() + split, 2 * sr - split);
        double dReset = 0.0, dFresh = 0.0;
        for (int i = split; i < 2 * sr; ++i) {
            dReset = std::max(dReset, std::abs((double)ob[i] - oc[i]));
            dFresh = std::max(dFresh, std::abs((double)ob[i] - oa[i]));
        }
        addValue(c, "reset_vs_fresh_second_segment", dReset);
        addValue(c, "continuity_max_diff_vs_uninterrupted", dFresh);
        check(c, dReset == 0.0, "mid-splice reset differs from a fresh restart");
        check(c, meas::allFinite(ob.data(), ob.size()), "non-finite");
        finishCase(R, c);
    }

    {  // signal-type safety at the worst cold case (+10 cents)
        CaseResult c{"coldstart_types_+10c"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(10.0);
        struct Sig { const char* name; std::vector<float> x; };
        std::vector<Sig> sigs;
        sigs.push_back({"chord", gen::chord({196.0, 294.0, 392.0, 494.0}, sr, 2 * sr, 0.6)});
        sigs.push_back({"noise", gen::noise(31, 2 * sr, 0.5)});
        {  // transient bursts: tone with 3 decaying bursts
            std::vector<float> x(2 * sr, 0.0f);
            const auto t = gen::tone(220.0, sr, 2 * sr, 0.4);
            for (int i = 0; i < 2 * sr; ++i) x[i] = t[i];
            for (int b = 0; b < 3; ++b) {
                const int i0 = (b * 2 + 1) * sr / 3;
                for (int i = 0; i < sr / 200 && i0 + i < 2 * sr; ++i)
                    x[i0 + i] += (float)(2.0 * std::exp(-i / 200.0));
            }
            sigs.push_back({"transient", x});
        }
        sigs.push_back({"lowlevel_-60dB", gen::tone(220.0, sr, 2 * sr, 0.001)});
        sigs.push_back({"silence", std::vector<float>(2 * sr, 0.0f)});
        double statMod = 0.0, worstStep = 0.0, lowGainDb = 0.0, noiseGainDb = 0.0;
        int finiteOk = 1, silenceOk = 0;
        for (const auto& s : sigs) {
            AlignedDelayLine e;
            e.prepare(cfg);
            std::vector<float> out(s.x.size(), 0.f);
            e.process(s.x.data(), out.data(), static_cast<int>(s.x.size()));
            if (!meas::allFinite(out.data(), out.size())) finiteOk = 0;
            const double pk = meas::peak(out.data(), static_cast<int>(out.size()));
            if (pk > 2.5) worstStep = 999.0;
            const double so = meas::maxStep(out.data(), static_cast<int>(out.size()));
            const double si = meas::maxStep(s.x.data(), static_cast<int>(s.x.size()));
            worstStep = std::max(worstStep, so / std::max(si, 1e-9));
            const std::string nm(s.name);
            if (nm == "lowlevel_-60dB") {
                // stationary single-period signal: the period-sync envelope
                // metric is meaningful. (The chord's components are
                // non-harmonic -- its envelope beats ~12 dB on its own, so
                // the metric would measure the signal, not the engine.)
                const int perW = std::max(2, (int)std::lround(sr / 220.0));
                statMod = std::max(statMod, meas::envModulationDb(
                    out.data(), static_cast<int>(out.size()), sr, sr / 2, perW));
            }
            if (nm == "noise") {
                // noise: no envelope metric (stationarity), gate RMS instead
                noiseGainDb = 20.0 * std::log10(
                    meas::rms(out.data() + sr, sr) / meas::rms(s.x.data() + sr, sr));
            }
            if (nm == "silence" && pk == 0.0) silenceOk = 1;
            if (nm == "lowlevel_-60dB") {
                const double ro = meas::rms(out.data() + sr, sr);
                const double ri = meas::rms(s.x.data() + sr, sr);
                lowGainDb = 20.0 * std::log10(ro / ri);
            }
        }
        addValue(c, "stationary_env_mod_db", statMod);
        addValue(c, "worst_step_ratio", worstStep);
        addValue(c, "lowlevel_gain_db", lowGainDb);
        addValue(c, "noise_gain_db", noiseGainDb);
        check(c, finiteOk == 1, "non-finite output for some signal type");
        check(c, silenceOk == 1, "silence not passed through silently");
        check(c, worstStep <= 3.5, "output step > 3.5x input step for some type");
        check(c, statMod <= 3.5,
              "stationary-signal envelope modulation > 3.5 dB");
        // Noise through the dual-tap blend: the two taps are uncorrelated,
        // so the power-complementary blend yields ~-3.0 dB RMS (plus
        // interpolator loss) -- the design's documented behaviour, the same
        // class as the Python v2 reference. Gate the documented class.
        check(c, noiseGainDb >= -4.5 && noiseGainDb <= -1.5,
              "noise RMS outside the documented dual-tap blend class "
              "[-4.5, -1.5] dB");
        check(c, lowGainDb >= -1.0 && lowGainDb <= 1.0,
              "low-level tone gain outside +-1 dB");
        finishCase(R, c);
    }

    {  // unity <-> non-unity round trip with continuity gates
        CaseResult c{"coldstart_unity_roundtrip"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.ratio = semitoneRatio(50.0);
        AlignedDelayLine e;
        e.prepare(cfg);
        const int seg = sr;  // 1 s each
        const auto in = gen::tone(220.0, sr, 3 * seg, 0.5);
        std::vector<float> out(3 * seg, 0.f);
        e.process(in.data(), out.data(), seg);              // +50 c
        e.setRatio(1.0);
        e.process(in.data() + seg, out.data() + seg, seg);  // unity
        e.setRatio(semitoneRatio(-50.0));
        e.process(in.data() + 2 * seg, out.data() + 2 * seg, seg);  // -50 c
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        // continuity across both transitions (60 ms windows)
        double worst = 0.0;
        for (int t = 0; t < 2; ++t) {
            const int i0 = (t + 1) * seg;
            const int w = static_cast<int>(0.06 * sr);
            const double step = meas::maxStep(out.data() + i0, w);
            const double stepBefore = meas::maxStep(out.data() + i0 - w, w);
            worst = std::max(worst, step / std::max(stepBefore, 1e-9));
        }
        addValue(c, "worst_transition_step_ratio", worst);
        check(c, worst <= 2.5, "transition click (step > 2.5x pre-transition)");
        // pitch sanity on the first segment
        const double fm = meas::pitchFFT(out.data() + sr / 2, sr / 2, sr, 50.0, 4000.0);
        addValue(c, "seg1_pitch_error_cents", meas::centsBetween(fm, 220.0) - 50.0);
        check(c, std::abs(meas::centsBetween(fm, 220.0) - 50.0) <= 2.0,
              "pitch error > 2 cents before the transitions");
        finishCase(R, c);
    }
}

// ---------------------------------------------------------------------------
// Round 13, Priority 2: sample-rate robustness
// ---------------------------------------------------------------------------
void casesRates(std::vector<CaseResult>& R) {
    const int rates[] = {44100, 48000, 96000, 192000};
    const double freqs[] = {55.0, 60.0, 80.0, 110.0, 220.0, 440.0};

    // detector capability report + gates
    {
        CaseResult c{"detector_info"}; c.cpu_t0 = cpuNowMs();
        int rangeOk = 0;
        for (int sr : rates) {
            Config cfg;
            cfg.sample_rate = sr;
            AlignedDelayLine e;
            e.prepare(cfg);
            const DetectorInfo di = e.detectorInfo();
            char key[32];
            std::snprintf(key, sizeof(key), "sr%d", sr);
            addValue(c, (std::string(key) + "_analysis_rate").c_str(), di.analysis_rate);
            addValue(c, (std::string(key) + "_decimation").c_str(), di.decimation);
            addValue(c, (std::string(key) + "_fmin_eff").c_str(), di.fmin_effective);
            addValue(c, (std::string(key) + "_fmax_eff").c_str(), di.fmax_effective);
            addValue(c, (std::string(key) + "_control_interval").c_str(), di.control_interval);
            addValue(c, (std::string(key) + "_window").c_str(), di.window_samples);
            const bool ok = di.fmin_effective <= 55.0 && di.fmax_effective >= 1200.0 &&
                            di.control_interval == 64 && di.window_samples == 2048 &&
                            (sr <= 48000 ? di.decimation == 1 : di.decimation > 1);
            if (ok) ++rangeOk;
        }
        addValue(c, "rates_with_full_range", rangeOk);
        check(c, rangeOk == 4, "detector range incomplete at some rate");
        finishCase(R, c);
    }

    // frequency battery at +400 cents at every rate
    for (int sr : rates) {
        for (double f : freqs) {
            CaseResult c{"rate"}; c.cpu_t0 = cpuNowMs();
            char tag[64];
            std::snprintf(tag, sizeof(tag), "rate_%d_%.0fHz_+400c", sr, f);
            c.name = tag;
            Config cfg;
            cfg.sample_rate = sr;
            cfg.ratio = semitoneRatio(400.0);
            const int n = 3 * sr / 2;
            const auto in = gen::tone(f, sr, n, 0.5);
            AlignedDelayLine e;
            e.prepare(cfg);
            std::vector<float> out(n, 0.f);
            e.process(in.data(), out.data(), n);
            const double fm = meas::pitchFFT(out.data() + sr / 2, n - sr / 2,
                                             sr, 30.0, 6000.0);
            const double estErr = (e.lastEstimateHz() > 0.0)
                ? meas::centsBetween(e.lastEstimateHz(), f) : 999.0;
            addValue(c, "pitch_error_cents", meas::centsBetween(fm, f) - 400.0);
            addValue(c, "estimate_error_cents", estErr);
            addValue(c, "last_estimate_hz", e.lastEstimateHz());
            addValue(c, "spacing", e.voiceStats(0).spacing);
            check(c, meas::allFinite(out.data(), out.size()), "non-finite");
            check(c, std::abs(meas::centsBetween(fm, f) - 400.0) <= 2.0,
                  "pitch error > 2 cents");
            check(c, std::abs(estErr) <= 5.0, "detector estimate off by > 5 cents");
            finishCase(R, c);
        }
    }

    // negative shift at 96 kHz (349.23 Hz expected from 440 Hz input)
    {
        CaseResult c{"rate_96000_-400c_440Hz"}; c.cpu_t0 = cpuNowMs();
        Config cfg;
        cfg.sample_rate = 96000.0;
        cfg.ratio = semitoneRatio(-400.0);
        const int sr = 96000;
        const int n = 3 * sr / 2;
        const auto in = gen::tone(440.0, sr, n, 0.5);
        AlignedDelayLine e;
        e.prepare(cfg);
        std::vector<float> out(n, 0.f);
        e.process(in.data(), out.data(), n);
        const double fm = meas::pitchFFT(out.data() + sr / 2, n - sr / 2, sr,
                                         200.0, 900.0);
        addValue(c, "pitch_error_cents", meas::centsBetween(fm, 440.0) + 400.0);
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        check(c, std::abs(meas::centsBetween(fm, 440.0) + 400.0) <= 2.0,
              "pitch error > 2 cents");
        finishCase(R, c);
    }

    // non-periodic input at every rate: safe, bounded, honest report
    for (int sr : rates) {
        CaseResult c{"rate"}; c.cpu_t0 = cpuNowMs();
        char tag[64];
        std::snprintf(tag, sizeof(tag), "rate_%d_noise", sr);
        c.name = tag;
        Config cfg;
        cfg.sample_rate = sr;
        cfg.ratio = semitoneRatio(400.0);
        const int n = sr;
        const auto in = gen::noise(9, n, 0.5);
        AlignedDelayLine e;
        e.prepare(cfg);
        std::vector<float> out(n, 0.f);
        e.process(in.data(), out.data(), n);
        const double pk = meas::peak(out.data(), n);
        addValue(c, "peak", pk);
        addValue(c, "last_estimate_hz", e.lastEstimateHz());
        addValue(c, "splices", static_cast<double>(e.voiceStats(0).splices));
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        check(c, pk < 2.0, "peak too high for noise input");
        finishCase(R, c);
    }

    // per-rate processing cost (reported, not gated -- machine-dependent;
    // the release benchmark is the canonical performance evidence)
    for (int sr : rates) {
        CaseResult c{"rate"}; c.cpu_t0 = cpuNowMs();
        char tag[64];
        std::snprintf(tag, sizeof(tag), "rate_%d_cost_220Hz_1voice", sr);
        c.name = tag;
        Config cfg;
        cfg.sample_rate = sr;
        cfg.ratio = semitoneRatio(400.0);
        const int n = sr / 2;
        const auto in = gen::tone(220.0, sr, n, 0.5);
        AlignedDelayLine e;
        e.prepare(cfg);
        std::vector<float> out(n, 0.f);
        const double t0 = cpuNowMs();
        e.process(in.data(), out.data(), n);
        const double ms = cpuNowMs() - t0;
        addValue(c, "cpu_ms", ms);
        addValue(c, "ns_per_sample", ms * 1e6 / n);
        addValue(c, "realtime_factor", (n / (double)sr) / (ms / 1e3));
        check(c, meas::allFinite(out.data(), out.size()), "non-finite");
        finishCase(R, c);
    }
}

// ---------------------------------------------------------------------------
// JSON report
// ---------------------------------------------------------------------------
std::string jsonEscape(const std::string& s) {
    std::string o;
    for (char ch : s) {
        if (ch == '"' || ch == '\\') {
            o += '\\';
            o += ch;
        } else if (ch == '\n') {
            o += "\\n";
        } else {
            o += ch;
        }
    }
    return o;
}

void writeJson(const std::string& path) {
    std::string j = "{\n  \"suite\": \"octavox_native_tests\",\n  \"version\": \"";
    j += versionString();
    j += "\",\n  \"cases\": [\n";
    int idx = 0;
    for (const auto& c : g_results) {
        j += "    {\"name\": \"" + jsonEscape(c.name) + "\", \"pass\": " +
             (c.pass ? "true" : "false") + ", \"duration_ms\": " +
             [&]{ char b[32]; std::snprintf(b, sizeof(b), "%.3f", c.duration_ms);
                  return std::string(b); }() + ", \"note\": \"" +
             jsonEscape(c.note) + "\", \"values\": {";
        for (size_t i = 0; i < c.values.size(); ++i) {
            char buf[64];
            std::snprintf(buf, sizeof(buf), "%.10g", c.values[i].second);
            j += "\"" + jsonEscape(c.values[i].first) + "\": " + buf;
            if (i + 1 < c.values.size()) j += ", ";
        }
        j += "}}";
        if (++idx < (int)g_results.size()) j += ",";
        j += "\n";
    }
    int passed = 0;
    for (const auto& c : g_results) passed += c.pass ? 1 : 0;
    double total_ms = 0.0;
    for (const auto& c : g_results) total_ms += c.duration_ms;
    char tbuf[32];
    std::snprintf(tbuf, sizeof(tbuf), "%.3f", total_ms);
    j += "  ],\n  \"summary\": {\"total\": " + std::to_string(g_results.size()) +
         ", \"passed\": " + std::to_string(passed) + ", \"failed\": " +
         std::to_string(g_results.size() - passed) + ", \"cpu_ms\": " + tbuf +
         "}\n}\n";
    FILE* f = std::fopen(path.c_str(), "wb");
    if (f) {
        std::fwrite(j.data(), 1, j.size(), f);
        std::fclose(f);
    }
}

// ---------------------------------------------------------------------------
int main(int argc, char** argv) {
    std::string jsonPath;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--json") == 0 && i + 1 < argc)
            jsonPath = argv[++i];
    }

    // Round 13: the real-time-safety group runs FIRST so its first-call
    // measurements are this process's actual first prepare()/process().
    casesRealtimeSafety(g_results);
    casesPrepareReset(g_results);
    casesUnity(g_results);
    casesVoices(g_results);
    casesStereo(g_results);
    casesRatesFormats(g_results);
    casesStability(g_results);
    casesColdStart(g_results);
    casesRates(g_results);
    {  // final tripwire: the tables were constructed exactly once for the
       // whole process and never inside process()
        CaseResult c{"tables_never_rebuilt"}; c.cpu_t0 = cpuNowMs();
        addValue(c, "init_count", static_cast<double>(diagnostics::interpTableInitCount()));
        addValue(c, "init_during_process",
                 static_cast<double>(diagnostics::interpTableInitDuringProcess()));
        check(c, diagnostics::interpTableInitCount() == 1,
              "interpolation tables constructed more than once");
        check(c, diagnostics::interpTableInitDuringProcess() == 0,
              "table construction inside process()");
        finishCase(g_results, c);
    }

    int passed = 0, failed = 0;
    std::printf("%-46s %-6s %s\n", "CASE", "PASS", "MEASUREMENTS (selected)");
    std::printf("%s\n", std::string(100, '-').c_str());
    for (const auto& c : g_results) {
        if (c.pass) ++passed; else ++failed;
        std::printf("%-46s %-6s %s\n", c.name.c_str(), c.pass ? "ok" : "FAIL",
                    c.note.c_str());
        for (const auto& v : c.values)
            std::printf("%-46s %-6s %s = %.10g\n", "", "", v.first.c_str(),
                        v.second);
    }
    std::printf("%s\n%s: %d passed, %d failed, %d total\n",
                std::string(100, '-').c_str(), versionString(), passed, failed,
                (int)g_results.size());

    if (!jsonPath.empty()) writeJson(jsonPath);

    return failed == 0 ? 0 : 1;
}
