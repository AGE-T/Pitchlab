# OCTAVOX — VST3 READINESS ASSESSMENT (Round 14, Priority 4)

Grounded **only** in the actual API (`include/octavox/dsp.hpp`, version
13.0.0), the measured quality (round 13/14 evidence), and the toolchain
present in this environment. **No wrapper is built this round** — this
document is the readiness assessment the round-14 mandate asked for, and the
explicit decision is to complete the parameter surface first (Phase A below)
so that a future wrapper is a real implementation, not a placeholder.

## 1. What the core already provides (verified, not claimed)

| capability | evidence |
|---|---|
| Block-based RT processing, allocation-free steady state (incl. the FIRST process call) | round-13 P3 gates (`first_process_clean`, armed global-new counter); round-14 re-run 105/105 |
| Deterministic, restartable state (reset = fresh, cold start re-runs alignment deterministically) | `reset_restart_*` cases, bit-identical |
| Latency reporting | `latencySamples()` = base + grain/2 |
| 1..8 voices per engine, N engines per channel with structural isolation | `MultichannelShifter`; stereo leakage exactly 0 (r14_interp_compare §7) |
| Pitch accuracy / gain / modulation floors | cold-start ≤ 0.018 c across the cent matrix, steady gain ≤ 0.003 dB, env-mod ≤ 0.03 dB stationary (r14 unified re-measurement); THD+N at unity −153 dB (interp comparison) |
| Detector range & rate robustness | [54.4, 1200] Hz at 44.1/48/96/192 kHz; block-size invariant |
| Interpolation modes incl. the target's observed kernel | 4 modes measured head-to-head (round 14 P3) |
| Cost | 48 kHz worst-case (noise, no detector early-exit): ~920 ns/frame 1-voice (22.7× RT), ~1125 ns/frame 8-voice (18.5× RT) — comfortable for real-time |

## 2. The parameter-surface gaps for a practical eight-voice harmonizer

Against the harmonizer feature set (and, for reference, the original's own
port surface recovered statically: per-voice `shift1..8`/`mod1..8`, global
`gatelevel/minpitch/pitchtracking/xfadetime/tune/scale/key/...`,
CONTROL_FLOW_MATRIX §10):

| # | feature | current API | gap |
|---|---|---|---|
| 1 | **Independent voice intervals** | one global `Config::ratio` + a fixed internal `spread` table | `setVoiceRatio(v, ratio)` missing. The engine's per-voice state already carries a per-voice ratio internally (`VoiceState::ratio`), so this is an API/normalisation change, not a redesign |
| 2 | **Per-voice level / mute** | none | needs per-voice gain with ramping (the voice-count normalisation ramp shows the pattern) |
| 3 | **Per-voice delay** | single global `base_delay` (first voice); spread staggers internally | needs per-voice base-delay control |
| 4 | **Feedback routing** | one global `feedback` coefficient per engine | per-voice feedback routing absent; global behaviour documented and gated (60-s stability case) |
| 5 | **Wet/dry mix** | none (core is wet-only) | needs dry path + equal-power mix, or wrapper-side mixing (wrapper-side is acceptable; document latency compensation of the dry path = `latencySamples()`) |
| 6 | **Bypass** | none | click-free bypass needs a short crossfade — wrapper-side ramping possible, core-side is cleaner |
| 7 | **Parameter smoothing for automation** | `setRatio` etc. apply immediately; engine-internal spacing glide/ghost handles the transition (unity↔non-unity roundtrip steps ≤ 2.5×) | abrupt large automation jumps are not slewed at the parameter level; add explicit slew or document sample-accurate application |
| 8 | **Per-voice random/periodic modulation** (the original's `mod1..8`) | none | optional for a first demo; the round-9 static law (4·P(f)·ratio·correction) is already reproduced in the Python reference if ever needed |
| 9 | **State persistence** | `reset()` only; no serialisation | VST3 getState/setState can snapshot `Config` (+ re-prepare deterministically); engine-state snapshot is optional (cold-start alignment re-runs — 45 ms) |
| 10 | **Denormals** | no explicit FTZ/DAZ guards in the library | rely on host FTZ or add `_MM_SET_FLUSH_ZERO_MODE` in prepare (documented risk, not observed as a cost issue in the benchmarks) |

**Verdict:** the core is *quality-ready* but **not parameter-surface-ready**
for an eight-voice harmonizer demo. Items 1–3 and 5–6 are the minimum set;
none of them is architecturally hard (the per-voice state structure exists),
but they change the API and therefore belong in a dedicated round with gates
(per-voice interval isolation, level accuracy, click-free sweeps), not as a
side effect of wrapper work.

## 3. Toolchain status (verified in this sandbox)

* **CMake 4.4.4** — satisfies the VST3 SDK's requirement (recent CMake,
  ≥ 3.19-class features).
* **GCC 14.2, C++17** — satisfies the SDK's C++17 requirement.
* **VST3 SDK**: **not present locally**; the canonical repository
  `github.com/steinbergmedia/vst3sdk` is **reachable from this environment
  (HTTP 200, verified 2026-10-26)**, so a pinned-commit fetch is feasible
  when the wrapper round starts. Licensing: dual GPLv3 / Steinberg
  proprietary agreement — GPLv3 is compatible with this project's research
  distribution.
* **Validation without a DAW**: the SDK's `validator` and `hostemu` targets
  run headless on Linux — sufficient for conformance gates (bus negotiation,
  parameter ranges, state round-trip, process-cycle checks) inside this
  sandbox. Real-DAW verification (REAPER/Windows) remains outside the
  sandbox and would be the final acceptance step elsewhere.
* **JUCE or other frameworks**: deliberately not part of the stack; a direct
  vst3sdk integration keeps the dependency surface minimal.

## 4. Concrete implementation plan (when the milestone is scheduled)

* **Phase A — parameter surface (in our repo, no SDK needed):**
  per-voice ratio/level/delay setters, wet/dry, bypass crossfade, optional
  per-voice feedback; extend the acceptance suite with per-voice gates
  (interval isolation per voice, level accuracy ±0.1 dB, click-free
  parameter changes at block boundaries, spread-table regression). Deliver
  the updated API + suite + before/after benchmarks, exactly per this
  round's discipline.
* **Phase B — wrapper (vst3sdk):** single-processor component with an
  edit controller; 2-in/2-out (with an optional 1-in/2-out mode using one
  engine + a MonoToStereo adapter, mirroring the original's
  mimo/miso/siso profiles); parameters mapped 1:1 onto the Phase-A API with
  sample-accurate application; `setLatencySamples(latencySamples())`;
  state = `Config` snapshot (deterministic re-prepare); built behind
  `-DBUILD_VST3=ON` (default OFF so the standalone library build stays
  dependency-free); gates: SDK validator clean + hostemu process cycles +
  parameter/state round-trips.
* **Phase C — host verification** (outside this sandbox): DAW matrix
  (Windows REAPER class), latency/compensation checks, CPU at 96/192 kHz.

## 5. Explicit non-claims

Nothing in the core or a future wrapper reproduces the original plugin's
runtime behaviour; the `ObsKernel6` mode uses statically observed data for
research comparison only and is not the default (round-14 P3 measured it
worse on THD+N and noise tilt than the Lagrange6 default). The original was
never executed in this project.
