# OCTAVOX Native DSP Core — Architecture Note (Round 13)

This note covers state, memory ownership, threading, channel isolation and
limitations of the round-13 native core (`native/`, C++17). It is part of the
round-13 evidence; the research context is in `OCTAVOX_ROUND13_FINDINGS.md`.
Round-12 note: the sections marked *(r12)* are unchanged behaviour; the
round-13 changes are marked *(r13)*.

## What this is (and is not)

* **Is**: our own independent implementation of the round-11
  `delayline_aligned` design (ported in round 12 from
  `poc/octavox_v2.py`, preserved untouched as the Python reference
  baseline), plus the round-12 unity engagement and the round-13
  robustness work (cold-start splice alignment, decimated detector,
  prepare-time table initialisation).
* **Is not**: a VST3 plugin, a wrapper for the original Eventide Octavox, or a
  claim about the original's runtime behaviour. The target was never executed.
  The single exception to "our own code" is documented **data**: the optional
  `Interpolation::ObsKernel6` mode embeds the 256×6 float kernel table
  **observed** in the target's `.rdata` (`src/obs_kernel_table.h`, extraction
  script `evidence/analysis_round12/r12_interp_table.py`) for research
  comparison. That mode is opt-in; the default interpolator is our own
  6-point Lagrange table.

## Object model

```
octavox::AlignedDelayLine      one mono engine, 1..max_voices voices
octavox::MultichannelShifter   N AlignedDelayLine engines, one per channel
```

`MultichannelShifter` owns one `AlignedDelayLine` **per channel**. Channel
isolation is therefore structural (r12): measured bit-identical whether or
not the other channel is processed.

## Lifecycle and memory ownership

| phase | allocates | notes |
|---|---|---|
| `prepare(cfg)` | yes | ring (2^18 doubles = 2 MiB/engine), voice state, detector window + work arrays, decimator taps/history (r13), control accumulator. **Also initialises the shared interpolation tables** (r13: exactly once per process, via an explicit `std::call_once` on the preparation path — `process()` never constructs or guards anything). |
| `reset()` | no | zeroes the ring and all state (including the r13 cold-start/ghost/decimator state, so a restart re-runs the early alignment deterministically); parameters keep their values. |
| `setRatio/setVoices/setSpread/setFeedback` | no | scalar writes + precomputed per-voice targets. |
| `process()` | **no** | steady state is allocation-free — gated by the `steady_state_no_allocation` case AND the `first_process_clean` case (r13: zero allocations on the FIRST call too). |

Single-threaded audio-thread model (r12): no locks, no atomics, no blocking
calls anywhere in `process()`. The one-time table construction is the only
historically expensive initialisation and it now lives in `prepare()`
(r13, gated by `tables_init_at_prepare` / `tables_never_rebuilt` /
`first_process_clean`).

## Per-voice state

(r12) `ratio_t`/`ratio` (geometric glide 0.9995/sample), `base_delay`
(256 + 32·v), `frac` (grain phase), `S` (tap spacing, committed at wraps with
0.5 % hysteresis from the median-smoothed period estimate), the unity
engagement pair `e`/`a`, `d_park`.

(r13) additionally: the **splice ghost** (`g_active`, `g_blend`, `g_frac`,
`g_S`, `g_ratio`) — a dying copy of the pre-commit machine — and the
per-voice misalignment tracking (`misalign_run`, `last_splice_pos`) that
drives the splice commit. `voiceStats()` returns a `VoiceStats` **by value**
(r13; the r12 const-ref API returned thread-local scratch).

## The unity engagement (r12, unchanged)

Per voice, when the target ratio is **bit-exactly 1.0**, the two-tap blend
morphs to tap A alone over `engagement_seconds` (10 ms), then parks on the
nearest **integer** delay — a bit-exact delayed copy. Departure reverses the
morphs and commits the period-aligned spacing when the read point is
preserved. No bypass region (±1 cent is fully processed).

## The cold-start splice alignment (r13)

Round 12 kept the v2 rule "S commits only at grain wraps"; a fresh near-unity
engine never wraps (first wrap minutes away at ±1 cent), so the static
two-tap comb persisted (measured −2.41 dB at 220 Hz / ±1 cent; first commit:
never — the round-12 documented defect). The round-13 splice commit:

* **Trigger** (control rate): a voice whose spacing is misaligned by more
  than `align_threshold_periods` input periods (default 0.05 ⇒ worst
  frozen-weight gain error −0.019 dB) for `align_persist` consecutive
  estimates (default 3), while in the dual-tap regime, with an
  `align_cooldown` (default 4096 samples) between commits. The candidate
  target must itself be aligned (the [G/2, 1.5G] clamp can leave it
  misaligned for extreme period/grain combinations — no churning commits).
* **Commit**: snapshot the old machine as the ghost, commit `S ← S_target`
  with tap A's read point preserved exactly (`frac_new = frac·S_old/S_new`,
  integer re-wraps hidden under the blend); blend ghost → committed over
  `engagement_seconds`. Both endpoints are exact and the blend is convex,
  so the splice is continuous by construction. Non-periodic input (no
  accepted estimate) never triggers it.
* **Startup wrap guard** (r>1): when a wrap's hand-off target (d + S) is
  beyond the recorded data (large positive shifts at cold start — measured
  at +1200 cents: wrap at sample 2048 jumping to delay 4352 ⇒ 24 ms of
  digital silence in round 12), the voice re-anchors inside the recorded
  data, **content-aligned to the continuing read** when a period estimate
  exists (`d_new = d_ghost + m·T̂`), and the ghost carries the short
  transition.
* **B-tap readiness** (r13): at cold start the B tap (delay ≈ base + S)
  reads the zero-filled region of the ring until enough samples have been
  pushed; the complementary blend summed real data with zeros, halving the
  amplitude for ~90 ms (measured −3.8 dB over the first 100 ms after
  latency). While the B data has not arrived the voice runs as the natural
  single-tap A path; a 128-sample convex crossfade hands over to the
  dual-tap blend as the data arrives. Convexity bounds the output (no gain
  overshoot) and once readiness is 1 the code path is bit-identical to the
  round-12 arithmetic.

## Control rate and block-size invariance (r12 + r13)

The detector fires every `detection_interval` **stream** samples; the r13
decimator's phase follows the absolute stream position, so the output is
invariant to how the caller splits the stream into blocks (gated to exactly
0 difference). Documented delta vs the Python (r12): the control timing
lags the reference's intra-block look-ahead by at most one interval.

## The pitch detector (r13 revision)

* **Decimated analysis path**: above `analysis_rate_max` (default 48000 Hz)
  the detector consumes a polyphase-FIR-decimated copy of the input
  (63-tap Blackman-windowed sinc, cutoff 0.45·analysis Nyquist, DC gain
  exactly 1, designed in `prepare()`). 44.1/48 kHz analysis is a bit-exact
  passthrough (no filtering). The detector's window length in *time*
  (2048 analysis samples ≈ 42.7 ms), frequency range and cold-start timing
  are therefore rate-invariant: 96 kHz measures identically to 48 kHz
  (verified — the rate battery's values coincide).
* **Config-driven range**: `tau_min = sr/fmax − 4`, `tau_max =
  min(window/2 − 32, ceil(sr/fmin) + 8)` with edge-reliability rejection
  (a selected lag on the tau_max boundary is the clipped-period signature —
  a 50 Hz input at 48 kHz is rejected instead of reported as ~55 Hz; the
  r12 code accepted it). A populated-window guard rejects the degenerate
  partially-filled-window estimates (an all-zero difference segment
  reported sr/tau_min — 1200 Hz — on any cold input).
* **Valley selection**: the first point below the 0.20 threshold enters a
  candidate valley; the walk follows it while the curve stays below
  1.5× the deepest point seen, selecting that deepest point. This skips the
  shallow cos² ripple that the finite overlap (m ≪ T at low f0) puts on the
  CMND descent (measured: a spurious sub-threshold local minimum at 0.7
  periods on a 55 Hz tone, which the round-12 first-local-minimum rule
  selected instead of the true 0.0000 minimum), while the inter-period
  ridges (cmnd ≈ 1) can never satisfy the merge bar, so octave errors
  cannot be introduced.
* **Fused with early exit**: the difference/CMND/selection passes are one
  loop that stops at the selected valley — numerically identical results
  to the r12 two-pass form (the per-lag accumulation order is unchanged),
  ~3.7× cheaper on periodic input (measured 915 → 250 ns/sample at 48 kHz,
  1 voice). Noise (no sub-threshold valley) always pays the full scan.

`DetectorInfo detectorInfo()` reports what the detector ACTUALLY supports
for the prepared configuration (analysis rate, decimation, window, tau
range, effective fmin/fmax, control interval); tests gate on the REPORTED
range so unsupported configurations cannot hide behind permissive gates.

## Threading

One engine = one thread (r12). The shared interpolator tables are immutable
after the first `prepare()` (r13: explicit initialisation, no lazy guards).
`voiceStats()` returns by value (r13) — no thread-local scratch.

## Limitations (honest list)

* (r13) At extreme positive shifts from a cold start the first wrap is
  causality-limited (the read point outruns the recording); the guard
  re-anchors content-aligned and the transition is a ~2.5-ms ghost blend.
  Measured: first-second output steps ≤ 2× the input's natural step at
  +1200 cents.
* (r13) Noise through the dual-tap blend loses ~3.0 dB RMS (the two taps
  are uncorrelated, so the power-complementary blend yields half the
  power) plus interpolator loss — the design's documented behaviour, the
  same class as the Python v2 reference. Gated in
  `coldstart_types_+10c` at [−4.5, −1.5] dB.
* (r13) Chords with non-harmonic components beat on their own; the
  period-sync envelope metric is only gated for stationary single-period
  signals (the chord's own beating is the signal, not the engine).
* (r12, unchanged) Multi-voice unison at unity parks each voice at its own
  integer delay (an exact multi-tap FIR sum of delayed copies);
  feedback at unity is a stable single-tap comb for |fb| < 1.
* (r12, unchanged) No dither in the CLI's 16-bit writer; the write/read
  asymmetry (round(y·32767) then ÷32768) is the reference's own convention.
* The detector dominates the cost at the default 64-sample control interval
  on noise input (measured 68 % of the ctrl-64 cost); periodic input pays
  ~3.7× less (the early exit). A sparse control interval (512) runs the
  voice path alone.

## Build and test

See `native/README.md`. Release tests: 105/105; ASan+UBSan build: 105/105
with zero sanitizer reports; benchmark and cross-language metrics are
machine-readable JSON in `evidence/analysis_round13/`.

## Round-14 note (measurement discipline only)

No architectural change this round: the core, its real-time guarantees and
its cold-start alignment are exactly the round-13 design (version string
bumped to 14.0.0). Round 14 delivered measurement corrections and
benchmarking around it: the suite meter's window-placement fix (see
`tests/test_main.cpp`), the unified cold-start harness (engine commit sample
vs block-observation; both meters co-reported), and the four-mode
interpolation comparison (`bench/interp_compare.cpp`) whose decision is to
keep `Interpolation::Lagrange6` as the default — the observed-kernel mode
stays opt-in research parity. See `OCTAVOX_ROUND14_FINDINGS.md` §4.
