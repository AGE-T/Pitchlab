# OCTAVOX Native DSP Core (Round 12)

Our own C++17 port of the round-11 `delayline_aligned` design plus the
round-12 unity engagement fix. **Not a VST3 plugin and not a reproduction of
the original plugin's runtime behaviour** — see `ARCHITECTURE.md` for the
full note (state, memory ownership, threading, channel isolation,
limitations) and `../docs/OCTAVOX_ROUND12_FINDINGS.md` for the research
context.

## Layout

```
include/octavox/dsp.hpp   public API (AlignedDelayLine, MultichannelShifter)
src/dsp.cpp               implementation
src/obs_kernel_table.h    OBSERVED target .rdata kernel (opt-in mode; data, not code)
tests/test_main.cpp       correctness + unity regression suite (51 cases)
tests/wav_io.*            WAV I/O (harness only; mirrors the Python CLI)
tests/alloc_counter.cpp   global-new counter for the no-alloc gate
bench/bench_main.cpp      release benchmark (deterministic LCG input)
cli/octavox_cli.cpp       WAV->WAV demo CLI (cross-language metrics driver)
```

## Build

Requires CMake ≥ 3.16 and a C++17 compiler (developed with GCC 14.2).

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

Sanitizer build (address + undefined):

```sh
cmake -S . -B build-asan -DCMAKE_BUILD_TYPE=Debug -DENABLE_SANITIZERS=ON
cmake --build build-asan -j
```

## Test / benchmark

```sh
./build/octavox_tests --json results.json      # exit 0 = all pass
./build-asan/octavox_tests --json results_asan.json
./build/octavox_bench --json bench.json
./build/octavox_cli --in ../poc/example_input.wav --out out.wav --cents 400 --voices 3
```

The authoritative cross-language measurements (native vs the preserved Python
reference) are produced by
`../evidence/analysis_round12/r12_native_metrics.py`.

## Recorded results (this round's environment)

* `octavox_tests` (release): **51/51 pass** — unity bit-exactness (tones,
  noise, chord, silence, low level, arrival from a shift), the cent battery
  (0, ±1, ±10, ±50, ±100, ±500, ±1200), 1/8 voices, mono/stereo, channel
  isolation, block-size invariance, repeated prepare, reset determinism,
  long runs, NaN/clip gates, steady-state allocation-freedom.
* ASan+UBSan build: **51/51 pass, zero sanitizer reports**.
* Benchmark (mono 48 kHz, +4 st, LCG noise, best of 3): ≈ 15× realtime
  (1 voice) / ≈ 13.8× (8 voices) at the default 64-sample control interval;
  ≈ 51× realtime with the interval at 512 (the YIN detector is ~73 % of the
  cost). Zero steady-state allocations. Stereo ≈ 6.7× realtime.
* Cross-language (identical input): the Python reference runs at 0.42×
  (1 voice) / 0.25× (8 voices) realtime — the native core is ≈ 35–55× faster
  on the same machine.

---

# Round 13

The core gained three robustness fixes (see `../docs/OCTAVOX_ROUND13_FINDINGS.md`
for the full evidence):

1. **Cold-start alignment (splice commit)**: a fresh engine commits the
   period-aligned tap spacing as soon as a reliable estimate exists (~45 ms
   at 48 kHz) instead of waiting for a possibly distant first grain wrap.
   The commit is continuity-preserving (a "ghost" of the old machine
   crossfades out over 10 ms), and a B-tap readiness ramp keeps the output
   at full amplitude while the second tap's data has not been recorded yet.
2. **Sample-rate robustness**: the pitch detector runs on a decimated copy
   of the input above 48 kHz (polyphase FIR, analysis rate <= 48000), so
   88.2/96/176.4/192 kHz support the same [55, 1200] Hz detector range and
   the same cold-start timing as 44.1/48 kHz. The detector's lag range is
   config-driven with edge reliability rejection.
3. **Deterministic real-time preparation**: the interpolation tables are
   built by the first `prepare()` (once per process); `process()` contains
   no lazy construction, no thread-safe-static guards, no allocation
   (gated by tests).

The suite grew to 105 cases (cold-start matrix, rate battery, real-time
safety, per-case CPU timing). The benchmark was FIXED in this round: the
round-12 harness re-processed the first block instead of advancing the
input pointers (see the findings doc, section "harness bug"); all
performance numbers are re-measured.

```sh
# full validation (release + sanitizers + benchmark)
cmake --build build -j
./build/octavox_tests --json ../evidence/analysis_round13/r13_native_tests.json
cmake -S . -B build-asan -DCMAKE_BUILD_TYPE=Debug -DENABLE_SANITIZERS=ON
cmake --build build-asan -j
./build-asan/octavox_tests --json ../evidence/analysis_round13/r13_native_tests_asan.json
./build/octavox_bench --json ../evidence/analysis_round13/r13_native_bench.json
```

---

## Round 14 (version 14.0.0)

* The DSP core is **functionally unchanged** (the only edit: the version
  string 13.0.0 → 14.0.0; CMake project version 14.0.0).
* `tests/test_main.cpp`: the FFT pitch meter's **window-placement fix** —
  `off = n − N` went negative for non-power-of-two windows and read before
  the handed pointer; now the window zero-pads ("newest N samples"
  semantics). Verdicts unchanged: 105/105, identical to round 13.
* New target **`octavox_interp_compare`** (`bench/interp_compare.cpp`): the
  four interpolation modes measured head-to-head on identical deterministic
  signals (pitch/gain/env-mod/THD+N/chord/transient/noise/stereo/
  multivoice/CPU/memory, meter self-check first). Result: the default
  **Lagrange6 stays** (details in `../evidence/analysis_round14/
  r14_interp_compare.txt`).
* **`VST3_READINESS.md`**: the parameter-surface gap analysis for an
  eight-voice harmonizer + the three-phase wrapper plan (no wrapper built).

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
./build/octavox_tests --json ../evidence/analysis_round14/r14_native_tests.json      # 105/105
./build/octavox_interp_compare --json ../evidence/analysis_round14/r14_interp_compare.json
```
