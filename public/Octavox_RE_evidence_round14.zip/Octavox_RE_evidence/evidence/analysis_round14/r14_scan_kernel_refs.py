#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OCTAVOX round 14 -- kernel origin scan: is the 256x6-float interpolation
kernel at 0x1803B6170..0x1803B7970 (i) runtime-generated, (ii) copied from
another constant, or (iii) embedded precomputed data?

Method (all static, read-only; target never executed; sha256 verified):
  1. SECTION 1: linear disassembly of every .pdata chunk + inter-chunk gap;
     every rip-relative operand whose target lands INSIDE the table range is
     reported with its containing .pdata chunk and a disassembly window
     (read-only lookup vs store classification).
  2. SECTION 2: table placement -- section, exact bounds, size arithmetic;
     plus every rip-relative reference that lands within +-0x200 of the
     table (the neighbourhood: install sites of neighbouring constants).
  3. SECTION 3: the kernel POINTER edge: engine+0x40f0 holds the table
     pointer installed by FUN_1800E18B0 (0x1800E1FB4 lea / 0x1800E1FBB mov).
     All whole-.text accesses to displacement 0x40f0 are listed and their
     windows disassembled -- a store THROUGH that pointer would prove (i);
     only the lea/mov install + reads prove (iii).
  4. SECTION 4: duplicate/source scan -- the whole image is searched for the
     byte patterns of row 0, row 128, rows 0..1 (0x30 bytes) and the first
     0x100 bytes of the table.  A second copy (e.g. in .data) would evidence
     (ii); only the table itself -> no source copy.
  5. SECTION 5: neighbourhood dump -- 0x1803B5F70..0x1803B7B70 (table
     +-0x200) as 6-float rows with row sums, to test whether the table is a
     slice of a larger 6-float-row structure (row sums ~1.0 continuing past
     the end would say yes).
  6. SECTION 6: quick numerical origin checks on the table itself:
     float32 ULP structure of the row sums and of the mirror-symmetry
     differences (exact-zero symmetry = designed+rounded data, OBS data).

Output: r14_scan_kernel_refs.txt
"""

import hashlib
import struct
import sys

import capstone

TARGET = "/home/z/octavox/original/Ox.vst3"
OUT = ("/home/z/octavox/work/Octavox_RE_evidence/evidence/"
       "analysis_round14/r14_scan_kernel_refs.txt")
SHA_EXPECT = "7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2"

TABLE_VA = 0x1803B6170
TABLE_END = 0x1803B7970          # 0x1800 bytes = 256 rows x 0x18
NEIGH = 0x200                    # neighbourhood radius for Section 2/5


def load():
    with open(TARGET, "rb") as f:
        data = f.read()
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    coff = e_lfanew + 4
    machine, nsec = struct.unpack_from("<HH", data, coff)
    opt_sz = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    opt = coff + 20
    image_base = struct.unpack_from("<Q", data, opt + 24)[0]
    sec_off = e_lfanew + 24 + opt_sz
    sections = {}
    order = []
    for i in range(nsec):
        o = sec_off + 40 * i
        name = data[o:o + 8].rstrip(b"\x00").decode("ascii", "replace")
        vsize, vaddr, rsize, roff = struct.unpack_from("<IIII", data, o + 8)
        sections[name] = (vaddr, vsize, roff, rsize)
        order.append(name)
    return data, image_base, sections, order


def main():
    sha_before = hashlib.sha256(open(TARGET, "rb").read()).hexdigest()

    data, image_base, sections, order = load()

    def va2fo(va):
        rva = va - image_base
        for name in order:
            vaddr, vsize, roff, rsize = sections[name]
            if vaddr <= rva < vaddr + vsize:
                return roff + (rva - vaddr)
        return None

    def section_of(va):
        rva = va - image_base
        for name in order:
            vaddr, vsize, roff, rsize = sections[name]
            if vaddr <= rva < vaddr + vsize:
                return name
        return None

    # ---- .pdata function table -------------------------------------------
    pdata = sections[".pdata"]
    praw = data[pdata[2]:pdata[2] + pdata[3]]
    chunks = []
    n_zero = 0
    for i in range(0, len(praw) - 11, 12):
        s, e, _u = struct.unpack_from("<III", praw, i)
        if s == 0 and e == 0:
            n_zero += 1
            continue
        chunks.append((image_base + s, image_base + e))
    chunks.sort()

    def chunk_of(va):
        for fs, fe in chunks:
            if fs <= va < fe:
                return fs, fe
        return None

    tv, _ts, t_off, t_rsz = sections[".text"]
    TVA = image_base + tv
    blob = data[t_off:t_off + t_rsz]

    # sweep ranges = chunks + gaps
    ranges = []
    cur = TVA
    for fs, fe in chunks:
        if fs > cur:
            ranges.append((cur, fs, "gap"))
        ranges.append((fs, fe, "chunk"))
        cur = max(cur, fe)
    if cur < TVA + t_rsz:
        ranges.append((cur, TVA + t_rsz, "gap"))

    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    md.detail = True

    STORE_MNEMONICS = {"mov", "movss", "movsd", "movaps", "movups", "movdqa",
                       "movdqu", "movntps", "movd", "movq", "add", "sub",
                       "mul", "imul", "xor", "or", "and", "pop", "inc", "dec"}

    def resolve_targets(insn):
        """rip-relative targets of an instruction with optional data values"""
        out = []
        for op in insn.operands:
            if (op.type == capstone.x86.X86_OP_MEM
                    and op.mem.base == capstone.x86.X86_REG_RIP):
                tgt = insn.address + insn.size + op.mem.disp
                fo = va2fo(tgt)
                val = ""
                if fo is not None and section_of(tgt) not in (".text", None):
                    f32 = struct.unpack_from("<f", data, fo)[0]
                    f64 = struct.unpack_from("<d", data, fo)[0]
                    val = f" [f32={f32!r} f64={f64!r}]"
                out.append((tgt, val))
        return out

    def disasm_window(lo, hi):
        lines = []
        for insn in md.disasm(blob[lo - TVA:hi - TVA], lo):
            ann = ""
            for tgt, val in resolve_targets(insn):
                sec = section_of(tgt)
                mark = ""
                if TABLE_VA <= tgt < TABLE_END:
                    mark = "  <== KERNEL TABLE REF"
                elif (TABLE_VA - NEIGH) <= tgt < (TABLE_END + NEIGH):
                    mark = "  (table +-0x200 neighbourhood)"
                ann += f"  ; -> {tgt:#x} ({sec}){val}{mark}"
            # engine+0x40f0 (kernel pointer) annotation
            for op in insn.operands:
                if (op.type == capstone.x86.X86_OP_MEM
                        and op.mem.base != capstone.x86.X86_REG_RIP
                        and op.mem.disp == 0x40f0):
                    ann += "   ; <engine+0x40f0 = KERNEL TABLE PTR>"
                    break
            lines.append(f"  {insn.address:#x}  {insn.mnemonic:10s} "
                         f"{insn.op_str}{ann}")
        return lines

    # ---- SECTION 1: references INTO the table ----------------------------
    refs = []          # (va, insn, tgt, where)
    ptr_refs = []      # engine+0x40f0 accesses
    for lo, hi, where in ranges:
        for insn in md.disasm(blob[lo - TVA:hi - TVA], lo):
            for tgt, _v in resolve_targets(insn):
                if TABLE_VA <= tgt < TABLE_END:
                    refs.append((insn.address, insn.mnemonic, insn.op_str,
                                 tgt, where))
            for op in insn.operands:
                if (op.type == capstone.x86.X86_OP_MEM
                        and op.mem.base != capstone.x86.X86_REG_RIP
                        and op.mem.base not in (capstone.x86.X86_REG_RSP,
                                                capstone.x86.X86_REG_RBP)
                        and op.mem.disp == 0x40f0):
                    w = "read"
                    if (insn.mnemonic in STORE_MNEMONICS
                            and op is insn.operands[0]
                            and insn.op_str.split(",")[0].strip().find("[") >= 0):
                        w = "WRITE"
                    ptr_refs.append((insn.address, insn.mnemonic, insn.op_str,
                                     w, where))

    out = []
    out.append("OCTAVOX round 14 -- interpolation kernel origin scan "
               "(static, read-only)")
    out.append(f"target: {TARGET}")
    out.append(f"table: {TABLE_VA:#x}..{TABLE_END:#x} "
               f"({TABLE_END - TABLE_VA:#x} bytes = 256 rows x 0x18, 6 floats)")
    out.append(f"sha256 (before): {sha_before} "
               f"({'MATCH' if sha_before == SHA_EXPECT else 'MISMATCH!'})")
    out.append("")
    out.append("=" * 78)
    out.append("SECTION 1: every rip-relative reference INTO "
               f"{TABLE_VA:#x}..{TABLE_END:#x} (whole .text,")
    out.append("           .pdata chunks + gap sweep)")
    out.append("=" * 78)
    if not refs:
        out.append("(none)")
    for va, m, o, tgt, where in sorted(set(refs)):
        ch = chunk_of(va)
        chs = (f".pdata chunk {ch[0]:#x}..{ch[1]:#x}" if ch
               else "NO .pdata chunk (gap)")
        g = " [gap sweep]" if where == "gap" else ""
        # store classification: is the rip operand a write destination?
        is_store = False
        for insn in md.disasm(blob[va - TVA:va - TVA + 16], va):
            if insn.address == va:
                is_store = (insn.mnemonic in STORE_MNEMONICS
                            and insn.operands
                            and insn.operands[0].type == capstone.x86.X86_OP_MEM
                            and insn.operands[0].mem.base
                            == capstone.x86.X86_REG_RIP)
                break
        kind = "STORE (would write the table!)" if is_store else "read"
        out.append(f"{va:#x}  {m} {o} -> {tgt:#x}   [{kind}] {chs}{g}")
    out.append("")

    # ---- SECTION 2: placement + neighbourhood -----------------------------
    out.append("=" * 78)
    out.append("SECTION 2: table placement and +-0x200 neighbourhood refs")
    out.append("=" * 78)
    sec = section_of(TABLE_VA)
    tfo = va2fo(TABLE_VA)
    out.append(f"section: {sec}  (file offset {tfo:#x})")
    # section characteristics (read/write flags) -- decisive for origin
    flag_names = [(0x00000020, "CODE"), (0x00000040, "INITIALIZED_DATA"),
                  (0x80000000, "UNINITIALIZED_DATA"), (0x40000000, "MEM_READ"),
                  (0x80000000, "MEM_WRITE"), (0x10000000, "MEM_EXECUTE"),
                  (0x02000000, "MEM_DISCARDABLE"), (0x04000000, "MEM_NOT_CACHED")]
    out.append("section characteristics (all sections, for the write-permission"
               " argument):")
    for name in order:
        ch = sections[name][3]
        # re-read the header for the flags (sections tuple has no flags)
    # simpler: re-parse flags directly
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    opt_sz = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    for i in range(len(order)):
        o = e_lfanew + 24 + opt_sz + 40 * i
        name = data[o:o + 8].rstrip(b"\x00").decode("ascii", "replace")
        ch = struct.unpack_from("<I", data, o + 36)[0]
        fl = []
        if ch & 0x00000020:
            fl.append("CODE")
        if ch & 0x00000040:
            fl.append("INITIALIZED_DATA")
        if ch & 0x80000000:
            fl.append("UNINITIALIZED_DATA")
        if ch & 0x40000000:
            fl.append("MEM_READ")
        if ch & 0x80000000:
            fl.append("MEM_WRITE")
        if ch & 0x10000000:
            fl.append("MEM_EXECUTE")
        if ch & 0x02000000:
            fl.append("MEM_DISCARDABLE")
        out.append(f"  {name:8s} characteristics={ch:#010x} "
                   f"({' | '.join(fl)})")
    out.append("")
    out.append("-> the table's section is READ-ONLY (no MEM_WRITE): an in-place")
    out.append("   runtime generation would fault; only VirtualProtect/memcpy")
    out.append("   to a writable copy could create a runtime kernel, and no")
    out.append("   writable copy exists anywhere in the image (Section 4).")
    out.append("")
    out.append(f"size: {TABLE_END - TABLE_VA:#x} = {TABLE_END - TABLE_VA} "
               f"= 256*24 exactly (256 rows x 6 floats, 0x18 stride)")
    out.append(f"section range: {sec} spans "
               f"{image_base + sections[sec][0]:#x}.."
               f"{image_base + sections[sec][0] + sections[sec][1]:#x}")
    # raw first/last rows for the record
    r0 = struct.unpack_from("<6f", data, tfo)
    r255 = struct.unpack_from("<6f", data, tfo + 255 * 0x18)
    out.append(f"row 0   : {' '.join(f'{v:+.6e}' for v in r0)}")
    out.append(f"row 255 : {' '.join(f'{v:+.6e}' for v in r255)}")
    neigh = []
    for lo, hi, where in ranges:
        for insn in md.disasm(blob[lo - TVA:hi - TVA], lo):
            for tgt, _v in resolve_targets(insn):
                if ((TABLE_VA - NEIGH) <= tgt < TABLE_VA
                        or TABLE_END <= tgt < TABLE_END + NEIGH):
                    neigh.append((insn.address, insn.mnemonic, insn.op_str,
                                  tgt, where))
    out.append("")
    out.append(f"rip-relative refs into [{TABLE_VA - NEIGH:#x},"
               f"{TABLE_VA:#x}) or [{TABLE_END:#x},{TABLE_END + NEIGH:#x}):")
    if not neigh:
        out.append("(none -- nothing references the bytes around the table)")
    for va, m, o, tgt, where in sorted(set(neigh)):
        ch = chunk_of(va)
        chs = (f".pdata chunk {ch[0]:#x}..{ch[1]:#x}" if ch else "gap")
        g = " [gap sweep]" if where == "gap" else ""
        out.append(f"  {va:#x}  {m} {o} -> {tgt:#x}   {chs}{g}")
    out.append("")

    # ---- SECTION 3: the kernel pointer edge (engine+0x40f0) --------------
    out.append("=" * 78)
    out.append("SECTION 3: all whole-.text accesses to displacement 0x40f0 "
               "(engine+0x40f0 = the kernel")
    out.append("           table pointer; a store THROUGH it would prove "
               "runtime generation)")
    out.append("=" * 78)
    if not ptr_refs:
        out.append("(none)")
    for va, m, o, w, where in sorted(set(ptr_refs)):
        ch = chunk_of(va)
        chs = (f".pdata chunk {ch[0]:#x}..{ch[1]:#x}" if ch else "gap")
        g = " [gap sweep]" if where == "gap" else ""
        tag = "  <== WRITE of the pointer slot" if w == "WRITE" else ""
        out.append(f"  {va:#x}  {m} {o}   [{w}] {chs}{g}{tag}")
    out.append("")
    out.append("windows for every pointer-slot access and every table ref:")
    shown = set()
    for va, m, o, tgt, where in sorted(set(refs)):
        if va in shown:
            continue
        if where == "gap":
            # gap sweep decodes can be misaligned before the instruction;
            # start exactly at the ref (the lea itself is aligned)
            lo, hi = va, va + 0x10
        else:
            lo, hi = va - 0x28, va + 0x28
        lo, hi = max(TVA, lo), min(TVA + len(blob), hi)
        shown.update(range(lo, hi))
        out.append("")
        out.append("-" * 78)
        ch = chunk_of(va)
        out.append(f"### window {lo:#x}..{hi:#x} around table ref {va:#x} "
                   f"({'.pdata chunk %s..%s' % (hex(ch[0]), hex(ch[1])) if ch else 'gap -- decoded from the ref itself'})")
        out.append("-" * 78)
        out.extend(disasm_window(lo, hi))
    for va, m, o, w, where in sorted(set(ptr_refs)):
        if va in shown:
            continue
        lo, hi = va - 0x30, va + 0x30
        lo, hi = max(TVA, lo), min(TVA + len(blob), hi)
        shown.update(range(lo, hi))
        out.append("")
        out.append("-" * 78)
        ch = chunk_of(va)
        out.append(f"### window {lo:#x}..{hi:#x} around engine+0x40f0 "
                   f"access {va:#x} [{w}] "
                   f"({'.pdata chunk %s..%s' % (hex(ch[0]), hex(ch[1])) if ch else 'gap'})")
        out.append("-" * 78)
        out.extend(disasm_window(lo, hi))

    # ---- SECTION 4: duplicate / source scan -------------------------------
    out.append("")
    out.append("=" * 78)
    out.append("SECTION 4: duplicate/source scan (byte patterns of the "
               "table searched in the")
    out.append("           WHOLE image, all sections, raw file bytes)")
    out.append("=" * 78)
    tbytes = data[tfo:tfo + (TABLE_END - TABLE_VA)]
    patterns = [
        ("row 0 (24 bytes)", tbytes[0:24]),
        ("row 128 (24 bytes)", tbytes[128 * 24:128 * 24 + 24]),
        ("rows 0..1 (0x30 bytes)", tbytes[0:0x30]),
        ("first 0x100 bytes", tbytes[0:0x100]),
        ("rows 127..129 (0x48 bytes, mirror centre)",
         tbytes[127 * 24:127 * 24 + 0x48]),
    ]
    for label, pat in patterns:
        occ = []
        start = 0
        while True:
            i = data.find(pat, start)
            if i < 0:
                break
            occ.append(i)
            start = i + 1
        # map file offsets to VAs
        va_occ = []
        for fo in occ:
            for name in order:
                vaddr, vsize, roff, rsize = sections[name]
                if roff <= fo < roff + rsize:
                    va_occ.append(f"{image_base + vaddr + (fo - roff):#x} ({name})")
                    break
            else:
                va_occ.append(f"file offset {fo:#x} (headers)")
        out.append(f"{label}: {len(occ)} occurrence(s) in the image: "
                   f"{', '.join(va_occ) if va_occ else '(none)'}")
    out.append("")
    out.append("(only occurrences INSIDE 0x1803B6170..0x1803B7970 itself "
               "mean 'the table'; any")
    out.append(" occurrence elsewhere would be a second copy / a source "
               "constant)")

    # ---- SECTION 5: neighbourhood dump ------------------------------------
    out.append("")
    out.append("=" * 78)
    out.append(f"SECTION 5: neighbourhood dump {TABLE_VA - NEIGH:#x}.."
               f"{TABLE_END + NEIGH:#x} as 6-float rows (0x18 stride)")
    out.append("           (row sums ~1.0 continuing past the table end "
               "would mean 'slice of a")
    out.append("            larger table'; other structure = unrelated "
               "neighbour constants)")
    out.append("=" * 78)
    nfo = va2fo(TABLE_VA - NEIGH)
    nrows_n = (2 * NEIGH + (TABLE_END - TABLE_VA)) // 0x18
    for r in range(nrows_n):
        fo = nfo + r * 0x18
        va = TABLE_VA - NEIGH + r * 0x18
        vals = struct.unpack_from("<6f", data, fo)
        inside = TABLE_VA <= va < TABLE_END
        ssum = sum(vals)
        q = data[fo:fo + 24].hex()
        tag = "TABLE" if inside else ("before" if va < TABLE_VA else "after")
        out.append(f"{va:#x} [{tag:6s}] sum={ssum:+.6f} "
                   f"{' '.join(f'{v:+.5e}' for v in vals)}")
    out.append("")

    # ---- SECTION 6: numerical origin checks -------------------------------
    out.append("=" * 78)
    out.append("SECTION 6: numerical origin checks on the table data "
               "(OBS data, DER reading)")
    out.append("=" * 78)
    rows = [struct.unpack_from("<6f", data, tfo + r * 0x18)
            for r in range(256)]
    sums = [sum(r) for r in rows]
    out.append(f"row sums: min={min(sums):.9f} max={max(sums):.9f} "
               f"(round 12: 1.000000..1.000122)")
    # mirror symmetry exactness
    mir = max(abs(rows[r][k] - rows[255 - r][5 - k])
              for r in range(256) for k in range(6))
    out.append(f"mirror symmetry max|T[r,k]-T[255-r,5-k]| = {mir!r} "
               "(0.0 = bit-exact, round 13 OBS)")
    # ULP structure: how many rows have a sum exactly 1.0 in f32?
    import math
    one_rows = sum(1 for s in sums if math.copysign(1.0, s) == 1.0 and
                   struct.unpack("<I", struct.pack("<f", s))[0]
                   == 0x3F800000)
    out.append(f"rows whose f32 sum is exactly 0x3F800000 (1.0): {one_rows}")
    # zero taps? (a computed windowed sinc has exact zeros at row boundaries)
    zeros = [(r, k) for r in range(256) for k in range(6) if rows[r][k] == 0.0]
    out.append(f"exact zero taps: {len(zeros)} "
               + (str(zeros[:12]) if zeros else ""))
    # denormals / inf / nan
    bad = [(r, k) for r in range(256) for k in range(6)
           if not math.isfinite(rows[r][k])]
    out.append(f"non-finite taps: {len(bad)}")
    # quantisation spacing: distinct mantissa deltas of neighbouring rows
    # (row r and row 255-r are mirror images; check T[r][2] vs T[255-r][3])
    d2 = max(abs(rows[r][2] - rows[255 - r][3]) for r in range(256))
    out.append(f"mirror pair |T[r][2]-T[255-r][3]| max = {d2!r} "
               "(tap2/tap3 mirror)")
    # last-byte histogram of the raw rows: generated-then-rounded data has
    # full-entropy low mantissa bits; 'hand-typed' tables often show patterns
    low = {}
    for r in range(256):
        b = data[tfo + r * 0x18 + 23] & 0x0F
        low[b] = low.get(b, 0) + 1
    out.append("low nibble of the high mantissa byte (per tap float, "
               "mod-16 histogram):")
    out.append("  " + " ".join(f"{k}:{v}" for k, v in sorted(low.items())))

    sha_after = hashlib.sha256(open(TARGET, "rb").read()).hexdigest()
    out.append("")
    out.append(f"sha256 (after): {sha_after} "
               f"({'MATCH' if sha_after == SHA_EXPECT else 'MISMATCH!'})")
    out.append("target was read only; never executed")

    text = "\n".join(out)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(text + "\n")
    print(f"wrote {OUT} ({len(out)} lines)")
    print(f"table refs: {len(set(refs))}, engine+0x40f0 accesses: "
          f"{len(set(ptr_refs))}")
    print(f"sha before/after: {sha_before} / {sha_after}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
