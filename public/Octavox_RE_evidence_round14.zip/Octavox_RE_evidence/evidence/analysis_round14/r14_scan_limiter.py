#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OCTAVOX round 14 (v3) -- exact whole-.text scan of the tracker's
ratio-limiter / correction / period fields and of the tracker-function call
graph.

METHOD (v2 -- replaces the interrupted first version whose needle+back-search
could accept a mis-aligned decode and thereby MISS real references):
  * every .pdata chunk is disassembled LINEARLY from its start (exact,
    complete inside the chunk; .pdata is verified: 13116 real entries,
    zero padding only at the end, monotonic);
  * the gaps BETWEEN .pdata chunks are swept linearly too (best-effort --
    functions without SEH scopes live there, e.g. the recorder
    FUN_1800E0190..0x1800E0355 has NO .pdata entry);
  * every memory operand with base != RIP and displacement in
    0x5F00..0x6090 (tracker fields) is collected, with the access span
    (4/8/16 bytes) so vector stores covering several fields are caught;
  * read/write classification from the operand order;
  * additionally: all rel32 call/jmp sites targeting the tracker functions
    (0x1800DFE80 tracker top, 0x1800E0190 recorder, 0x18013E160 parabolic
    refinement, 0x18013BBC0 state machine), and all lea/access sites with
    displacement 0x4518 (engine->tracker base) / 0x4510 (tracking flag) /
    0xA4FC (wdelta = tracker+0x5FE4) for the engine<->tracker boundary.

v3 ADDITIONS (round-14 residues):
  * ENGINE-ALIAS WINDOW: the same tracker fields are also reachable through
    the engine base as engine+0x4518+field -- displacement window
    0xA3C0..0xA5A0.  This is how m01/m02 (FUN_1800E10B0/FUN_1800E1520)
    touch them (e.g. tracker+0x6044 = engine+0xA55C); a tracker-only
    displacement scan cannot see those.  Section 5 lists every such alias
    access with the tracker-field name resolved.
  * RECORD-RING SCAN: every operand of the form [base + index*4 + 0x98]
    (the record ring lives at engine+0x98 and is only ever indexed) is
    collected -> Section 6: the complete reader list for the ring fields.
  * DEDICATED WINDOWS (Section 7): m01 case 0x10/0x11 (the writers of
    +0x6044/+0x6048/+0x604C/+0x6050), m02 case 0xc/0xd (the consumers of
    +0x6074/+0x6070), the prepare's record reader 0x1800E25DB..0x1800E2662
    (the consumer of the clamped gain -> rate slot), and the CRT exp
    prologue (identification of FUN_180351F50).

v4 (final round-14 version) FIXES/EXTENSIONS:
  * Section 6 CORRECTED: of the 9 [base+index*4+0x98] sites, only the 3
    with base=rsi=engine at 0x1800E26xx are the RECORD RING; the other 6
    (0x180213C25/0x180214180/0x180214403/0x1802198B8/0x1802199C4/
    0x180219ADD) belong to a DIFFERENT structure (an int table at +0x98
    paired with a byte table at +0x498, guarded by `cmp N, 8` bit-ladder
    selection, used by the stream readers FUN_180219DC0/0x180219CB0) --
    they are NOT the engine record ring and are now listed separately.
    The recorder's 7 ring WRITES go through the pointer loaded from
    T+0x5FD8 (no displacement) and are listed explicitly.
  * Section 7 EXTENDED: the prepare record-reader window now runs to
    0x1800E2762 (rate slot / fade / re-arm jump); ADDED the tracker state
    machine dispatch + cases 7/8/9 (WHEN the limiter runs) and the m01/m02
    dispatch heads (edx = message id).

v5 (round-14 P2-A, audited + extended): every dedicated window re-verified
  * against a fresh independent disassembly; ADDED SECTION 4: the m01/m02
  * message-dispatch jump tables decoded from .text (m01 @0x1800E14D0 ids
  * 0..0x11: 0x0e -> row count T+0x6040, 0x0f -> acceptance-band zero,
  * 0x10 -> dead-band edges, 0x11 -> ratio clamps; m02 @0x1800E1890 ids
  * 7..0xd: 0xc -> target cents, 0xd -> gain cents) and the PORT-BOUND
  * ENGINE REGION engine+0x4310..0x4520 (the cand-table ladder
  * engine+0x4320..0x4360, the cand row table engine+0x4370..0x4490, the
  * bitmask/threshold engine+0x44A0..0x44D0 -- ctor-zeroed, then filled
  * through the lea+jmp port thunks 0x180361xxx/0x180365xxx into the setter
  * 0x1800171B0, the same mechanism round 12 mapped to port 30 /
  * engine+0x4510; no displacement-visible writer fills them).

Read-only. Target never executed. SHA-256 verified before and after.
Output: r14_scan_limiter.txt
"""

import hashlib
import struct
import sys

import capstone

TARGET = "/home/z/octavox/original/Ox.vst3"
OUT = ("/home/z/octavox/work/Octavox_RE_evidence/evidence/"
       "analysis_round14/r14_scan_limiter.txt")
SHA_EXPECT = "7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2"

TRACKER_LO, TRACKER_HI = 0x5F00, 0x6090   # tracker field displacement window
ENG_LO, ENG_HI = 0xA3C0, 0xA5A0           # engine-alias window (tracker+0x5EA8..0x6088)
CAND_LO, CAND_HI = 0x4310, 0x4520         # port-bound engine region (cand tables/bitmask)
TRACKER_BASE_OFF = 0x4518                 # engine -> tracker
RING_DISP = 0x98                          # record ring at engine+0x98 (indexed)
ENGINE_OFFS = {0x4518: "engine+0x4518 = TRACKER BASE",
               0x4510: "engine+0x4510 = tracking flag (port 30)",
               0xA4FC: "engine+0xa4fc = wdelta (= tracker+0x5FE4)"}
CALL_TARGETS = {
    0x1800DFE80: "FUN_1800DFE80 tracker top (omega, candidate search, +0x6074)",
    0x1800E0190: "FUN_1800E0190 recorder (ratio limiter + ring writer)",
    0x18013E160: "FUN_18013E160 parabolic peak refinement",
    0x18013BBC0: "FUN_18013BBC0 tracker state machine",
}

FLD = {
    0x5F14: "cfg (==4 -> x2, ==8 -> x4 in case 6)",
    0x5F30: "reject-hold flag (>=0 keeps old estimate)",
    0x5F58: "history buffer begin ptr (== tracker+0)",
    0x5F60: "history buffer base ptr (== tracker+4)",
    0x5F90: "tracker state (case5/6 scalar)",
    0x5F98: "position ptr A",
    0x5FA0: "last peak value",
    0x5FA8: "position ptr B",
    0x5FB0: "counter A",
    0x5FB4: "counter B",
    0x5FB8: "position ptr C",
    0x5FC0: "glide state",
    0x5FC8: "ptr to 2-float (magnitude, level)",
    0x5FD0: "gatelevel",
    0x5FD4: "PERIOD ESTIMATE x 2^11 (input samples)",
    0x5FD8: "record ring base (engine+0x98)",
    0x5FE0: "ring mask 0xFFF",
    0x5FE4: "ring write index (wdelta)",
    0x5FE8: "tracking flag",
    0x5FEC: "confidence/magnitude",
    0x5FF4: "scalar state",
    0x5FF8: "state machine id",
    0x6008: "2048.0 = 2^11",
    0x6018: "cand table ptr 1",
    0x6020: "cand table ptr 2",
    0x6028: "cand table ptr 3 (6-float rows)",
    0x6030: "cand table ptr 4",
    0x6038: "ptr (bitmask word + int threshold at +4)",
    0x6040: "cand table row count",
    0x6044: "ratio clamp HI",
    0x6048: "ratio clamp LO",
    0x604C: "dead-band HI edge",
    0x6050: "dead-band LO edge",
    0x6058: "selected cand row ptr",
    0x6060: "selected cand row value",
    0x6064: "acceptance band LO (omega units)",
    0x6068: "acceptance band HI (omega units)",
    0x606C: "raw angular frequency omega = 2048*2pi/[0x5FD4]",
    0x6070: "running correction gain (ratio-limited)",
    0x6074: "instantaneous correction target",
    0x6078: "stability counter",
}

# already documented in r14_disas_tracker_full.txt or in Section 7 below
KNOWN = [(0x1800DFE80, 0x1800E0356), (0x18013CEC0, 0x18013D131),
         (0x18013E160, 0x18013E1F6), (0x1800E0C90, 0x1800E0F00),
         (0x1800E13FD, 0x1800E14B3),   # m01 cases 0x10/0x11 (Section 7)
         (0x1800E1751, 0x1800E1871),   # m02 cases 0xc/0xd  (Section 7)
         (0x1800E25DB, 0x1800E2762),   # prepare record reader (Section 7)
         (0x180351F50, 0x180351FB0),   # exp prologue (Section 7)
         (0x18013BBC0, 0x18013BE73),   # state machine head (disas file)
         (0x18013BE40, 0x18013BE73),   # state dispatch (Section 7)
         (0x18013D127, 0x18013D1FB),   # cases 7/8/9 (Section 7)
         (0x1800E10B0, 0x1800E10E1),   # m01 head (Section 7)
         (0x1800E1520, 0x1800E1560)]   # m02 head (Section 7)

STORE_MNEMONICS = {"mov", "movss", "movsd", "movaps", "movups", "movdqa",
                   "movdqu", "movd", "movq", "add", "sub", "mul", "imul",
                   "xor", "or", "and", "pop", "inc", "dec"}


def main():
    sha_before = hashlib.sha256(open(TARGET, "rb").read()).hexdigest()

    with open(TARGET, "rb") as f:
        data = f.read()
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    coff = e_lfanew + 4
    machine, nsec = struct.unpack_from("<HH", data, coff)
    opt_sz = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    opt = coff + 20
    image_base = struct.unpack_from("<Q", data, opt + 24)[0]
    sec_off = e_lfanew + 24 + opt_sz
    sections = {}
    for i in range(nsec):
        o = sec_off + 40 * i
        name = data[o:o + 8].rstrip(b"\x00").decode("ascii", "replace")
        vsize, vaddr, rsize, roff = struct.unpack_from("<IIII", data, o + 8)
        sections[name] = (vaddr, vsize, roff, rsize)

    def va2fo(va):
        rva = va - image_base
        for name, (vaddr, vsize, roff, rsize) in sections.items():
            if vaddr <= rva < vaddr + vsize:
                return roff + (rva - vaddr)
        return None

    def section_of(va):
        rva = va - image_base
        for name, (vaddr, vsize, roff, rsize) in sections.items():
            if vaddr <= rva < vaddr + vsize:
                return name
        return None

    # ---- .pdata (verified: zeros only at the very end, monotonic) --------
    pdata = sections[".pdata"]
    raw = data[pdata[2]:pdata[2] + pdata[3]]
    chunks = []
    n_zero = 0
    for i in range(0, len(raw) - 11, 12):
        s, e, _u = struct.unpack_from("<III", raw, i)
        if s == 0 and e == 0:
            n_zero += 1
            continue
        chunks.append((image_base + s, image_base + e))
    chunks.sort()

    tv, _ts, t_off, t_rsz = sections[".text"]
    TVA = image_base + tv
    blob = data[t_off:t_off + t_rsz]

    # sweep ranges = chunks + inter-chunk gaps
    ranges = []
    cur = TVA
    for fs, fe in chunks:
        if fs > cur:
            ranges.append((cur, fs, "gap"))
        ranges.append((fs, fe, "chunk"))
        cur = max(cur, fe)
    if cur < TVA + t_rsz:
        ranges.append((cur, TVA + t_rsz, "gap"))

    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    md.detail = True

    def resolve_ann(insn):
        out = ""
        for op in insn.operands:
            if op.type == capstone.x86.X86_OP_MEM:
                if op.mem.base == capstone.x86.X86_REG_RIP:
                    tgt = insn.address + insn.size + op.mem.disp
                    sec = section_of(tgt)
                    val = ""
                    fo = va2fo(tgt)
                    if fo is not None and sec not in (".text", None):
                        f32 = struct.unpack_from("<f", data, fo)[0]
                        f64 = struct.unpack_from("<d", data, fo)[0]
                        val = f" [f32={f32!r} f64={f64!r}]"
                    out += f" -> {tgt:#x} ({sec}){val}"
        return out

    hits = []          # (va, mnemonic, op_str, disp, span, kind, where)
    callhits = []      # (va, mnemonic, target, where)
    ringhits = []      # (va, mnemonic, op_str, base, index, w, where)
    candhits = []      # (va, mnemonic, op_str, disp, span, w, where)
    for lo, hi, where in ranges:
        for insn in md.disasm(blob[lo - TVA:hi - TVA], lo):
            # rel32 call/jmp to tracker functions
            if insn.mnemonic in ("call", "jmp") and insn.operands:
                op = insn.operands[0]
                if op.type == capstone.x86.X86_OP_IMM:
                    if op.imm in CALL_TARGETS:
                        callhits.append((insn.address, insn.mnemonic,
                                         op.imm, where))
            for op in insn.operands:
                if op.type != capstone.x86.X86_OP_MEM:
                    continue
                if op.mem.base == capstone.x86.X86_REG_RIP:
                    continue
                # stack-frame operands are noise for object-field scanning
                if op.mem.base in (capstone.x86.X86_REG_RSP,
                                   capstone.x86.X86_REG_RBP):
                    continue
                # record-ring access: [base + index*4 + 0x98]
                if (op.mem.index != 0 and op.mem.scale == 4
                        and op.mem.disp == RING_DISP
                        and op.mem.base not in (capstone.x86.X86_REG_RSP,
                                                capstone.x86.X86_REG_RBP)):
                    w = "read"
                    if insn.mnemonic in STORE_MNEMONICS and op is insn.operands[0] \
                            and insn.op_str.split(",")[0].strip().find("[") >= 0:
                        w = "WRITE"
                    ringhits.append((insn.address, insn.mnemonic, insn.op_str,
                                     insn.reg_name(op.mem.base) if op.mem.base else "",
                                     insn.reg_name(op.mem.index), w, where))
                d = op.mem.disp
                # access span
                span = 4
                if "xmmword" in insn.op_str or insn.mnemonic in (
                        "movaps", "movups", "movdqa", "movdqu", "andps",
                        "xorps", "movntps"):
                    span = 16
                elif "qword" in insn.op_str or insn.mnemonic in (
                        "movq", "movsd"):
                    span = 8
                elif "word ptr" in insn.op_str:
                    span = 2
                covered = set(range(d, d + span))
                is_t = any(TRACKER_LO <= x < TRACKER_HI for x in covered)
                is_e = any(x in ENGINE_OFFS for x in covered)
                is_a = any(ENG_LO <= x < ENG_HI for x in covered)
                is_c = any(CAND_LO <= x < CAND_HI for x in covered)
                if is_c:
                    wc = "read"
                    if insn.mnemonic in STORE_MNEMONICS and op is insn.operands[0] \
                            and insn.op_str.split(",")[0].strip().find("[") >= 0:
                        wc = "WRITE"
                    candhits.append((insn.address, insn.mnemonic, insn.op_str,
                                     d, span, wc, where))
                if not (is_t or is_e or is_a):
                    continue
                # write?
                w = "read"
                if insn.mnemonic in STORE_MNEMONICS and op is insn.operands[0] \
                        and insn.op_str.split(",")[0].strip().find("[") >= 0:
                    w = "WRITE"
                for x in sorted(covered):
                    if TRACKER_LO <= x < TRACKER_HI or x in ENGINE_OFFS \
                            or ENG_LO <= x < ENG_HI:
                        hits.append((insn.address, insn.mnemonic, insn.op_str,
                                     x, span, w, where))

    # ---- output ----------------------------------------------------------
    out = []
    out.append("OCTAVOX round 14 (v5, exact linear sweep) -- tracker "
               "limiter/correction/period field scan")
    out.append(f"target: {TARGET}  (read-only; never executed)")
    out.append(f"sha256 (before): {sha_before} "
               f"({'MATCH' if sha_before == SHA_EXPECT else 'MISMATCH!'})")
    out.append("method: linear disassembly of every .pdata chunk plus the "
               "inter-chunk gaps (best-effort),")
    out.append("        collecting every memory operand with displacement "
               "in 0x5F00..0x6090 (tracker")
    out.append("        fields, span-aware for vector accesses), the "
               "ENGINE-ALIAS window 0xA3C0..0xA5A0 (the")
    out.append("        same tracker fields via engine+0x4518+field), and "
               "0x4518/0x4510/0xA4FC (engine boundary);")
    out.append("        rsp/rbp-based (stack) operands excluded.  Also: every "
               "[base+index*4+0x98] operand")
    out.append("        (the record ring at engine+0x98).")
    out.append(f".pdata: {len(chunks)} chunks, {n_zero} zero-pad entries "
               "(all at the end); gaps swept: "
               f"{sum(1 for r in ranges if r[2] == 'gap')}")
    out.append("")
    out.append("=" * 78)
    out.append("SECTION 1: TRACKER FIELD SUMMARY "
               "(displacement -> every reference site)")
    out.append("=" * 78)

    from collections import defaultdict
    per = defaultdict(list)
    for va, m, o, d, span, w, where in hits:
        if TRACKER_LO <= d < TRACKER_HI:
            per[d].append((va, m, o, span, w, where))
    for d in sorted(per):
        name = FLD.get(d, "")
        refs = sorted(set(per[d]))
        wr = [r for r in refs if r[4] == "WRITE"]
        out.append(f"+{d:#06x} {name}: {len(refs)} refs "
                   f"({len(wr)} WRITE, {len(refs)-len(wr)} read)")
        for va, m, o, span, w, where in refs:
            tag = ("  <== WRITE" if w == "WRITE" else "")
            g = " [gap sweep]" if where == "gap" else ""
            out.append(f"    {va:#x}  {m} {o}   {tag}{g}")
        out.append("")

    out.append("=" * 78)
    out.append("SECTION 2: ENGINE<->TRACKER BOUNDARY "
               "(engine offsets 0x4518 / 0x4510 / 0xA4FC / 0x98)")
    out.append("=" * 78)
    for d in sorted(ENGINE_OFFS):
        sel = [h for h in hits if h[3] == d]
        if not sel:
            out.append(f"{ENGINE_OFFS[d]}: no hits")
            continue
        out.append(f"{ENGINE_OFFS[d]}: {len(sel)} refs")
        for va, m, o, d2, span, w, where in sorted(set(sel)):
            g = " [gap sweep]" if where == "gap" else ""
            tag = ("  <== WRITE" if w == "WRITE" else "")
            out.append(f"    {va:#x}  {m} {o}{tag}{g}")
        out.append("")

    out.append("=" * 78)
    out.append("SECTION 3: CALLERS of the tracker functions (rel32 "
               "call/jmp sites)")
    out.append("=" * 78)
    for tgt in sorted(CALL_TARGETS):
        sel = [c for c in callhits if c[2] == tgt]
        out.append(f"{CALL_TARGETS[tgt]}:")
        if not sel:
            out.append("    (no rel32 call/jmp site found in .text)")
        for va, m, t, where in sorted(set(sel)):
            g = " [gap sweep]" if where == "gap" else ""
            out.append(f"    {va:#x}  {m} {t:#x}{g}")
        out.append("")

    out.append("=" * 78)
    out.append("SECTION 4: TRACKER PARAMETER SOURCES -- message dispatch "
               "tables + port-bound engine region")
    out.append("=" * 78)
    out.append("m01 = FUN_1800E10B0 (engine parameter-message handler; edx = "
               "id, r8 = &value).  Jump table @0x1800E14D0, ids 0..0x11:")
    M01_CASES = {
        0x0E: "T+0x6040 cand row count = (int)value",
        0x0F: "acceptance band T+0x6064/T+0x6068 = 0 (correction disable)",
        0x10: "dead-band edges T+0x604C/T+0x6050 = 2^(\u00b1value/1200)",
        0x11: "ratio clamps T+0x6044/T+0x6048 = 2^(\u00b11/(12*value))",
        0x05: "windowed-magnitude FIR table T+0x5EB0.. (3 constant sets)",
        0x06: "reject-hold T+0x5F30=0x12, T+0x5F38=value*243, "
              "T+0x5F34=1/value",
    }
    fo_m01 = va2fo(0x1800E14D0)
    for idx in range(0x12):
        off = struct.unpack_from("<I", data, fo_m01 + idx * 4)[0]
        tgt = image_base + off
        note = M01_CASES.get(idx, "")
        out.append(f"    id {idx:#04x} -> {tgt:#x}"
                   + (f"   ; {note}" if note else ""))
    out.append("")
    out.append("m02 = FUN_1800E1520 (engine meter/message handler; edx = id, "
               "r8 = &out).  Jump table @0x1800E1890, ids 7..0xD "
               "(index = id-7):")
    M02_CASES = {
        0x0C: "reads T+0x6074 (target): gated -1731.234*log|target| cents",
        0x0D: "reads T+0x6070 (running gain): gated +1731.234*log(gain) cents",
        0x07: "reads T+0x5FC8 pair (magnitude/level) meter",
    }
    fo_m02 = va2fo(0x1800E1890)
    for idx in range(7):
        off = struct.unpack_from("<I", data, fo_m02 + idx * 4)[0]
        tgt = image_base + off
        note = M02_CASES.get(idx + 7, "")
        out.append(f"    id {idx + 7:#04x} -> {tgt:#x}"
                   + (f"   ; {note}" if note else ""))
    out.append("")
    out.append("port-bound engine region engine+0x4310..0x4520 (base != "
               "rsp/rbp/rip; span-aware):")
    out.append("  ctor stores: [0x6018]=engine+0x4320, [0x6020]=engine+"
               "0x4328 (8-slot {f32 thr, f32 val} ladder, ctor-zeroed "
               "0x1800E0BF8..0x1800E0C01);")
    out.append("               [0x6028]=engine+0x4370, [0x6030]=engine+"
               "0x4388 (cand row table, <= 12 x 6-float rows in the "
               "memset(engine+0x4370,0,0x120) @0x1800E0C42);")
    out.append("               [0x6038]=engine+0x44A0 ({dword bitmask, int "
               "threshold}, 0x30 bytes zeroed @0x1800E0C7A..0x1800E0C85).")
    out.append("  after the ctor zeroing NO displacement-visible writer "
               "fills the ladder/rows/bitmask; the lea+jmp port thunks "
               "(0x180361xxx / 0x180365xxx families -> setter 0x1800171B0, "
               "the mechanism round 12 mapped to port 30 = engine+0x4510) "
               "bind this region, so the fill path is pointer-based "
               "(UNK beyond the thunks):")
    for va, m, o, d, span, w, where in sorted(set(candhits)):
        g = " [gap sweep]" if where == "gap" else ""
        tag = ("  <== WRITE" if w == "WRITE" else "")
        out.append(f"    {va:#x}  {m} {o}{tag}{g}")
    out.append("")

    out.append("=" * 78)
    out.append("SECTION 5: ENGINE-ALIAS ACCESSES to the tracker fields "
               "(displacements 0xA3C0..0xA5A0)")
    out.append("  (the field is engine+0x4518+tracker_offset -- this is "
               "how m01/m02 reach the)")
    out.append("   limiter fields; a tracker-displacement-only scan CANNOT "
               "see these accesses)")
    out.append("=" * 78)
    alias = defaultdict(list)
    for va, m, o, d, span, w, where in hits:
        if ENG_LO <= d < ENG_HI:
            alias[d].append((va, m, o, span, w, where))
    if not alias:
        out.append("(no engine-alias accesses found)")
    for d in sorted(alias):
        tf = d - TRACKER_BASE_OFF
        name = FLD.get(tf, "")
        refs = sorted(set(alias[d]))
        wr = [r for r in refs if r[4] == "WRITE"]
        out.append(f"engine+{d:#06x} = tracker+{tf:#06x} {name}: "
                   f"{len(refs)} refs ({len(wr)} WRITE)")
        for va, m, o, span, w, where in refs:
            tag = ("  <== WRITE" if w == "WRITE" else "")
            g = " [gap sweep]" if where == "gap" else ""
            out.append(f"    {va:#x}  {m} {o}{tag}{g}")
        out.append("")

    out.append("=" * 78)
    out.append("SECTION 6: RECORD-RING ACCESSES")
    out.append("  the record ring at engine+0x98 (4096 floats, mask 0xFFF) is "
               "read via")
    out.append("  [engine + index*4 + 0x98] and WRITTEN through the pointer "
               "loaded from")
    out.append("  T+0x5FD8 (no displacement on the stores).  Records are 4 "
               "consecutive floats in")
    out.append("  ASCENDING index order [period*2^11 | interval | spare | "
               "clamped gain],")
    out.append("  written DESCENDING (gain at wdelta-1 ... period at "
               "wdelta-4; wdelta -= 4).")
    out.append("=" * 78)
    out.append("readers ([base+index*4+0x98] with base = rsi = engine, all in "
               "FUN_1800E2030 prepare):")
    ringreads = [r for r in sorted(set(ringhits)) if r[3] == "rsi"]
    for va, m, o, b, i, w, where in ringreads:
        g = " [gap sweep]" if where == "gap" else ""
        tag = ("  <== WRITE" if w == "WRITE" else "")
        out.append(f"    {va:#x}  {m:8s} {o}   base={b} index={i}{tag}{g}")
    out.append("")
    out.append("writers (recorder FUN_1800E0190 stores through the pointer "
               "from T+0x5FD8;")
    out.append("            displacement-free, hence invisible to the "
               "displacement scan):")
    for va, what in (
            (0x1800E0276, "ring[(wdelta-1)&0xFFF] = clamped new gain "
                          "(tracking branch)"),
            (0x1800E028E, "ring[(wdelta-2)&0xFFF] = (float)r10d"),
            (0x1800E02B0, "ring[(wdelta-3)&0xFFF] = (float)r11d"),
            (0x1800E02DB, "ring[...] = clamped new gain (non-tracking "
                          "branch; T+0x5FE8 is ctor-const 1 -> dead)"),
            (0x1800E0302, "ring[...] = (float)r10d (non-tracking branch)"),
            (0x1800E0329, "ring[...] = (float)r11d (non-tracking branch)"),
            (0x1800E034B, "ring[(wdelta-4)&0xFFF] = period estimate (raw "
                          "f32 bits of T+0x5FD4); then wdelta -= 4")):
        out.append(f"    {va:#x}  movss/mov [ring + idx*4]   ; {what}")
    out.append("")
    out.append("NOT the record ring (same [base+index*4+0x98] operand shape, "
               "different object: an")
    out.append("int table at +0x98 paired with a byte table at +0x498, "
               "`cmp N, 8`-guarded")
    out.append("bit-ladder selection used by the stream readers "
               "FUN_180219DC0/0x180219CB0;")
    out.append("bases r8/r12/rbx/r14 are NOT the engine -- kept here only "
               "to document the")
    out.append("disambiguation):")
    for va, m, o, b, i, w, where in sorted(set(ringhits)):
        if b != "rsi":
            g = " [gap sweep]" if where == "gap" else ""
            out.append(f"    {va:#x}  {m:8s} {o}   base={b} index={i}{g}")
    out.append("")

    out.append("=" * 78)
    out.append("SECTION 7: DEDICATED EVIDENCE WINDOWS (fully annotated)")
    out.append("=" * 78)

    def field_ann(insn):
        """annotation for tracker fields reached directly or via engine"""
        tags = []
        for op in insn.operands:
            if op.type != capstone.x86.X86_OP_MEM:
                continue
            if op.mem.base == capstone.x86.X86_REG_RIP:
                continue
            dd = op.mem.disp
            if TRACKER_LO <= dd < TRACKER_HI:
                tags.append(f"T+{dd:#x}={FLD.get(dd, '')}")
            elif dd in ENGINE_OFFS:
                tags.append(ENGINE_OFFS[dd])
            elif ENG_LO <= dd < ENG_HI:
                tf = dd - TRACKER_BASE_OFF
                tags.append(f"engine+{dd:#x}=T+{tf:#x} {FLD.get(tf, '')}")
        return ("   ; <" + " | ".join(tags) + ">") if tags else ""

    DEDICATED = [
        ("m01 = FUN_1800E10B0 case 0x10 (id 16) -- WRITES the dead-band "
         "edges: T+0x604C = 2^(+x/1200), T+0x6050 = 2^(-x/1200) via "
         "exp(FUN_180351F50) and ln2/1200 = 0.00057762265 @0x1804120C0",
         0x1800E13FD, 0x1800E1460),
        ("m01 case 0x11 (id 17) -- WRITES the ratio clamps: T+0x6044 = "
         "2^(+1/(12x)), T+0x6048 = 2^(-1/(12x)) via exp and ln2/12 = "
         "0.057762265 @0x1804121A8 / -0.057762265 @0x180412818",
         0x1800E1460, 0x1800E14B3),
        ("m02 = FUN_1800E1520 case 0xc -- READS T+0x6074 (correction "
         "target): gated -1731.234*log|target| (cents)",
         0x1800E1751, 0x1800E17E1),
        ("m02 case 0xd -- READS T+0x6070 (running correction gain): gated "
         "+1731.234*log(gain) (cents)",
         0x1800E17E1, 0x1800E1871),
        ("prepare = FUN_1800E2030 record reader -- the CONSUMER of the "
         "clamped gain: rate_slot[v] = page[0] * ring[base+3](gain); "
         "also the period clamp (480.0 if < 2^-47 else max(v, 48.0) -- NO "
         "upper clamp), the fade decrement page[12+idx]*2^-23 and the "
         "re-arm jump 2^(page[12+idx]&0xF)*v",
         0x1800E25DB, 0x1800E2762),
        ("tracker state machine FUN_18013BBC0 -- the STATE DISPATCH on "
         "T+0x5FF8 (jump table 0x18013D22C, states 0..9; one state per "
         "call; called once per prepare() at 0x1800E20CE).  State 7 = "
         "tracker top, state 8 = RECORDER (the ratio limiter), state 9 = "
         "confidence/gate",
         0x18013BE40, 0x18013BE73),
        ("tracker state machine cases 7/8/9 bodies: state 7 calls "
         "0x1800DFE80 (tracker top) -> state 8; state 8 calls 0x1800E0190 "
         "(recorder: ratio limiter + record write) -> state 9; state 9 "
         "updates T+0x5FEC (one-pole confidence, rates 0.99/0.7, min 1.0) "
         "and T+0x5FF0 = min(T+0x5FF4/sqrt(conf), 1)*32 and returns to "
         "state 0 (see also r14_disas_tracker_full.txt)",
         0x18013D127, 0x18013D1FB),
        ("m01 = FUN_1800E10B0 head -- the parameter-message dispatch "
         "(edx = id; cmp edx, 0x11 / jump table); case 0x10 = dead-band "
         "edges, case 0x11 = ratio clamps (windows above)",
         0x1800E10B0, 0x1800E10E1),
        ("m02 = FUN_1800E1520 head -- the meter/message dispatch "
         "(edx = id); case 0xc = target cents, case 0xd = gain cents "
         "(windows above)",
         0x1800E1520, 0x1800E1560),
        ("FUN_180351F50 prologue -- the CRT double exp (range guards "
         "+-709.782712893384 = ln(2^+-1024))",
         0x180351F50, 0x180351FB0),
    ]
    for label, lo, hi in DEDICATED:
        out.append("")
        out.append("-" * 78)
        out.append(f"### {label}")
        out.append("-" * 78)
        for insn in md.disasm(blob[lo - TVA:hi - TVA], lo):
            out.append(f"  {insn.address:#x}  {insn.mnemonic:10s} "
                       f"{insn.op_str}   {resolve_ann(insn)}"
                       f"{field_ann(insn)}")

    out.append("=" * 78)
    out.append("SECTION 8: ANNOTATED WINDOWS around NEW reference sites "
               "(not already in r14_disas_tracker_full.txt or Section 7)")
    out.append("=" * 78)
    shown = set()
    for va, m, o, d, span, w, where in sorted(set(hits)):
        if any(lo <= va < hi for lo, hi in KNOWN):
            continue
        if va in shown:
            continue
        lo, hi = va - 0x30, va + 0x18
        lo = max(TVA, lo)
        hi = min(TVA + len(blob), hi)
        key = (lo, hi)
        if key in shown:
            continue
        shown.add(key)
        shown.update(range(lo, hi))
        out.append("")
        out.append("-" * 78)
        out.append(f"### window {lo:#x}..{hi:#x} "
                   f"(first hit {va:#x}: {m} {o}"
                   f"{' WRITE' if w == 'WRITE' else ''})")
        for insn in md.disasm(blob[lo - TVA:hi - TVA], lo):
            dtag = ""
            for op in insn.operands:
                if (op.type == capstone.x86.X86_OP_MEM
                        and op.mem.base != capstone.x86.X86_REG_RIP):
                    dd = op.mem.disp
                    if TRACKER_LO <= dd < TRACKER_HI:
                        dtag = f"   ; <+{dd:#x} {FLD.get(dd, '')}>"
                        break
                    if dd in ENGINE_OFFS:
                        dtag = f"   ; <{ENGINE_OFFS[dd]}>"
                        break
            out.append(f"  {insn.address:#x}  {insn.mnemonic:10s} "
                       f"{insn.op_str}   {resolve_ann(insn)}{dtag}")

    sha_after = hashlib.sha256(open(TARGET, "rb").read()).hexdigest()
    out.append("")
    out.append(f"sha256 (after): {sha_after} "
               f"({'MATCH' if sha_after == SHA_EXPECT else 'MISMATCH!'})")
    out.append("target was read only; never executed")

    text = "\n".join(out)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(text + "\n")
    print(f"wrote {OUT} ({len(out)} lines)")
    print(f"field hits: {len(set(hits))}, call sites: {len(set(callhits))}, "
          f"ring accesses: {len(set(ringhits))}")
    print(f"sha before/after: {sha_before} / {sha_after}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
