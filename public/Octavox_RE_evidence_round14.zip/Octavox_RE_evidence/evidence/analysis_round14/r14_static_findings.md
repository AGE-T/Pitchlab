# OCTAVOX ROUND 14 — STATIC DSP FINDINGS (P2)

**Evidence consistency + remaining static DSP paths.** All work in this file
is **static analysis of the shipped target** (`Ox.vst3`, SHA-256
`7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2`). The
target was **read only and never executed**; the digest was verified before
and after every scan (see the verification logs inside
`r14_disas_tracker_full.txt`, `r14_scan_limiter.txt`,
`r14_scan_kernel_refs.txt`). Labels: **OBS** = directly supported by cited
instructions; **DER** = derived interpretation (derivation stated); **UNK** =
unresolved. Nothing here is a claim about the original plugin's runtime
behaviour.

Scripts (all read-only, `/home/z/.venv/bin/python` + capstone 5.0.7):

| script | output | purpose |
|---|---|---|
| `r14_disas_tracker_full.py` | `r14_disas_tracker_full.txt` | full annotated disassembly of the tracker top (FUN_1800DFE80), the recorder (FUN_1800E0190), the period-estimate state (FUN_18013BBC0 case 6 + head + cases 7/8/9), the peak refinement (FUN_18013E160), the init helper (0x180161700), the engine-ctor tracker window and the prepare reader |
| `r14_scan_limiter.py` | `r14_scan_limiter.txt` | whole-.text displacement scan of tracker fields 0x5F00–0x6090 (+ engine-alias window 0xA3C0–0xA5A0, the engine↔tracker boundary, callers, m01/m02 dispatch tables, record-ring accesses, dedicated evidence windows) |
| `r14_scan_kernel_refs.py` | `r14_scan_kernel_refs.txt` | every rip-relative reference into the observed kernel table 0x1803B6170..0x1803B7970, write-path check, whole-image duplicate scan, neighbourhood dump, numerical origin checks |

---

## 1. P2-A — the tracker input (xmm1) and the ratio limiter

### 1.1 The input quantity xmm1 = tracker+0x5FD4 — the period estimate at the 2^11 scale (OBS)

At `0x1800DFE86` (function FUN_1800DFE80, the "tracker top"):

```
0x1800dfe86  movss  xmm1, dword ptr [rcx + 0x5fd4]     ; the divisor
0x1800dfeb1  comiss xmm1, xmm9                          ; xmm9 = 2^-47 (0x180411E44)
0x1800dfeb5  jb    0x1800dfede                          ; degenerate -> keep frozen omega
0x1800dfeb7  movss  xmm0, dword ptr [rcx + 0x6008]     ; 2048.0 (= 2^11)
0x1800dfec2  mulsd  xmm0, qword ptr [0x180412400]      ; × 2π (the DOUBLE 6.283185307179586)
0x1800dfed7  divss  xmm8, xmm1                          ; xmm8 = 2048·2π / [T+0x5FD4]
0x1800dfef7  movss  dword ptr [rcx + 0x606c], xmm8     ; store as +0x606C
```

**What xmm1 is (OBS):** `xmm1 = [tracker+0x5FD4]`, a positive float32 written
by the tracker state machine's **state 6** (FUN_18013BBC0 case 6,
`0x18013D10E`) and initialised by the engine constructor to
`2048.0 × 50.0 = 102400.0` (`0x1800E0E3C–0x1800E0E4C`, constants 0x45000000
= 2048.0f at +0x6008 and 50.0 at 0x18041268C).

**How state 6 computes it (OBS, `r14_disas_tracker_full.txt` case-6 window):**

```
period = 16384·idx + (refine(current_peak − 3 entries) − refine(prev_peak))
       · ×2 if [T+0x5F14] == 4   · ×4 if [T+0x5F14] == 8
       · reject-hold: if [T+0x5F30] >= 0 → keep the OLD [T+0x5FD4]
       · gate: if [T+0x5FD0] − level < ε → also publish into the 2-float pair at [T+0x5FC8]
       · octave guard: if period < 2048·50 → period ×= 2
       · store to [T+0x5FD4]
```

where `refine` is FUN_18013E160 (`0x18013E160..0x18013E1F5`): a **parabolic
sub-entry peak refinement** on three consecutive history samples, returning
`float(int(δ·8·2048))` with δ = 0.5·(x0−x2)/(x0−2·x1+x2) clamped to [−1, 1]
(computed in double; constants 0.5 @0x1804122A0, 8.0 @0x1804125B8, the
2^11 at +0x6008).

**Units (DER, now closed):** 16384 = 8·2048 exactly, and the refinement
returns δ·8·2048 — i.e. the history buffer is decimated by 8 input samples
per entry and the stored value is the **period in input samples scaled by
2^11**: `T̂·2^11 = 2^11·8·(idx + δ)`. The consumer-side confirmation is
direct: the prepare reader multiplies the ring's period field by
**2^-11** (`0x1800E260B`, constant 0x180411E94 = 0.00048828125) and clamps
the result as a sample count (min 48.0, see §1.4). The 2048.0 in the tracker
top **cancels** the 2^11 scale, so

> **+0x606C = ω = 2π/T̂, the angular frequency in rad/sample (OBS chain,
> DER label)** — the quantity the candidate search and the acceptance band
> work in.

### 1.2 ROUND-13 CORRECTION — the constant at 0x180412400 is 2π, not 3370280550400.0

The instruction at `0x1800DFEC2` is `mulsd` (scalar **double**). The qword at
.rdata `0x180412400` is `0x401921FB54442D18` = **6.283185307179586 = 2π**
(byte dump in `r14_scan_limiter.txt` §"tracker top"). Round 13 documented
this constant as "the double 3370280550400.0 = 2²¹·5²·64283" — that number
is the **float32 reading of the low 32 bits** (0x54442D18 → f32 =
3370280550400.0), i.e. a decoding error, and its factorisation is an artifact
of the misread. Correction recorded in
`OCTAVOX_ROUND14_FINDINGS.md` §2 and the canonical docs; the round-13 archive
is preserved unchanged.

Follow-on correction: round 13's "the first-field scaling is a matched
×2¹¹ / ÷2¹¹ pair (writer: 2048.0 × 3370280550400.0 / x at 0x1800dfeb7)" is
**refuted as stated**. The 2048·2π/xmm1 computation produces ω for the
candidate search and the acceptance band (stored at +0x606C); it is not a
ring-field target. The genuine ×2¹¹/÷2¹¹ matched pair is on the **period**:
writer side [T+0x5FD4] (state 6, at the 2^11 scale) → ring field at
`base+0` → reader ×2^-11 (`0x1800E260B`). See §1.4.

### 1.3 The ratio limiter — exact semantics (OBS)

The chain runs in the recorder, FUN_1800E0190 (`0x1800E0190..0x1800E0355`),
called by tracker state 8 (FUN_18013BBC0 case 8 at `0x18013D13F`), which
itself runs after state 7 (the tracker top FUN_1800DFE80 at
`0x18013D12A`). All epsilon guards are 2^-47 (0x180411E44).

1. **Instantaneous target** `[T+0x6074]` (written by the tracker top's tail,
   `0x1800E0154`/`0x1800E016E`): `1.0` when the confidence
   `[T+0x5FEC] ≤ 6.0000000071054275e-06` (double at 0x180412018); otherwise
   `f3/(pivot·ω)` — the selected candidate row's field `[row−8]` divided by
   the search key `pivot·ω` (`0x1800E0105–0x1800E0109`; pivot = the phase-1
   selected value at `[T+0x6060]`, key = pivot·ω from `0x1800E00B0`). DER:
   this is a "snap-to-note" target — the ratio between a table target
   frequency and the detected frequency.
2. **Per-candidate enable** (`0x1800E01B5–0x1800E01C8`): `bit (id1+1)` of
   the dword at `[T+0x6038]` (engine+0x44A0) — `id1 = int(row[0])`. Bit
   clear → the target is forced to `1.0` (correction disabled for that
   candidate). Bit set → target kept.
3. **Dead-band** (`0x1800E01D6–0x1800E01FB`): if the target lies inside
   `[+0x6050, +0x604C]` the effective value is `1.0` (no correction);
   outside the band it passes through. Edges are written by the m01
   parameter case **0x10** (`0x1800E13FD`): `+0x604C = 2^(+x/1200)`,
   `+0x6050 = 2^(−x/1200)` (x in **cents**, ln2/1200 = 0.00057762265 @
   0x1804120C0; exp = FUN_180351F50). I.e. a ±cents window around unity
   where correction is suppressed.
4. **Rate limiter** (`0x1800E01FB–0x1800E0243`):
   `ratio = effective / [T+0x6070]`, clamped into `[[T+0x6048], [T+0x6044]]`
   (inclusive, epsilon-guarded), then `[T+0x6070] ← ratio·[T+0x6070]`.
   Bounds are written by the m01 parameter case **0x11** (`0x1800E1460`):
   `+0x6044 = 2^(+1/(12·x))`, `+0x6048 = 2^(−1/(12·x))` (ln2/12 =
   0.057762265 @0x1804121A8, −0.057762265 @0x180412818; exp = FUN_180351F50).
   x is the correction-rate parameter — per tracker update the running gain
   moves at most `100/x` cents (DER).
5. **Ring write** (`0x1800E0246–0x1800E0355`): the new `[T+0x6070]` and two
   candidate ids are appended as a 4-float record at descending indices from
   `wdelta` (mask 0xFFF): `ring[(wdelta−1)&mask] = gain`,
   `ring[(wdelta−2)&mask] = (float)id1`,
   `ring[(wdelta−3)&mask] = (float)id2`,
   `ring[(wdelta−4)&mask] = raw bits of [T+0x5FD4]` (the period at the 2^11
   scale, integer move `0x1800E034B`); `wdelta ← (wdelta−4)&mask`. The
   non-tracking branch (flag `[T+0x5FE8] == 0`) performs the same stores
   with manual wrap.

**Stability machinery around the limiter (OBS, tracker top):**

* `[T+0x6078]` — a counter: `+1` (saturating at 0x7FFFFF) while
  `|ω_new − ω_old| < 1.6e-4` (0.00015999999595806003 @0x180411E80); reset to
  0 when the delta reaches that threshold (`0x1800DFF17`, `cmovb` at
  `0x1800DFF1E`, store `0x1800DFF2B`).
* When the counter exceeds the threshold at `[T+0x6038]+4`, the acceptance
  band narrows: HI × 0.561269998550415, LO × 0.4454199969768524
  (`0x1800DFF56/0x1800DFF63` — the "locked" state tightens tracking;
  DER).
* `[T+0x6070]` is hard-reset to `1.0f` (0x3f800000) when
  `|ω_new − ω_old| ≥ 4e-4` (0.00039999998989515007 @0x180411E8C;
  `0x1800DFF24–0x1800DFF33`): a frequency jump restarts the correction from
  unity.
* Acceptance band `[T+0x6064]/[T+0x6068]` (LO/HI, in ω units) is recomputed
  from the selected candidate row (`0x1800E0123/0x1800E012B`); the band
  check at `0x1800DFF74–0x1800DFF90` gates whether the tracker stays
  "locked" (skip the search) — band = (f3/pivot)·f1 / ·f2 with the row
  fields f1/f2.

**Init/reset values (OBS, engine ctor window `0x1800E0D1F–0x1800E0E14`):**

* `0x180161700` is a compiler **memset** (0x101010101010101 fill pattern,
  `.pdata 0x180161700..0x180161890`) called with `(tracker, 0, 0x5EB0)` —
  zeroes the first 0x5EB0 bytes only. **`+0x6044/+0x6048/+0x604C/+0x6050`
  lie above 0x5EB0 and are not written by the ctor** — they are configured
  exclusively through the m01 messages 0x10/0x11 (host parameters; DER:
  they are 0-initialized only insofar as the engine allocation is zeroed —
  UNK for the allocator's guarantees, the m01 path is the only observed
  writer).
* Explicit ctor writes: `[T+0x5FD4] = 2048·50` (50 samples at the 2^11
  scale), `[T+0x6070] = 1.0f`, `[T+0x5FE8] (tracking) = 1`,
  `[T+0x5FE4] (wdelta) = 0`, `[T+0x5FF8] (state id) = 0`,
  `[T+0x5FF4] = 0.0078125f`, ring base/mask/2048.0 installs, cand-table
  pointers into the engine's port region (see §1.5), `[T+0x6040] = 0`,
  `[T+0x6060] = 0`, `[T+0x6058] = engine+0x4370`.

**Consumers (OBS):**

* The recorder itself (the rate limiter + the ring write, above).
* The m02 read-outs (FUN_1800E1520, jump table @0x1800E1890): **case 0xc**
  reads `[T+0x6074]` and reports `−1731.234·ln|target|` = `1200·log2(1/target)`
  cents, gated by `exp(0.11513·gatelevel) vs sqrt(level·0.99999988)`
  (`0x1800E1751–0x1800E17C9`; constants −1731.234 @0x180412888,
  0.11513000000000001 @0x180412200, 0.9999998812035873 @0x180412320);
  **case 0xd** reads `[T+0x6070]` and reports `+1731.234·ln(gain)` =
  `1200·log2(gain)` cents (`0x1800E17E1+`, +1731.234 @0x180412540). These
  are the round-10 "read-outs 12/13" meters — now pinpointed to the
  correction target/running gain.
* The prepare reader (see §1.4) — the ring transport of the gain.

### 1.4 The prepare reader — where the clamped value goes (OBS)

`FUN_1800E2030` (prepare), reader at `0x1800E25DB–0x1800E2759`
(`r14_disas_tracker_full.txt` final windows; constants resolved):

```
base = (page_off[v] + wdelta) & 0xFFF            ; page_off[v] from the engine+0x42F8 int table
v    = ring[base+0] · 2^-11                      ; 0x1800E260B, 2^-11 @0x180411E94
       if v < 2^-47 -> v = 480.0                 ; the ZERO-RECORD fallback (0x180412730)
       else if v <= 48.0 -> v = 48.0             ; min clamp (48.0 @0x180412688)  -- NO upper clamp
interval = (int)ring[base+1]                     ; 0x1800E2630 (cvttss2si)
gain     = ring[base+3]                          ; 0x1800E264A
       if engine+0x4510 ('tracking', port 30) == 0 -> gain = 1.0
rate_slot[v] = page[0] · gain                    ; fallback page[0] if the product < 2^-47
       stored through the engine+0x4128 vector   ; 0x1800E2691-0x1800E269F
idx  = clamp((v − 48)·0.0625, 0, 31)             ; 0x1800E26AA-0x1800E26BB
jump = 2^( (int)page[12+idx] & 0xF ) · v         ; +0.5 round-half-up (0.5 @0x180412058)
       -- the re-arm jump distance, in samples
```

**ROUND-12 CORRECTION:** the reader's period handling is `max(v, 48)` with a
**480.0 fallback only for degenerate/zero records** — there is **no upper
clamp at 480**. Round 12's "re-arm base clamped to [48, 480]" conflated the
min-clamp (48.0 @0x180412688) with the degenerate fallback (480.0
@0x180412730). Both constants are real; only one is a clamp.

**The closure of the round-9 law (OBS):** `rate_slot[v] = page[0]·gain` with
`page[0] = ratio·0.0625` (round 9) and `gain = ring[base+3]` (the running
correction) is exactly `slot_4128 = (ratio/16)·correction` — the record ring
is the transport of the tracker's **pitch-correction gain** into the pitch
rate map. The `interval` id indexes a per-voice float table
(`[r11 + 8 + interval·4]`, `0x1800E267C`); the fourth ring field
(`base+2`, the id1 written by the recorder) is **not read by this reader**
(spare/UNK consumer).

### 1.5 Classification — pitch correction, record re-arming, or both?

**OBS facts:** every consumer of `+0x6070/+0x6044/+0x6048` is inside the
correction-gain path (the recorder's limiter, the m02 meters 12/13, the
ring→prepare rate-slot). The record ring transports **both** roles but in
**separate fields**: the gain (base+3) feeds pitch correction; the period
(base+0) feeds the re-arm base and jump distance; the interval (base+1)
feeds a per-voice table index.

**Verdict:** the ratio-limiter fields (`+0x6070/+0x6044/+0x6048`, with the
dead-band `+0x604C/+0x6050` and the target `+0x6074`) control **pitch
correction only** — they never influence the re-arm geometry. The re-arm
path consumes the *period* field, whose limiter-free writer is state 6. The
record ring itself serves both, as the transport. (Classification from the
dataflow above, not from names.)

### 1.6 The candidate tables (context, OBS)

The candidate search tables live in the **engine's port-bound region**, not
in .rdata: `[T+0x6018]=engine+0x4320` and `[T+0x6020]=engine+0x4328` (an
8-slot {f32 threshold, f32 value} ladder, ctor-zeroed
`0x1800E0BF8–0x1800E0C01`), `[T+0x6028]=engine+0x4370` and
`[T+0x6030]=engine+0x4388` (a 12×6-float row region, memset 0x120 at
`0x1800E0C42`), `[T+0x6038]=engine+0x44A0` ({dword bitmask, int threshold},
0x30 bytes zeroed). The engine ctor installs these pointers
(`0x1800E0E54–0x1800E0E78`). No displacement-visible code fills these engine
regions after the ctor zeroing — they sit in the port-bound thunk region
engine+0x4330..0x4510 (host-configured; DER: the "scale/note tables" of a
pitch corrector, rows keyed by ω with fields {key, band LO mult, band HI
mult, correction numerator, id1, id2}).

The search itself (tracker top): phase 1 selects a pivot from the 8-slot
ladder by ω (`0x1800DFFBC–0x1800E009D`, cmov chain); phase 2 scans the
6-float rows while `row[0] > pivot·ω` (`0x1800E00D0–0x1800E00E8`) and
selects the previous row; the acceptance band and correction numerator are
that row's fields (§1.3).

---

## 2. P2-B — the observed interpolation kernel: origin verdict

Table: `.rdata 0x1803B6170..0x1803B7970`, exactly 0x1800 bytes = 256 rows ×
6 floats (0x18 stride). All results from `r14_scan_kernel_refs.py/.txt`.

1. **References (OBS):** exactly **three** rip-relative references into the
   range exist in the whole .text (pdata chunks + gap sweep):
   * `0x1800E1FB4` (`lea rax, [rip+0x2d41b5]`) in FUN_1800E18B0 — the known
     pitch-engine prepare: installs the table pointer at **engine+0x40F0**
     (`0x1800E1FBB`, the only write to that pointer slot).
   * `0x1800DC287` (`lea rax, [rip+0x2d9ee2]`) in the function spanning
     0x1800DBEF0..0x1800DC425 — a **second consumer**: installs the same
     table pointer at `[obj+0xD0]` (`0x1800DC28E`) of a different object.
     The object's role beyond the pointer install is UNK (a second
     fractional-delay user is the plausible reading, DER).
   * `0x18032B720` — a gap-sweep hit whose surrounding bytes do not decode
     to a coherent instruction stream (mid-instruction data; classified as
     a false positive of the linear gap sweep, not a code reference).
2. **Write-path check (OBS):** no instruction anywhere stores into
   0x1803B6170..0x1803B7970; the only WRITE involving the table is the
   pointer-slot store at engine+0x40F0. Runtime generation would require a
   write path (or a copy into .data) — none exists. Section confirmed
   .rdata (file offset 0x3B4770).
3. **Duplicate/source scan (OBS):** the byte patterns of row 0, row 128,
   rows 0–1, the first 0x100 bytes and the rows 127–129 mirror-centre block
   each occur **exactly once in the entire image** — at the table itself.
   There is no second copy, no source constant block, and the table is not
   a strided slice of a larger table (the neighbourhood 0x1803B5F70..
   0x1803B7B70 dump shows the adjacent structures; references to
   0x1803B7970 are to the table that *starts* there — a different constant
   used by unrelated functions 0x1800C77xx–0x1800D05xx).
4. **Numerical origin checks (OBS data, DER reading):** row sums
   1.000000136..1.000122214 (round-12 values reproduced); mirror symmetry
   `max|T[r,k]−T[255−r,5−k]| = 0` bit-exact; 4 exact-zero taps
   [(101,0),(102,0),(153,5),(154,5)]; no non-finite taps; the per-tap
   mantissa low-nibble histogram (0:2, 8:45, 9:122, 10:25, 11:48, 12:14)
   shows a broad, non-degenerate quantisation fingerprint — consistent
   with a one-off float32 design output, not with a runtime-computed
   double→float cast chain (DER).

**Verdict: (iii) embedded precomputed data — OBS.** The kernel ships as a
unique, write-never-referenced .rdata block consumed through pointer
installs by (at least) the pitch engine and one other object. The exact
design formula remains **UNK**: the round-13 characterisation
(Blackman-Harris-windowed-sinc-like, cutoff ≈0.83, RMS residual 2.8e-3) is
an approximation, not the formula; with no generator code and no source
table in the image, the design cannot be proved from the binary alone. The
`ObsKernel6` mode in our native core reproduces the OBSERVED DATA (row
values), not any claimed design.

---

## 3. Path matrix

See `r14_path_matrix.md` (the DSP route audit: every main-graph edge with
producer, consumer, evidence location, OBS/DER/UNK classification, and the
edge counts by class).

---

## 4. Residue (what stays UNK, and why)

* The exact generating formula of the observed kernel (no generator code,
  no source table — §2).
* The role of the second kernel consumer's object (only the pointer install
  is OBS; §2.1).
* The semantics of the `[T+0x5F14]` cfg multipliers (==4 → ×2, ==8 → ×4 in
  state 6): OBS arithmetic, DER/UNK meaning (the mapping to a voice/shift
  configuration is not traced).
* The consumer (if any) of the ring's `base+2` field (id1) — written by the
  recorder, not read by the prepare reader.
* The host-side fill of the candidate tables (port region — outside the
  binary's .text evidence; the ctor only zeroes them).
* All runtime questions (walk statistics, correction audibility, the
  m02 meters' live values) — the target was never executed.

**SHA-256 verification log** (before/after every scan — recorded inside each
output file): `7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2`
— MATCH at every check.
