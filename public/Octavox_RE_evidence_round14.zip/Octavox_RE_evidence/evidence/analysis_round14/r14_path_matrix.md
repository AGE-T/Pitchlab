# OCTAVOX ROUND 14 — DSP ROUTE AUDIT / PATH MATRIX (P2-C)

Main processing graph of the original, **edge by edge**: producer → consumer,
evidence location, classification (**OBS** directly supported by static
evidence · **DER** derived · **UNK** unresolved). This matrix audits the
canonical architecture (`OCTAVOX_DSP_ARCHITECTURE.md` §2–§6, §8–§10) and
control-flow (`OCTAVOX_CONTROL_FLOW_MATRIX.md` §1–§14) documents against the
binary evidence and **focuses on the edges that were previously open or
contradictory**; long-established edges are referenced compactly. Round-14
scan evidence: `r14_disas_tracker_full.txt`, `r14_scan_limiter.txt`,
`r14_scan_kernel_refs.txt`, `r14_static_findings.md` (all in this directory).

Notation: E = engine object; T = tracker sub-object at engine+0x4518;
page = the per-voice page tables; VA = virtual address in the shipped image.

## 1. Input and parameter updates

| # | edge | producer | consumer | evidence | class |
|---|---|---|---|---|---|
| 1 | host params → engine m01 | host (port thunks) | FUN_1800E10B0 dispatch (ids 3..0x11) | CONTROL_FLOW_MATRIX §2/§4; r14_scan_limiter §4 | OBS |
| 2 | m01 id 0x10 (cents) → T+0x604C/+0x6050 | m01 case 0x10 `0x1800E13FD` (2^(±x/1200)) | recorder dead-band `0x1800E01D6–0x1800E01FB` | r14_static_findings §1.3 | **OBS (round-14 closure; was DER "tuning/quantization" in CFM §7.9)** |
| 3 | m01 id 0x11 (rate) → T+0x6044/+0x6048 | m01 case 0x11 `0x1800E1460` (2^(±1/(12x))) | recorder rate limiter `0x1800E01FB–0x1800E0243` | r14_static_findings §1.3 | **OBS (round-14 closure; was DER "correctrate" in CFM §7.9 — now instruction-confirmed)** |
| 4 | m01 id 0x0e → T+0x6040 (cand row count) | m01 case 0x0e `0x1800E13D5` ((int)value) | tracker-top phase-2 scan bound `0x1800E0071` | r14_scan_limiter §4 | OBS |
| 5 | m01 id 0x0f → T+0x6064/+0x6068 = 0 | m01 case 0x0f `0x1800E13E9` | acceptance-band check `0x1800DFF74–0x1800DFF90` (band 0 ⇒ never "locked" ⇒ search every update; correction effectively disabled) | r14_scan_limiter §4; r14_static_findings §1.3 | OBS (behaviour DER) |
| 6 | m01 id 0x06 → T+0x5F30/0x5F34/0x5F38 (reject-hold) | m01 case 0x06 `0x1800E1396` | state 6 reject-hold `0x18013D0C0–0x18013D0CA` | r14_scan_limiter §4 | OBS |
| 7 | host scale/key tables → engine+0x4320..0x44D0 region (cand tables, bitmask) | host via port-bound thunks (no .text writer) | tracker-top search `0x1800DFFBC–0x1800E00F2`; per-candidate enable `0x1800E01B5–0x1800E01C8` | r14_static_findings §1.6 | **UNK→bounded: the filler is outside .text; the layout/pointers are OBS** |
| 8 | host 'tracking' flag (port 30) → engine+0x4510 | host | prepare reader gain default `0x1800E2653–0x1800E2657` | r14_disas_tracker_full (reader) | OBS |

## 2. Tracker state

| # | edge | producer | consumer | evidence | class |
|---|---|---|---|---|---|
| 9 | input block → 64-float input ring T+0x5DB0 (idx [0x5F0C]&0x3F) | FUN_18013BBC0 head `0x18013BBD0–0x18013BC13` | windowed-magnitude FIR over the m01 table at T+0x5EB0 (`0x18013BC40–0x18013BCAC`), level smoother | r14_disas_tracker_full (head) | OBS |
| 10 | level smoother → 2-float (magnitude, level) pair at [T+0x5FC8] | `0x18013BCF8–0x18013BD84` (coeffs T+0x5F18/0x5F1C/0x5F20 = 0.9921875/0.0078125/…, ctor values OBS) | state 6 gate `0x18013D0D3–0x18013D0ED`; state 9 confidence `0x18013D157+`; m02 id 7 meter `0x1800E1554` | r14_disas_tracker_full | OBS |
| 11 | state machine dispatch (states 0..9, one per prepare call) | jump table 0x18013D22C on [T+0x5FF8] | states: 0 linearise; 1–5 peak search; 6 period estimate; 7 tracker top; 8 recorder; 9 confidence/gate | r14_disas_tracker_full (cases 6/7/8/9); prepare call site `0x1800E20C4–0x1800E20CE` | OBS |
| 12 | peak search → history positions (ptrs [T+0x5F58]/[T+0x5F60]/[T+0x5FA8]/[T+0x5FB8], glide [T+0x5FC0]) | states 1–5 | state 6 period computation | r14_disas_tracker_full (case 6) | OBS |
| 13 | parabolic refinement FUN_18013E160 → δ·2^14 offsets | `0x18013E160–0x18013E1F5` | state 6: period = 16384·idx + (refB − refA) | r14_static_findings §1.1 | OBS |
| 14 | **period estimate → T+0x5FD4 (2^11 scale)** | state 6 store `0x18013D10E` (cfg ×2/×4, reject-hold, gate, <2048·50 → ×2) | tracker top divisor `0x1800DFE86`; recorder ring field (edge 21) | r14_static_findings §1.1 | **OBS (round-14 closure: xmm1 identified; units = input samples × 2^11, DER confirmed by reader ×2^-11)** |
| 15 | **ω = 2048·2π/T̂ → T+0x606C** | tracker top `0x1800DFEB7–0x1800DFEF7` (const = the DOUBLE 2π @0x180412400) | candidate search key; acceptance band; stability counters | r14_static_findings §1.1–§1.2 | **OBS (round-14 closure; corrects the round-13 "3370280550400.0 / ×2^11 field-0 pair" reading)** |
| 16 | candidate search → selected row [T+0x6058], pivot [T+0x6060], band [T+0x6064/+0x6068] | tracker top `0x1800DFFBC–0x1800E012B` | correction target; locked-check | r14_static_findings §1.3/§1.6 | OBS |
| 17 | confidence [T+0x5FEC] / gate [T+0x5FF0] | state 9 `0x18013D157–0x18013D1DB` (one-pole 0.99/0.7, min 1.0; gate = min([T+0x5FF4]/√conf,1)·32) | tracker-top target gate (`0x1800E0133–0x1800E0152`: conf ≤ 6e-6 ⇒ target 1.0); m02 meters' gating | r14_disas_tracker_full (case 9) | OBS |
| 18 | stability counter [T+0x6078] | tracker top `0x1800DFEEB–0x1800DFF2B` (+1 while \|Δω\| < 1.6e-4, sat 0x7FFFFF, else 0) | band narrowing `0x1800DFF56/0x1800DFF63` when counter > [[T+0x6038]+4] | r14_static_findings §1.3 | OBS |
| 19 | **correction target → T+0x6074** | tracker-top tail `0x1800E0154/0x1800E016E` (1.0 or f3/(pivot·ω)) | recorder (edge 20); m02 id 0xc meter | r14_static_findings §1.3 | **OBS (round-14 closure of the CFM §7.9 DER guesses)** |
| 20 | **dead-band + per-candidate bit + rate limiter → running gain T+0x6070** | recorder `0x1800E0190–0x1800E024E` (see r14_static_findings §1.3 for the full branch algebra); hard reset to 1.0 on \|Δω\| ≥ 4e-4 (`0x1800DFF33`); ctor init 1.0f (`0x1800E0E94`) | ring field (edge 21); m02 id 0xd meter | r14_static_findings §1.3 | **OBS (round-14 closure: exact clamp/state/reset semantics)** |

## 3. Record ring transport

| # | edge | producer | consumer | evidence | class |
|---|---|---|---|---|---|
| 21 | running gain + ids + period → 4-float record at descending indices from wdelta (mask 0xFFF) | recorder `0x1800E0246–0x1800E0355` ([wdelta−1]=gain, [wdelta−2]=id1, [wdelta−3]=id2, [wdelta−4]=period bits; wdelta ← (wdelta−4)&mask) | prepare reader (edge 22) | r14_static_findings §1.3 | **OBS (round-14: field order completed — the round-13 "first field" convention corrected)** |
| 22 | record → per-voice {period, interval, gain} | prepare reader `0x1800E25DB–0x1800E2759`: base=(page_off[v]+wdelta)&0xFFF; v=ring[base]·2^-11 (min 48, degenerate→480 fallback — **no upper clamp**); interval=(int)ring[base+1]; gain=ring[base+3] (1.0 when not tracking) | rate map (edge 23); re-arm (edge 25); per-voice table `[r11+8+interval·4]` | r14_static_findings §1.4 | **OBS (round-14 closure; corrects round-12's "[48,480]" clamp reading)** |
| 23 | **gain → rate_slot: page[0]·gain → engine+0x4128 vector** | reader `0x1800E2691–0x1800E269F` | the pitch rate map (round 9: step = P(f)·slot·64; slot = (ratio/16)·correction) | r14_static_findings §1.4; DSP_ARCHITECTURE §8 | **OBS — closes the loop: the ring IS the correction transport of the round-9 law** |
| 24 | ring field base+2 (id1) | recorder | **no reader found** in the prepare (or anywhere in .text) | r14_static_findings §1.4 | UNK (spare/diagnostic field) |

## 4. Per-voice processing, interpolation, delay and feedback

| # | edge | producer | consumer | evidence | class |
|---|---|---|---|---|---|
| 25 | period v → re-arm base + jump | reader `0x1800E269B–0x1800E2759`: idx = clamp((v−48)·0.0625, 0, 31) → page[12+idx] fade entry; jump = 2^((int)fade & 0xF)·v (+0.5 round) | the crossfade/delay-commit state machine (DSP_ARCHITECTURE S6, round-12 addendum §13) | r14_disas_tracker_full (reader window) | OBS |
| 26 | gated per-voice window (page tables) | prepare (round-12 evidence) | voice read gating | DSP_ARCHITECTURE S4; CONTROL_FLOW_MATRIX §13 | OBS (established round 12) |
| 27 | **observed kernel table → engine+0x40F0 (pitch engine) AND [obj+0xD0] (second consumer)** | FUN_1800E18B0 `0x1800E1FB4–0x1800E1FBB`; FUN_1800DBEF0..0x1800DC425 `0x1800DC287–0x1800DC28E` | the 6-tap fractional-delay reads (S5) | r14_scan_kernel_refs §1/§3 | **OBS (round-14: the table is embedded precomputed .rdata, write-never-referenced, unique in the image; second consumer newly found)** |
| 28 | variable-rate read + 6-tap interpolation → per-voice voice signal | S5 paths (round-12 instruction-level evidence) | crossfade/mixing | DSP_ARCHITECTURE S5/S6 | OBS (established round 12) |
| 29 | feedback path | (see S6/round-12) | delay ring re-read | DSP_ARCHITECTURE §6.1 | DER (established; the exact feedback tap point instruction-level OBS in round 12 for the work ring) |

## 5. Mixing, filtering and output

| # | edge | producer | consumer | evidence | class |
|---|---|---|---|---|---|
| 30 | per-voice modulation filter | FUN_1800E8B50 | voice sum | DSP_ARCHITECTURE S7 (decompile dec2_voice_fn) | OBS (established) |
| 31 | voice sum + output bus | S8 paths | module output | DSP_ARCHITECTURE S8; patch graph §6.1 | OBS (established) |
| 32 | m02 meters 0xc/0xd ← T+0x6074/T+0x6070 | FUN_1800E1520 `0x1800E1751+`/`0x1800E17E1+` (±1731.234·ln = ±1200·log2 cents, gated) | host UI/meter surface (virtual-only consumers, round 10) | r14_static_findings §1.3 | OBS (round 10 established; round 14 pins the exact source fields) |

## 6. Edge counts and the significant round-14 closures

Total edges listed: **32**. Classification: **OBS 27** (of which round-14
closures/corrections: edges 2, 3, 14, 15, 19, 20, 21, 22, 23, 27 — the
tracker-input identity, the full limiter algebra, the record field order,
the ring→rate-map closure, the kernel origin), **DER 2** (edges 5 behaviour
reading, 29 feedback tap), **UNK 3** (edges 7 host-side table filler, 24 the
id1 spare field, and the kernel's design formula as a standing item).

**The most significant newly-closed edges:**

1. **Edge 14/15** — the tracker input xmm1 = [T+0x5FD4] = the period
   estimate at the 2^11 scale, and the divisor chain produces ω = 2π/T̂
   (with the round-13 constant decode corrected to 2π).
2. **Edge 20** — the ratio limiter's complete algebra: target → per-
   candidate enable bit → ±cents dead-band → per-update multiplicative rate
   clamp (2^(±1/(12·correctrate))) → running gain, with the stability
   counter, the locked-band narrowing, the |Δω| ≥ 4e-4 hard reset, and all
   init/reset values.
3. **Edge 23** — the record ring's gain field lands exactly in the round-9
   law slot_4128 = (ratio/16)·correction: the tracker→voice correction
   transport is now OBS end-to-end.
4. **Edge 27** — the observed kernel is embedded precomputed .rdata data
   (unique, write-never-referenced), shared by the pitch engine and one
   other object.

**Contradictions resolved:** the round-13 "×2^11/÷2^11 matched pair on ring
field 0" and "3370280550400.0" constant reading (both corrected — see
`r14_static_findings.md` §1.2); the round-12 "[48,480]" re-arm clamp (a
min-clamp plus a degenerate fallback — §1.4).

**Still open (precisely bounded):** the host-side fillers of the candidate
tables (outside .text); the id1 ring field's consumer; the kernel's exact
design formula; the [T+0x5F14] cfg multiplier semantics; the second kernel
consumer object's role; all runtime behaviour (the target was never
executed).
