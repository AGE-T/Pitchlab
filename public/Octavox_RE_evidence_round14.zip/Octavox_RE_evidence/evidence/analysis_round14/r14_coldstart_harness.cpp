// OCTAVOX round 14 -- corrected cold-start harness (evidence-consistency fix).
//
// WHY THIS EXISTS (round-14 Priority 1, item 3): the round-13 cold-start
// harness (evidence/analysis_round13/r13_coldstart_harness.cpp) measured
// output pitch with the LEGACY LOG-GRID meter -- a 0.001-log2-step grid
// (1.2 cents quantisation) with NO parabolic refinement -- while the round-13
// acceptance suite used the corrected LOG-DOMAIN PARABOLIC meter. The shipped
// r13_coldstart_after.json pitch values are therefore legacy-meter values.
// This harness UNIFIES the measurement: every case reports BOTH the legacy
// and the corrected meter on the SAME signal (direct before/after evidence),
// and additionally records the engine's OWN commit sample (voiceStats
// last_commit_sample, the exact stream position of the commit) next to the
// 256-sample block-observation time the round-13 harness reported (the
// 45.3 ms vs 48 ms reconciliation, round-14 Priority 1, item 2).
//
// The corrected meter here is the suite's pitchFFT with the round-14
// window-placement fix: zero-pad (never read before the pointer) when the
// FFT size N exceeds n (n not a power of two).
//
// Build (against the round-14 library):
//   g++ -O2 -std=c++17 -I ../../native/include r14_coldstart_harness.cpp \
//       ../../native/build-r14/src/octavox_dsp.a -o /tmp/r14_coldstart
//   /tmp/r14_coldstart r14_coldstart_unified.json
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "octavox/dsp.hpp"

using namespace octavox;

// ---- deterministic generators (identical to the round-13 harness) ---------
namespace gen {
struct Lcg {
    uint64_t s;
    explicit Lcg(uint64_t seed) : s(seed * 6364136223846793005ULL + 1442695040888963407ULL) {}
    double next() {
        s = s * 6364136223846793005ULL + 1442695040888963407ULL;
        return ((s >> 11) * (1.0 / 9007199254740992.0));
    }
};
std::vector<float> tone(double f, int sr, int n, double a) {
    std::vector<float> x(n);
    for (int i = 0; i < n; ++i) x[i] = (float)(a * std::sin(2.0 * M_PI * f * i / sr));
    return x;
}
std::vector<float> noise(uint64_t seed, int n, double a) {
    Lcg r(seed);
    std::vector<float> x(n);
    for (int i = 0; i < n; ++i) x[i] = (float)((2.0 * r.next() - 1.0) * a);
    return x;
}
}  // namespace gen

// ---- measurements ----------------------------------------------------------
namespace meas {
double rms(const float* x, int n) {
    double s = 0.0;
    for (int i = 0; i < n; ++i) s += (double)x[i] * x[i];
    return std::sqrt(s / std::max(1, n));
}
bool allFinite(const float* x, int n) {
    for (int i = 0; i < n; ++i)
        if (!std::isfinite(x[i])) return false;
    return true;
}
// period-synchronous envelope modulation (identical to round 13)
double envModDb(const float* x, int n, int sr, int skip, int perW) {
    if (perW < 2) return 0.0;
    std::vector<double> env;
    for (int i0 = skip; i0 + perW <= n; i0 += perW)
        env.push_back(rms(x + i0, perW));
    if (env.size() < 3) return 0.0;
    const double mx = *std::max_element(env.begin(), env.end());
    const double mn = *std::min_element(env.begin(), env.end());
    if (mn <= 0.0) return 0.0;
    return 20.0 * std::log10(mx / mn);
}

// Radix-2 complex FFT (in-place, n a power of two) -- as in the suite.
void fft(double* re, double* im, int n) {
    for (int i = 1, j = 0; i < n; ++i) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) { std::swap(re[i], re[j]); std::swap(im[i], im[j]); }
    }
    for (int len = 2; len <= n; len <<= 1) {
        const double ang = -2.0 * M_PI / len;
        const double wr = std::cos(ang), wi = std::sin(ang);
        for (int i = 0; i < n; i += len) {
            double cr = 1.0, ci = 0.0;
            for (int k = 0; k < len / 2; ++k) {
                const double ur = re[i + k], ui = im[i + k];
                const double vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci;
                const double vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr;
                re[i + k] = ur + vr; im[i + k] = ui + vi;
                re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi;
                const double nr = cr * wr - ci * wi;
                ci = cr * wi + ci * wr; cr = nr;
            }
        }
    }
}

// CORRECTED meter: FFT peak pitch with log-domain parabolic interpolation
// (Hann window), zero-pad cap 2^18. Round-14 fix: when the FFT size N
// exceeds n (n not a power of two), the samples are placed at the END of
// the window and the head is zero-padded -- the round-13 suite form
// (off = n - N) would read BEFORE the pointer in that case.
double pitchFFT(const float* x, int n, int sr, double fmin, double fmax) {
    int N = 1;
    while (N < n && N < 262144) N <<= 1;
    if (N < 16) return 0.0;
    std::vector<double> re(N, 0.0), im(N, 0.0);
    const int off = n - N;  // may be negative when N > n (non-power-of-two n)
    for (int i = 0; i < N; ++i) {
        const int j = off + i;
        const double s = (j >= 0 && j < n) ? (double)x[j] : 0.0;  // zero-pad
        const double w = 0.5 - 0.5 * std::cos(2.0 * M_PI * i / N);
        re[i] = s * w;
    }
    fft(re.data(), im.data(), N);
    const int kmin = std::max(1, static_cast<int>(fmin * N / sr));
    const int kmax = std::min(N / 2 - 2, static_cast<int>(fmax * N / sr));
    if (kmax <= kmin) return 0.0;
    int kpeak = kmin;
    double best = 0.0;
    for (int k = kmin; k <= kmax; ++k) {
        const double m = re[k] * re[k] + im[k] * im[k];
        if (m > best) { best = m; kpeak = k; }
    }
    if (best <= 0.0) return 0.0;
    const double la = std::log(re[kpeak - 1] * re[kpeak - 1] + im[kpeak - 1] * im[kpeak - 1] + 1e-300);
    const double lb = std::log(best);
    const double lc = std::log(re[kpeak + 1] * re[kpeak + 1] + im[kpeak + 1] * im[kpeak + 1] + 1e-300);
    double d = 0.0;
    const double den = la - 2.0 * lb + lc;
    if (std::abs(den) > 1e-300) d = 0.5 * (la - lc) / den;
    if (d > 0.5) d = 0.5;
    if (d < -0.5) d = -0.5;
    return static_cast<double>(sr) * (kpeak + d) / N;
}

// LEGACY meter (VERBATIM the round-13 cold-start harness form, lines 66-91):
// Hann + direct correlation over a log-spaced grid (0.001 in log2 = 1.2 c
// steps), best-grid-point return, NO refinement. Kept to quantify the
// legacy values in r13_coldstart_after.json.
double pitchFFT_legacy(const float* x, int n, int sr, double flo, double fhi) {
    const int N = 1 << 15;
    std::vector<double> re(N, 0.0), im(N, 0.0);
    const int m = std::min(n, N);
    for (int i = 0; i < m; ++i) {
        const double w = 0.5 - 0.5 * std::cos(2.0 * M_PI * i / m);
        re[i] = (double)x[i] * w;
    }
    double bestF = 0.0, bestA = -1.0;
    const double lo = std::max(flo, 1.0), hi = fhi;
    for (double lf = std::log2(lo); lf <= std::log2(hi); lf += 0.001) {
        const double f = std::pow(2.0, lf);
        double srAcc = 0.0, siAcc = 0.0;
        for (int i = 0; i < m; ++i) {
            const double ph = 2.0 * M_PI * f * i / sr;
            srAcc += re[i] * std::cos(ph) + im[i] * 0;
            siAcc += re[i] * std::sin(ph);
        }
        const double a = srAcc * srAcc + siAcc * siAcc;
        if (a > bestA) { bestA = a; bestF = f; }
    }
    return bestF;
}
}  // namespace meas

static std::string g_json;
void jbegin() { g_json = "{\n  \"harness\": \"r14_coldstart_unified (round-14 library, corrected meter; legacy meter co-reported)\",\n  \"cases\": [\n"; }
int g_idx = 0;
void jcase(const std::string& name, const std::vector<std::pair<std::string, double>>& vals) {
    char buf[512];
    std::string j = "    {\"name\": \"" + name + "\", \"values\": {";
    for (size_t i = 0; i < vals.size(); ++i) {
        std::snprintf(buf, sizeof(buf), "\"%s\": %.10g", vals[i].first.c_str(), vals[i].second);
        j += buf;
        if (i + 1 < vals.size()) j += ", ";
    }
    j += "}}";
    if (++g_idx > 1) g_json += ",\n";
    g_json += j;
}
void jend(const char* path) {
    g_json += "\n  ]\n}\n";
    FILE* f = std::fopen(path, "wb");
    if (f) { std::fwrite(g_json.data(), 1, g_json.size(), f); std::fclose(f); }
}

double semitoneRatio(double c) { return std::pow(2.0, c / 1200.0); }

// ---- P1 cold-start matrix (unified measurement) ----------------------------
// For a fresh engine at `cents`: 3 s of 220 Hz tone; both meters on the same
// steady window; the engine's OWN first-commit sample (exact) AND the
// 256-sample block-observation boundary the round-13 harness reported.
void coldStart(const std::string& tag, double cents, int sr, double f0) {
    Config cfg;
    cfg.ratio = semitoneRatio(cents);
    cfg.sample_rate = sr;
    const int n = 3 * sr;
    const auto in = gen::tone(f0, sr, n, 0.5);
    AlignedDelayLine e;
    e.prepare(cfg);
    std::vector<float> out(n, 0.f);
    // poll every block: the commit COUNT (block observation) and the engine's
    // OWN last_commit_sample value (exact stream position of the commit)
    int firstCommitBlock = -1, block = 256;
    double engineCommitSample = -1.0;
    long lastC = 0;
    for (int i0 = 0; i0 < n; i0 += block) {
        const int m = std::min(block, n - i0);
        e.process(in.data() + i0, out.data() + i0, m);
        const VoiceStats st = e.voiceStats(0);
        if (st.commits > lastC && firstCommitBlock < 0) {
            firstCommitBlock = i0 + m;           // block-boundary observation (r13 semantics)
            engineCommitSample = (double)st.last_commit_sample;  // engine-internal, exact
        }
        lastC = st.commits;
    }
    const VoiceStats stF = e.voiceStats(0);
    std::vector<std::pair<std::string, double>> v;
    auto add = [&](const char* k, double x) { v.push_back({k, x}); };
    add("cents", cents);
    add("sr", sr);
    add("f0", f0);
    add("gain_db_first100ms",
        20.0 * std::log10(meas::rms(out.data(), sr / 10) / meas::rms(in.data(), sr / 10)));
    add("gain_db_first1s", 20.0 * std::log10(meas::rms(out.data(), sr) / meas::rms(in.data(), sr)));
    add("gain_db_steady_2to3s",
        20.0 * std::log10(meas::rms(out.data() + 2 * sr, sr) / meas::rms(in.data() + 2 * sr, sr)));
    {   // corrected meter (log-domain parabolic, fixed window placement)
        const double fm = meas::pitchFFT(out.data() + 1500 * sr / 1000, n - 1500 * sr / 1000, sr,
                                         50.0, 4000.0);
        add("pitch_error_cents", 1200.0 * std::log2(fm / f0) - cents);
    }
    {   // legacy meter (verbatim round-13 form) on the SAME signal
        const double fm = meas::pitchFFT_legacy(out.data() + 1500 * sr / 1000, n - 1500 * sr / 1000,
                                                sr, 50.0, 4000.0);
        add("pitch_error_cents_legacy_meter", 1200.0 * std::log2(fm / f0) - cents);
    }
    {
        const int perW = std::max(2, (int)std::lround(sr / f0));
        add("env_mod_db_after200ms", meas::envModDb(out.data(), n, sr, sr / 5, perW));
    }
    add("first_commit_sample_engine", engineCommitSample);
    add("first_commit_ms_engine",
        engineCommitSample < 0 ? -1.0 : 1000.0 * engineCommitSample / sr);
    add("first_commit_sample_blockobs", firstCommitBlock < 0 ? -1 : (double)firstCommitBlock);
    add("first_commit_ms_blockobs",
        firstCommitBlock < 0 ? -1.0 : 1000.0 * firstCommitBlock / sr);
    add("spacing_final", stF.spacing);
    add("commits_final", (double)stF.commits);
    add("wraps_final", (double)stF.wraps);
    add("finite", meas::allFinite(out.data(), n) ? 1.0 : 0.0);
    jcase("coldstart_" + tag, v);
}

int main(int argc, char** argv) {
    const char* outPath = "r14_coldstart_unified.json";
    if (argc > 1) outPath = argv[1];
    jbegin();
    const int sr = 48000;

    // ---- meter self-check: BOTH meters on pure reference tones -----------
    {
        const double freqs[] = {55.0, 60.0, 80.0, 110.0, 220.0, 277.18, 329.63, 440.0,
                                110.0 * std::pow(2.0, 10.0 / 1200.0),
                                220.0 * std::pow(2.0, 10.0 / 1200.0),
                                440.0 * std::pow(2.0, -10.0 / 1200.0)};
        for (double f : freqs) {
            const int n = 3 * sr;
            const auto x = gen::tone(f, sr, n, 0.5);
            const double fc = meas::pitchFFT(x.data() + 1500 * sr / 1000, n - 1500 * sr / 1000,
                                             sr, 30.0, 6000.0);
            const double fl = meas::pitchFFT_legacy(x.data() + 1500 * sr / 1000,
                                                    n - 1500 * sr / 1000, sr, 30.0, 6000.0);
            char tag[64];
            std::snprintf(tag, sizeof(tag), "metercheck_%.2f", f);
            jcase(tag, {{"f_true", f},
                        {"f_corrected", fc},
                        {"f_legacy", fl},
                        {"err_corrected_cents", 1200.0 * std::log2(fc / f)},
                        {"err_legacy_cents", 1200.0 * std::log2(fl / f)}});
        }
    }

    // ---- P1 cold-start battery (identical matrix to round 13) ------------
    const double centsList[] = {0.0, 1.0, -1.0, 10.0, -10.0, 50.0, -50.0, 100.0, -100.0, 500.0, -500.0, 1200.0, -1200.0};
    for (double c : centsList) {
        char tag[32]; std::snprintf(tag, sizeof(tag), "%+gc_220hz", c);
        coldStart(tag, c, sr, 220.0);
    }
    coldStart("+10c_110hz", 10.0, sr, 110.0);
    coldStart("-10c_440hz", -10.0, sr, 440.0);

    // reset/restart determinism at each ratio (unchanged measurement)
    {
        for (double c : centsList) {
            Config cfg; cfg.ratio = semitoneRatio(c);
            const auto in = gen::tone(220.0, sr, sr, 0.5);
            AlignedDelayLine a, b;
            a.prepare(cfg); b.prepare(cfg);
            std::vector<float> oa(sr, 0.f), ob(sr, 0.f), ob2(sr, 0.f);
            a.process(in.data(), oa.data(), sr);
            b.process(in.data(), ob.data(), sr);
            b.reset();
            b.process(in.data(), ob2.data(), sr);
            double d = 0.0;
            for (int i = 0; i < sr; ++i)
                d = std::max(d, std::abs((double)oa[i] - ob[i]));
            double d2 = 0.0;
            for (int i = 0; i < sr; ++i)
                d2 = std::max(d2, std::abs((double)ob[i] - ob2[i]));
            char tag[32]; std::snprintf(tag, sizeof(tag), "reset_restart_%+gc", c);
            jcase(tag, {{"cents", c}, {"fresh_vs_fresh", d}, {"reset_vs_fresh", d2}});
        }
    }

    // ---- rate battery with BOTH meters (the r13 harness's rate cases) ----
    {
        const int rates[] = {44100, 48000, 96000, 192000};
        const double freqs[] = {55.0, 60.0, 80.0, 110.0, 220.0, 440.0};
        for (int rsr : rates) {
            for (double f : freqs) {
                Config cfg;
                cfg.sample_rate = rsr;
                cfg.ratio = semitoneRatio(400.0);
                const int n = 3 * rsr;
                const auto in = gen::tone(f, rsr, n, 0.5);
                AlignedDelayLine e;
                const bool ok = e.prepare(cfg);
                std::vector<float> out(n, 0.f);
                e.process(in.data(), out.data(), n);
                const double fm = meas::pitchFFT(out.data() + rsr, 2 * rsr, rsr, 30.0, 6000.0);
                const double fl = meas::pitchFFT_legacy(out.data() + rsr, 2 * rsr, rsr, 30.0, 6000.0);
                char tag[64];
                std::snprintf(tag, sizeof(tag), "rate_%d_f%.0f", rsr, f);
                jcase(tag, {
                    {"prepared", ok ? 1.0 : 0.0},
                    {"last_estimate_hz", e.lastEstimateHz()},
                    {"pitch_error_cents", 1200.0 * std::log2(fm / f) - 400.0},
                    {"pitch_error_cents_legacy_meter", 1200.0 * std::log2(fl / f) - 400.0},
                    {"finite", meas::allFinite(out.data(), n) ? 1.0 : 0.0},
                });
            }
            {
                Config cfg;
                cfg.sample_rate = rsr;
                cfg.ratio = semitoneRatio(400.0);
                const int n = rsr;
                const auto in = gen::noise(9, n, 0.5);
                AlignedDelayLine e;
                e.prepare(cfg);
                std::vector<float> out(n, 0.f);
                e.process(in.data(), out.data(), n);
                char tag[64];
                std::snprintf(tag, sizeof(tag), "rate_%d_noise", rsr);
                jcase(tag, {{"last_estimate_hz", e.lastEstimateHz()},
                            {"finite", meas::allFinite(out.data(), n) ? 1.0 : 0.0}});
            }
        }
    }

    jend(outPath);
    std::printf("wrote %s (%d cases)\n", outPath, g_idx);
    return 0;
}
