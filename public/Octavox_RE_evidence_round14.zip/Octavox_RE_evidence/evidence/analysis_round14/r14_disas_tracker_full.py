#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OCTAVOX round 14 -- full annotated disassembly of the tracker-top / recorder
cluster (0x1800DFE80..0x1800E0355), the case-6 writer of tracker+0x5FD4 in
FUN_18013BBC0, the parabolic-refinement helper FUN_18013E160, the tracker-init
helper 0x180161700, and the engine-ctor tracker window.

Round-13 residues addressed here:
  * xmm1 at the `comiss xmm1, xmm9` (0x1800DFEB1): producer chain + units.
  * the ratio limiter (+0x6070/+0x6044/+0x6048) semantics.
  * CORRECTION of the round-13 constant annotation: the mulsd at 0x1800DFEC2
    loads the DOUBLE 6.283185307179586 (2*pi) at 0x180412400 -- the round-13
    note "3370280550400.0" is the FLOAT32 interpretation of the low half of
    that double (0x54442D18 -> 3.3702806e12).  This script decodes BOTH the
    f32 and f64 at every resolved data target so the error cannot recur.

Read-only. Target is NEVER executed. SHA-256 verified before and after.
Output: r14_disas_tracker_full.txt

v2 (final round-14 version): added the tracker state machine
FUN_18013BBC0 head + dispatch + cases 7/8/9 (documents WHEN the tracker top
and the recorder/limiter run, and the provenance of xmm6=FLT_EPSILON /
xmm7=1.0 used in case 6), and the FULL prepare record reader
0x1800E25DB..0x1800E2762 (documents WHERE the clamped gain goes: the
per-voice rate slot = page[0] * ring[base+3], plus the period field's
clamp semantics).  Case 0 of the state machine (0x18013BE73..0x18013C1F3,
the unrolled ring linearisation) is omitted for brevity -- it contains no
tracker-field references beyond [0x5F50]/[0x5F48]/[0x5F40]/[0x5FFC] which
are annotated in r14_scan_limiter.txt Section 8.

v3 (round-14 P2-A, audited + extended): every window re-verified against a
fresh independent disassembly; ctor window label now carries the
r14/rsi/rbx provenance of the cand tables ([0x6018]/[0x6020] =
engine+0x4320/+0x4328 ladder, [0x6028]/[0x6030] = engine+0x4370/+0x4388 row
table, [0x6038] = engine+0x44A0 bitmask+threshold -- all ctor-zeroed,
filled via the port-bound engine region); ADDED the prepare head excerpt
window 0x1800E2094..0x1800E2185 (state-machine call site + the reader's
xmm5=2^-47 / xmm6=48.0 / xmm9=0.5 constant setup).
"""

import bisect
import hashlib
import struct
import sys

import capstone

TARGET = "/home/z/octavox/original/Ox.vst3"
OUT = ("/home/z/octavox/work/Octavox_RE_evidence/evidence/"
       "analysis_round14/r14_disas_tracker_full.txt")
SHA_EXPECT = "7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2"

# (label, start, end, note)
RANGES = [
    ("FUN_1800DFE80 -- tracker top + candidate search (logical fn; "
     ".pdata chunks 0x1800DFE80..0x1800E0188)",
     0x1800DFE80, 0x1800E0188),
    ("FUN_1800E0190 -- the recorder (ring writer; NO .pdata entry of its "
     "own -- covered by the gap sweep; body 0x1800E0190..0x1800E0355)",
     0x1800E0190, 0x1800E0356),
    ("FUN_18013BBC0 case 6 -- the writer of tracker+0x5FD4 "
     "(.pdata chunk 0x18013C85E..0x18013D1FB)",
     0x18013CEC0, 0x18013D130),
    ("FUN_18013BBC0 head -- input ring (tracker+0x5DB0, 64 floats, index "
     "[0x5F0C]&0x3F), windowed-magnitude FIR over the m01 table at "
     "tracker+0x5EB0, level smoother ([0x5F18]/[0x5F1C]/[0x5F20]), 512-float "
     "level-history ring at tracker+0x800 (index [0x6004]&0x1FF), and the "
     "STATE DISPATCH on [0x5FF8] (jump table 0x18013D22C, states 0..9); "
     "xmm6=FLT_EPSILON (0x180411E54) and xmm7=1.0 (0x18041213C) are set "
     "here, BEFORE the dispatch -- so in case 6 the comiss 2048.0, xmm7 at "
     "0x18013D07F is 2048-vs-1.0, i.e. the *2048 path is unconditional",
     0x18013BBC0, 0x18013BE73),
    ("FUN_18013BBC0 cases 7/8/9 -- state 7 CALLS the tracker top "
     "(0x1800DFE80) -> state 8; state 8 CALLS the recorder (0x1800E0190: "
     "the ratio limiter + record-ring write) -> state 9; state 9 updates "
     "the confidence [0x5FEC] (one-pole toward the level, rates 0.99/0.7, "
     "min 1.0) and the gate [0x5FF0] = min([0x5FF4]/sqrt(conf),1)*32 and "
     "returns to state 0.  One state per call; the state machine is called "
     "once per prepare() (0x1800E20CE).  Case 0 = ring linearisation -> "
     "state 1 (peak search, states 1..5); case 6 = period estimate -> state 7",
     0x18013D127, 0x18013D1FB),
    ("FUN_18013E160 -- parabolic sub-entry peak refinement "
     "(no .pdata entry of its own; body 0x18013E160..0x18013E1F5)",
     0x18013E160, 0x18013E1F6),
    ("0x180161700 -- tracker init helper called with (tracker, 0, 0x5EB0) "
     "(.pdata 0x180161700..0x180161890)",
     0x180161700, 0x180161890),
    ("engine ctor tracker window (.pdata fn 0x1800E0360..0x1800E10AC).  "
     "r14/rsi/rbx provenance at the cand-table stores (0x1800E0E54..0x1800E0E78): "
     "r14 = engine+0x4320 (lea r14,[r8+0x10] with r8=engine+0x4310, the sub-object "
     "whose 64-byte inline array engine+0x4320..0x4360 = 8 x {f32 threshold, f32 "
     "value} ladder slots, zeroed by the four movups at 0x1800E0BF8..0x1800E0C01) "
     "-> [0x6018]=engine+0x4320, [0x6020]=engine+0x4328; rsi = engine+0x4370 (lea "
     "rsi,[rdi+0x10], rdi=engine+0x4360; memset(engine+0x4370,0,0x120) at "
     "0x1800E0C42 zeroes up to 12 x 6-float cand rows) -> [0x6028]=engine+0x4370, "
     "[0x6030]=engine+0x4388; rbx = engine+0x44A0 (lea rbx,[r8+0x10], r8=engine+"
     "0x4490; 0x30 bytes zeroed) -> [0x6038]=engine+0x44A0 = {dword bitmask, int "
     "threshold}.  No displacement-visible writer fills these engine regions "
     "after the ctor zeroing (see r14_scan_limiter.txt Section 4: they sit in "
     "the port-bound thunk region engine+0x4330..0x4510).",
     0x1800E0C90, 0x1800E0F00),
    ("prepare FUN_1800E2030 -- the record reader, the CONSUMER of the "
     "clamped gain and of the period field (base = (page_off[v] + wdelta) "
     "& 0xFFF; page_off[v] from the engine+0x42F8 int table): "
     "v = ring[base]*2^-11 -> 480.0 if v < 2^-47 else max(v, 48.0) (NO upper "
     "clamp; 480 is only the zero-record fallback); interval = (int)ring[base+1]; "
     "gain = ring[base+3] -> forced to 1.0 when engine+0x4510 (host 'tracking' "
     "flag, port 30) == 0; rate_slot[v] = page[0] * gain (fallback page[0] if "
     "the product < 2^-47) stored via the engine+0x4128 vector; "
     "idx = clamp((v-48)*0.0625, 0, 31) -> page[12+idx] fade table; "
     "jump = 2^( (int)page[12+idx] & 0xF ) * v (floor with +0.5) -- the "
     "re-arm jump distance",
     0x1800E25DB, 0x1800E2762),
    ("FUN_1800E2030 prepare head excerpt -- the tracker STATE-MACHINE CALL SITE "
     "(0x1800E20C4 lea rcx,[rsi+0x4518]; 0x1800E20CB mov r8b,1; 0x1800E20CE call "
     "FUN_18013BBC0 -- once per prepare, one state per call) and the RECORD "
     "READER'S CONSTANT SETUP: xmm5 = 2^-47 = 7.105427357601002e-15 @0x1800E20FD "
     "(0x180411E44 -- the SAME epsilon as comiss xmm1,xmm9 @0x1800DFEB1 and the "
     "recorder's xmm3), xmm6 = 48.0 @0x1800E2148 (0x180412688), xmm9 = 0.5 "
     "@0x1800E217B (0x180412058, the re-arm jump round-half-up addend)",
     0x1800E2094, 0x1800E2185),
]

# tracker-field names for auto-annotation (base = tracker = engine+0x4518)
FLD = {
    0x5F14: "cfg (==4 -> x2, ==8 -> x4 in case 6)",
    0x5F30: "reject-hold flag (>=0 keeps old estimate)",
    0x5F58: "history buffer begin ptr",
    0x5F60: "history buffer end/base ptr",
    0x5F70: "m01 case1 field",
    0x5F74: "m01 case1 field",
    0x5F90: "tracker state (case5/6 scalar)",
    0x5F98: "position ptr A",
    0x5FA0: "last peak value",
    0x5FA8: "position ptr B",
    0x5FB0: "counter A",
    0x5FB4: "counter B",
    0x5FB8: "position ptr C",
    0x5FC0: "glide state",
    0x5FC8: "ptr to 2-float (magnitude, level)",
    0x5FD0: "gatelevel",
    0x5FD4: "PERIOD ESTIMATE x 2^11 (input samples)",
    0x5FD8: "record ring base (engine+0x98)",
    0x5FE0: "ring mask 0xFFF",
    0x5FE4: "ring write index (wdelta)",
    0x5FE8: "tracking flag",
    0x5FEC: "confidence/magnitude",
    0x5FF4: "scalar state",
    0x5FF8: "state machine id",
    0x6008: "2048.0 = 2^11",
    0x6018: "cand table ptr 1",
    0x6020: "cand table ptr 2",
    0x6028: "cand table ptr 3 (6-float rows)",
    0x6030: "cand table ptr 4",
    0x6038: "ptr (bitmask word + int threshold at +4)",
    0x6040: "cand table row count",
    0x6044: "ratio clamp HI  (2^(+1/(12*correctrate)))",
    0x6048: "ratio clamp LO  (2^(-1/(12*correctrate)))",
    0x604C: "dead-band HI edge",
    0x6050: "dead-band LO edge",
    0x6058: "selected cand row ptr",
    0x6060: "selected cand row value",
    0x6064: "acceptance band LO (omega units)",
    0x6068: "acceptance band HI (omega units)",
    0x606C: "raw angular frequency omega = 2048*2pi/[0x5FD4]",
    0x6070: "running correction gain (ratio-limited)",
    0x6074: "instantaneous correction target",
    0x6078: "stability counter",
}


def load():
    with open(TARGET, "rb") as f:
        data = f.read()
    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    coff = e_lfanew + 4
    machine, nsec = struct.unpack_from("<HH", data, coff)
    opt_sz = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    opt = coff + 20
    image_base = struct.unpack_from("<Q", data, opt + 24)[0]  # PE32+
    sec_off = e_lfanew + 24 + opt_sz
    sections = {}
    for i in range(nsec):
        o = sec_off + 40 * i
        name = data[o:o + 8].rstrip(b"\x00").decode("ascii", "replace")
        vsize, vaddr, rsize, roff = struct.unpack_from("<IIII", data, o + 8)
        sections[name] = (vaddr, vsize, roff, rsize)
    return data, image_base, sections


def main():
    sha_before = hashlib.sha256(open(TARGET, "rb").read()).hexdigest()

    data, image_base, sections = load()

    def va2fo(va):
        rva = va - image_base
        for name, (vaddr, vsize, roff, rsize) in sections.items():
            if vaddr <= rva < vaddr + vsize:
                return roff + (rva - vaddr)
        return None

    def section_of(va):
        rva = va - image_base
        for name, (vaddr, vsize, roff, rsize) in sections.items():
            if vaddr <= rva < vaddr + vsize:
                return name
        return None

    # .pdata function table
    pdata = sections[".pdata"]
    raw = data[pdata[2]:pdata[2] + pdata[3]]
    funcs = []
    for i in range(0, len(raw) - 11, 12):
        s, e, _u = struct.unpack_from("<III", raw, i)
        if s == 0:
            break
        funcs.append((image_base + s, image_base + e))
    funcs.sort()
    starts = [f[0] for f in funcs]

    def chunks_covering(lo, hi):
        out = []
        for fs, fe in funcs:
            if fs < hi and fe > lo:
                out.append((fs, fe))
        return out

    tv, _ts, t_off, t_rsz = sections[".text"]
    TVA = image_base + tv
    blob = data[t_off:t_off + t_rsz]

    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    md.detail = True

    out = []
    out.append("OCTAVOX round 14 -- full tracker/recorder/case-6 disassembly "
               "(read-only, static)")
    out.append(f"target: {TARGET}")
    out.append(f"sha256 (before): {sha_before}  "
               f"(expected {SHA_EXPECT}: "
               f"{'MATCH' if sha_before == SHA_EXPECT else 'MISMATCH!'})")
    out.append("")

    for label, lo, hi in RANGES:
        out.append("=" * 78)
        out.append(f"### {label}")
        for fs, fe in chunks_covering(lo, hi):
            out.append(f"    .pdata chunk: {fs:#x}..{fe:#x}")
        out.append("=" * 78)
        for insn in md.disasm(blob[lo - TVA:hi - TVA], lo):
            ann = ""
            # rip-relative resolution with value decoding
            if "rip" in insn.op_str:
                for op in insn.operands:
                    if (op.type == capstone.x86.X86_OP_MEM
                            and op.mem.base == capstone.x86.X86_REG_RIP):
                        tgt = insn.address + insn.size + op.mem.disp
                        sec = section_of(tgt)
                        val = ""
                        fo = va2fo(tgt)
                        if fo is not None and sec not in (".text", None):
                            f32 = struct.unpack_from("<f", data, fo)[0]
                            f64 = struct.unpack_from("<d", data, fo)[0]
                            q = struct.unpack_from("<Q", data, fo)[0]
                            val = (f" [f32={f32!r} f64={f64!r}"
                                   f" q={q:#018x}]")
                        ann = f"    ; -> {tgt:#x} ({sec}){val}"
            # tracker-field annotation
            for op in insn.operands:
                if op.type == capstone.x86.X86_OP_MEM:
                    d = op.mem.disp
                    if d in FLD and op.mem.base != capstone.x86.X86_REG_RIP:
                        base = insn.reg_name(op.mem.base) if op.mem.base else ""
                        ann += f"    ; T+{d:#x} = {FLD[d]}"
                        break
            is_store = insn.op_str.split(",")[0].strip().startswith(
                ("dword ptr [", "qword ptr [", "byte ptr [", "word ptr ["))
            tag = "  <== STORE" if (insn.mnemonic.startswith("mov")
                                    and is_store) else ""
            out.append(f"{insn.address:#x}  {insn.mnemonic:10s} "
                       f"{insn.op_str}{ann}{tag}")
        out.append("")

    sha_after = hashlib.sha256(open(TARGET, "rb").read()).hexdigest()
    out.append(f"sha256 (after):  {sha_after}  "
               f"({'MATCH' if sha_after == SHA_EXPECT else 'MISMATCH!'})")
    out.append("target was read only; never executed")

    text = "\n".join(out)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(text + "\n")
    print(f"wrote {OUT} ({len(out)} lines)")
    print(f"sha before/after: {sha_before} / {sha_after}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
