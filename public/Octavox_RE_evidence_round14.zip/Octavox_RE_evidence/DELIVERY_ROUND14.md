# OCTAVOX ROUND 14 DELIVERY

Continued from `Octavox_RE_evidence_round13.zip` (SHA-256
`234ad5721afbcbd14c77858de1aa244ae34c68b1d42b39199b62dceb9f61bb30`, verified
intact on arrival; 308/308 manifest records OK after extraction). This file
documents the round-14 package: contents, verification, the delivery report
and the known limits.

## Contents (manifest delta vs round 13)

* **335 files (round 13: 308).** The archive holds **336 entries** (the
  root `checksums.txt` + the 335 project files under `Octavox_RE_evidence/`).
  Delta: 294 files unchanged in role; new — 23 evidence files under
  `evidence/analysis_round14/` (static scans + the corrected cold-start
  harness + the re-run suites + the interpolation comparison), the
  round-14 findings document, this delivery file, `native/VST3_READINESS.md`,
  `native/bench/interp_compare.cpp` (27 new in total); updated (14, all
  with explicit round-14 addenda/corrections): `DELIVERY_ROUND13.md`,
  `README.md`, the seven canonical docs (incl.
  `OCTAVOX_ROUND13_FINDINGS.md` with in-place `[ROUND-14 CORRECTION]`
  annotations), and the native tree (CMake 14.0.0 + the
  `octavox_interp_compare` target, the suite meter fix in
  `tests/test_main.cpp`, the version string, `README.md`/`ARCHITECTURE.md`).
* The Python reference implementations (`poc/`) and every historical
  evidence directory (rounds 6–13) are byte-identical to the round-13
  archive (manifest-verified; the round-11/12 result JSONs that this
  round's re-runs would have overwritten were restored from the round-12
  archive and the re-runs archived separately as `r14_rerun_*`).

## Verification (all from the shipped tree)

The manifest sits at the archive **root** (paths relative to
`Octavox_RE_evidence/`):

```sh
# after extracting the zip (root contains checksums.txt + Octavox_RE_evidence/)
cd Octavox_RE_evidence
sha256sum -c ../checksums.txt          # 335/335 OK
sha256sum ../Octavox_RE_evidence_round14.zip    # this round's own digest
sha256sum Octavox_RE_evidence_round13.zip       # 234ad572... (preserved)

cd native
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
./build/octavox_tests --json ../evidence/analysis_round14/r14_native_tests.json
      # 105/105, exit 0 (~10 s CPU on the 2-core dev sandbox; run from native/)
./build/octavox_interp_compare --json ../evidence/analysis_round14/r14_interp_compare.json \
                               --txt  ../evidence/analysis_round14/r14_interp_compare.txt
      # the four-mode comparison; recommendation computed last
cmake -S . -B build-asan -DCMAKE_BUILD_TYPE=Debug -DENABLE_SANITIZERS=ON
cmake --build build-asan -j
./build-asan/octavox_tests --json ../evidence/analysis_round14/r14_native_tests_asan.json
      # 105/105, exit 0, ZERO sanitizer reports (89.7 s)
# the corrected cold-start harness (unified meter + engine commit sample):
g++ -O2 -std=c++17 -I ../native/include \
    ../evidence/analysis_round14/r14_coldstart_harness.cpp \
    build/liboctavox_dsp.a -lm -o /tmp/r14_coldstart
(cd ../evidence/analysis_round14 && /tmp/r14_coldstart r14_coldstart_unified.json)
cd ..
python3 evidence/analysis_round11/r11_numeric_audit.py        # exit 0 (14 verdicts PASS)
python3 evidence/analysis_round11/r11_acceptance_tests.py    # 45/45 (~2.5 min)
python3 evidence/analysis_round12/r12_native_metrics.py \
    --poc poc --native-cli native/build/octavox_cli          # 15/15 gates
/home/z/.venv/bin/python evidence/analysis_round14/r14_disas_tracker_full.py   # static scans
/home/z/.venv/bin/python evidence/analysis_round14/r14_scan_limiter.py        # (read-only;
/home/z/.venv/bin/python evidence/analysis_round14/r14_scan_kernel_refs.py    #  target at
#  /home/z/octavox/original/Ox.vst3, sha256 7bb260f6... verified before/after)
```

## Delivery report

Completed:

* **Priority 1 (evidence consistency):** all four round-13 inconsistencies
  corrected with machine-readable before/after — the file count (305 → 334
  records this round / 308 then; the round-13 verification command fixed to
  match the archive layout), the cold-start timing reconciliation (engine
  commit sample 2175 = 45.3125 ms vs the harness's 256-sample block
  observation 2304 = 48.0 ms — the same event; first reliable estimate
  42.7 ms, commit 2 control intervals later), the pitch-meter discrepancy
  (the cold-start harness's legacy log-grid meter confirmed and quantified:
  ≤ 0.596 c self-error vs the corrected meter's ≤ 0.082 c; every case
  co-measured with both meters; the engine's true cold-start pitch error
  ≤ 0.018 c), and the affected tables recalculated with explicit
  `[ROUND-14 CORRECTION]` annotations. The round-13 package is preserved
  byte-identically.
* A **latent suite-meter window-placement bug** found and fixed
  (non-power-of-two windows read before the handed pointer; probe +1200 c
  failure case); re-run: 105/105 with identical verdicts
  (`r14_native_tests_vs_r13.txt` — the full numeric delta list).
* **Priority 2 (static):** the tracker input `xmm1` = tracker+0x5FD4 = the
  period estimate at the 2¹¹ scale (state-6 writer fully decoded); the
  divisor constant = the **double 2π** (round-13's "3370280550400.0" was a
  float32 misread — corrected); the **ratio limiter fully decoded** (dead
  band, per-update clamps, stability counter, hard reset, all init values)
  with its output proven to be the round-9 `correction` (the ring→rate-map
  transport closed end-to-end); the ×2¹¹/÷2¹¹ pair relocated to the period
  path; the reader's re-arm handling corrected (min-clamp 48 + degenerate
  fallback 480, no upper clamp); the observed kernel proven **embedded
  precomputed .rdata**; a 32-edge path matrix (27 OBS / 2 DER / 3 UNK).
* **Priority 3 (interpolation benchmarking):** all four modes measured
  head-to-head on identical deterministic signals with the meter's own
  error quantified first; **the default stays Lagrange6** (15–22 dB better
  small-shift tone THD+N than every alternative; ObsKernel6 shows no
  measured advantage on any metric; Linear's only win is CPU) — no new
  mode, no default change, tradeoffs stated.
* **Priority 4 (readiness):** `native/VST3_READINESS.md` — the
  parameter-surface gap analysis for an eight-voice harmonizer (quality
  ready, API not: per-voice intervals/levels/delays, wet/dry, bypass,
  smoothing) + the verified toolchain status (SDK absent locally,
  repository reachable; headless validator path) + a three-phase plan. No
  placeholder wrapper built.
* **Re-runs from the package (mandate):** r11 audit exit 0 (14 verdicts
  PASS); r11 acceptance 45/45 (2 m 31 s); r12 metrics 15/15 gates;
  ASan+UBSan 105/105 zero reports. Archived as `r14_rerun_*` with the
  untouched originals restored byte-identically.

Known limits / open:

* The observed kernel's exact design formula remains UNK (no generator
  code, no source table in the image — the BH-windowed-sinc fit stays a
  0.3 % RMS approximation).
* Remaining bounded UNKs: the ring's base+2 field consumer; the
  `[T+0x5F14]` cfg multiplier semantics; the second kernel consumer
  object's role; the host-side fillers of the candidate tables.
* All runtime questions about the original plugin remain UNK (it was never
  executed; the controlled Windows-host tests remain the way to close
  them).
* The interpolation comparison is one machine's measurement (2-core
  sandbox, getrusage, best-of-3; per-case values in the JSON); the
  multivoice env-modulation 14.8 dB is the spread voices' beating
  (engine property, identical across modes); noise through the dual-tap
  blend is ~−3 dB RMS by design (documented class).

No test in this round failed to complete; every gate result above is from
an actual run recorded in the shipped JSON files.
