# Round-9 delivery note

This ZIP (`Octavox_RE_evidence_round9.zip`) is the round-9 edition of the Octavox
reverse-engineering evidence package. It supersedes `Octavox_RE_evidence_round8.zip`
(SHA-256 `04fe8f948e20812f533d3a4e32bbb8bac483593cea80451c8f8aa4875f33d445`, preserved
read-only in the source environment) and is a complete, self-verifiable snapshot: nothing
else is required except the target binary.

## Contents (226 files + `checksums.txt`)

| path | role |
|---|---|
| `README.md` | package front door — updated for round 9 |
| `docs/OCTAVOX_ROUND9_FINDINGS.md` | **new** — the round-9 result: Q-7 closed, `R = ratio/64` refuted (→ `ratio/16`) |
| `docs/` (8 canonical docs + companions) | `OCTAVOX_OPEN_QUESTIONS.md`, `OCTAVOX_CONTROL_FLOW_MATRIX.md`, `OCTAVOX_DSP_ARCHITECTURE.md`, `OCTAVOX_RESEARCH_EVIDENCE_MATRIX.md` updated for round 9; every other doc is byte-identical to round 8 |
| `evidence/analysis_round9/` | **new** — the 33 raw round-9 artifacts (`r9_scan.py`, 30 × `r9_*.txt`, `decompile_1800E7DF0.json` + `.err`), produced read-only from the shipped image bytes; cited by bare file name in the round-9 docs |
| `evidence/` (records, decompiles, tools) | unchanged from round 8 |
| `poc/` | unchanged from round 8 (our own DSP implementation — never the target) |
| `OCTAVOX_AGENT_HANDOVER_REPORT.md` | **new** — the round-8 environment acceptance report (status **GO**) |
| `checksums.txt` | **regenerated** for this edition (see below) |

## Manifest

`checksums.txt` was regenerated for the round-9 edition in the same format as round 8
(sha256sum manifest, CRLF line endings, case-insensitive path order). Compared with the
round-8 manifest:

* **185 files byte-identical** to round 8 (identical hashes — verifiable by diffing the
  two manifests);
* **5 files updated** by round 9: `README.md`, `docs/OCTAVOX_OPEN_QUESTIONS.md`,
  `docs/OCTAVOX_CONTROL_FLOW_MATRIX.md`, `docs/OCTAVOX_DSP_ARCHITECTURE.md`,
  `docs/OCTAVOX_RESEARCH_EVIDENCE_MATRIX.md`;
* **36 files new**: `docs/OCTAVOX_ROUND9_FINDINGS.md`, the 33
  `evidence/analysis_round9/` artifacts, `OCTAVOX_AGENT_HANDOVER_REPORT.md`, and this note.

The round-8 manifest itself is preserved inside `Octavox_RE_evidence_round8.zip`.

## Verification

```sh
unzip Octavox_RE_evidence_round9.zip
cd Octavox_RE_evidence
sha256sum -c checksums.txt        # 226/226 OK expected
```

The SHA-256 of the ZIP file itself is published alongside it (sidecar file
`Octavox_RE_evidence_round9.zip.sha256`).

## Not included (by design)

* **The target binary `Ox.vst3`** (5 307 392 bytes, SHA-256
  `7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2`) — transfer it from
  the round-8 handover channel; it is byte-identical to the image every record in this
  package was produced from. It was never modified and never executed.
* Environment/acceptance scripts (`rea_env.sh`, `run_*.sh`, survival tests) —
  environment-specific; the acceptance report documents the environment, the tool
  versions (REA 6.7.0, Ghidra 12.1.4) and the exact reproduction commands.

## Provenance

* Built 2026-10-23 from the working tree `/home/z/octavox/work/Octavox_RE_evidence/`
  after round 9 (Q-7 closed; corrections recorded in
  `docs/OCTAVOX_RESEARCH_EVIDENCE_MATRIX.md` §13, correction log).
* Originals were preserved read-only throughout and re-verified unchanged at delivery
  time: `Ox.vst3` `7bb260f6…`, `Octavox_RE_evidence_round8.zip` `04fe8f94…`.
* Static analysis only (REA 6.7.0 + Ghidra 12.1.4). The target was never executed;
  runtime questions remain open exactly as documented in `docs/OCTAVOX_OPEN_QUESTIONS.md`.
