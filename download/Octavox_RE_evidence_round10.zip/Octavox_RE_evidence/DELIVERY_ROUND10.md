# Round-10 delivery note

This ZIP (`Octavox_RE_evidence_round10.zip`) is the round-10 edition of the Octavox
reverse-engineering evidence package. It supersedes
`Octavox_RE_evidence_round9.zip` (SHA-256
`cf76ae6021075f587b212aaf8a6c74d48163866bf52e9a48dd49a95b64bbac35`) and is a complete,
self-verifiable snapshot: nothing else is required except the target binary.

## Contents (243 files + `checksums.txt`)

| path | role |
|---|---|
| `README.md` | package front door — updated for round 10 |
| `docs/OCTAVOX_ROUND10_FINDINGS.md` | **new** — round 10: the round-9 mathematics validated (example cent values corrected), the proven random-modulation range, and the tracker read-outs 12/13 data path |
| `docs/` (canonical docs) | `OCTAVOX_ROUND9_FINDINGS.md`, `OCTAVOX_DSP_ARCHITECTURE.md`, `OCTAVOX_CONTROL_FLOW_MATRIX.md` (new §12), `OCTAVOX_RESEARCH_EVIDENCE_MATRIX.md` (rows R-51–R-58 + round-10 correction log), `OCTAVOX_OPEN_QUESTIONS.md` updated; every other doc unchanged from round 9 |
| `evidence/analysis_round10/` | **new** — the 16 raw round-10 artifacts (fresh capstone decoders `r10_*.py`, results `r10_*.txt`, the REA/Ghidra verification decompile `r10_decompile_1800E1520.json`, evidence `ev_d6c81933…`) |
| `evidence/analysis_round9/` | the round-9 raw artifacts — unchanged |
| `evidence/` (records, decompiles, tools), `poc/` | unchanged since round 8 |
| `OCTAVOX_AGENT_HANDOVER_REPORT.md` | the round-8 environment acceptance report (status **GO**) — unchanged |
| `checksums.txt` | **regenerated** for this edition (CRLF sha256sum manifest, case-insensitive path order) |

## Manifest

Compared with the round-9 manifest: **219 files byte-identical**, **6 files updated** by round 10
(`README.md`, `docs/OCTAVOX_ROUND9_FINDINGS.md`, `docs/OCTAVOX_DSP_ARCHITECTURE.md`,
`docs/OCTAVOX_CONTROL_FLOW_MATRIX.md`, `docs/OCTAVOX_RESEARCH_EVIDENCE_MATRIX.md`,
`docs/OCTAVOX_OPEN_QUESTIONS.md`), **18 files new** (`DELIVERY_ROUND10.md`,
`docs/OCTAVOX_ROUND10_FINDINGS.md`, the 16 `evidence/analysis_round10/` artifacts), and
**1 removed** (the superseded `DELIVERY_ROUND9.md`, replaced by this note). The round-9 manifest
is preserved inside `Octavox_RE_evidence_round9.zip`.

## Verification

```sh
unzip Octavox_RE_evidence_round10.zip
cd Octavox_RE_evidence
sha256sum -c checksums.txt        # 243/243 OK expected
```

The SHA-256 of the ZIP itself is published alongside it (sidecar file
`Octavox_RE_evidence_round10.zip.sha256`).

## Not included (by design)

* **The target binary `Ox.vst3`** (5 307 392 bytes, SHA-256
  `7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2`) — transfer it from the
  round-8 handover channel; it is byte-identical to the image every record in this package was
  produced from. It was never modified and never executed.
* Environment/acceptance scripts — environment-specific; the acceptance report documents the
  environment and the tool versions (REA 6.7.0, Ghidra 12.1.4).

## Provenance

* Built 2026-10-23 from the working tree `/home/z/octavox/work/Octavox_RE_evidence/` after round 10
  (round-9 mathematics validated and corrected; tracker read-outs 12/13 traced end to end).
* Originals preserved read-only throughout and re-verified unchanged at delivery time:
  `Ox.vst3` `7bb260f6…`, `Octavox_RE_evidence_round8.zip` `04fe8f94…`.
* Static analysis only (fresh capstone decodes + raw-byte displacement scans + one REA/Ghidra
  verification decompile + one numerical verification script with constants decoded from the
  target's bit patterns). The target was never executed; runtime questions remain open exactly as
  documented in `docs/OCTAVOX_OPEN_QUESTIONS.md` — no PoC result is substituted for a target
  measurement.
