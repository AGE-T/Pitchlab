# OCTAVOX_DSP_DEMO_USAGE

**How to run the round-6 independent demo (WAV → WAV) and the design comparison**

Everything described here is **our own implementation**. It contains no target code, and no number
produced by it is a measurement of the target. The target was never executed.

---

## 1. What is in the demo

| design | module | family | status |
|---|---|---|---|
| `delayline` | `poc/octavox_poc.py` (`OctavoxPoC`) | variable-rate two-tap delay line with crossfaded re-arm — the **reconstructed target architecture** | reference design / regression baseline |
| `pv` | `poc/octavox_offline.py` (`PhaseVocoderShifter`) | STFT phase vocoder: time-stretch by `r`, then resample by `1/r` | independent second approach |
| `pv_transient` | `poc/octavox_offline.py` | same vocoder + transient-aware short analysis window and phase re-lock at detected onsets | independent third approach (hybrid) |

The delay-line design is the architecture recovered from the binary (see
`OCTAVOX_ROUND6_DSP_FINDINGS.md` §4). The two vocoder designs were written from scratch for this
round; they share no code with the delay line beyond the metric functions.

---

## 2. Requirements

* Windows / Linux / macOS, CPython **3.11** (tested: 3.11.9, MSC v.1938, 64-bit)
* **NumPy** (tested: 2.4.4). No SciPy, no other dependency.
* Both files must stay in the same folder (the CLI imports `octavox_poc`).

```powershell
python -c "import numpy; print(numpy.__version__)"
```

---

## 3. Quick start

```powershell
cd f:\VST\OV_DIS\Evdence\poc

# 1. make the deterministic 2 s example input (48 kHz mono, 5 plucked notes)
python octavox_offline.py --make-example example_input.wav

# 2. shift it up a major third with the reconstructed delay line, 3 voices
python octavox_offline.py --in example_input.wav --out out_dl.wav `
    --algo delayline --semitones 4 --voices 3 --interp lagrange6

# 3. same shift with the phase vocoder
python octavox_offline.py --in example_input.wav --out out_pv.wav `
    --algo pv --semitones 4 --voices 3

# 4. same shift with the transient-aware hybrid
python octavox_offline.py --in example_input.wav --out out_pvt.wav `
    --algo pv_transient --semitones 4 --voices 3

# 5. the three-design comparison on identical signals
python octavox_offline.py --compare
```

`--compare` writes `offline_measurements.json` and `OFFLINE_COMPARISON.md` and prints the Markdown
table. It takes about a minute on the recorded machine (most of it is the Python delay line).

---

## 4. CLI reference

| option | meaning | default |
|---|---|---|
| `--in PATH` | input WAV (PCM 16/24/32-bit; mono or stereo) | — |
| `--out PATH` | output WAV (always 16-bit PCM) | — |
| `--algo {delayline,pv,pv_transient}` | pitch-shift design | `delayline` |
| `--ratio R` | pitch ratio (`1.0` = no shift, `2.0` = +1 oct) | `1.0` |
| `--semitones S` | pitch shift in semitones; **overrides** `--ratio` | — |
| `--voices N` | number of voices (0…8) | `1` |
| `--interp {lagrange6,lagrange6_q,linear}` | delay-line interpolator | `lagrange6` |
| `--grain G` | delay-line grain length in samples | `4096` |
| `--n-fft N` | vocoder FFT size (power of two) | `2048` |
| `--sr HZ` | **internal processing rate** | `48000` |
| `--keep-rate` | write the output at the **input file's** rate | off |
| `--no-spread` | put every voice at the same ratio (no musical spread) | off |
| `--json PATH` | also write the run info (levels, cost, sample counts) | — |
| `--make-example PATH` | write the deterministic example input and exit | — |
| `--compare` | run the three-design measurement suite and exit | — |

### 4.1 Sample-rate handling — exact semantics

* The file is read at its native rate `sr_in`.
* If `sr_in != --sr`, the input is **linear-resampled** to `--sr` and all processing happens at
  `--sr`.
* By default the output is written **at `--sr`**. The run info records `sr_in` and `sr_out`.
* With `--keep-rate`, the result is resampled back to `sr_in` before writing, so the file keeps its
  original rate (use this when the host expects the original rate).
* No sample-rate conversion is hidden elsewhere: the algorithms themselves are rate-parametric.

Example (44.1 kHz output, down a fourth):

```powershell
python octavox_offline.py --in example_input.wav --out example_output_pvt_44k.wav `
    --algo pv_transient --semitones -5 --sr 44100
# -> sr_in 48000, sr_out 44100, 88200 samples, 2.00 s
```

### 4.2 Voice spread

With `--voices N > 1` and spread on (default), voice 0 keeps the requested ratio exactly and the
remaining voices are placed at `ratio · 2^(d/12)` with
`d ∈ {0, +7, +4, +12, −5, −12, +3, −3}` semitones. `--no-spread` puts every voice at the same ratio
(useful for A/B tests and for the comparison suite, which uses 1 voice).

### 4.3 Supported WAV input

| format | supported |
|---|---|
| PCM 16-bit, 24-bit, 32-bit | yes |
| IEEE float 32-bit (`WAVE_FORMAT_IEEE_FLOAT`) | **no** — convert to PCM first |
| mono / stereo | yes (channels processed independently) |
| compressed (ADPCM, µ-law, …) | no |

Output is always 16-bit PCM, deterministic (no dither), clip-guarded at ±1.0.

---

## 5. How the three designs work (one paragraph each)

**`delayline` — reconstructed architecture.** Each voice reads a ring buffer at a position that
advances at `1 − r` samples per output sample (`r` = pitch ratio), so a grain of length `G` is
consumed at rate `r`. When the read position would leave its window, the voice re-arms: it starts a
second tap `G` samples away and crossfades over the grain. The two taps are mixed with a
complementary linear crossfade; the interval is applied as a cents value in the ratio exponent.
Interpolation is a 6-point Lagrange kernel (or its 256-phase quantised form). The nominal delay is
`base_delay + G/2` = 2304 samples (**48 ms at unison**); the measured main-response delay is not
constant, because the read position sweeps: 65 ms at ratio 0.80 and 102 ms at 1.25. This design
reproduces the target's *structure* (see `OCTAVOX_ROUND6_DSP_FINDINGS.md` §4); it is not a bit-exact
model.

**`pv` — phase vocoder.** Frames of `N` samples with a periodic Hann window and 75 % overlap are
transformed. For each bin the true instantaneous frequency is estimated from the phase difference
between consecutive frames (`ω = expected + princarg(Δφ − expected)`), and the synthesis phase is
advanced by `ω · Hs/H`, where `Hs = round(H·r)`. The stretched signal is then resampled by `r`
(`out[j] = stretch[j·r]`), which shifts the pitch by exactly `r` and restores the original duration.
A causal `N/2` delay is added so the reported latency is honest (34 ms at `N = 2048`, 48 kHz).

**`pv_transient` — transient-aware hybrid.** Same vocoder, but a level-normalised spectral-flux
detector marks local onset maxima (`flux > median + 8·MAD`, `flux > 2 %`). On those frames the
analysis/synthesis window is shortened to `N/4` (zero-padded, so the FFT size and the bin spacing are
unchanged) and the synthesis phase is re-locked to the analysis phase. This trades a little spectral
resolution exactly where it does not matter (the onset) for a much sharper attack and far less
pre-echo. The overlap-add normaliser is accumulated per sample (`Σ w²`), so the changing window length
does not alter the level.

---

## 6. Reproducibility

* All test signals are generated in code with fixed parameters; the only noise source is
  `np.random.default_rng(7)` (cost test) and `default_rng(3)` (example material), both seeded.
* No wall-clock or random value influences the audio path.
* The comparison writes both the raw numbers (`offline_measurements.json`) and the formatted table
  (`OFFLINE_COMPARISON.md`).
* Two runs on the same machine produce byte-identical WAVs; the cost numbers vary with machine load,
  so the cost columns are indicative, not exact.

To re-create every artefact in this folder:

```powershell
python octavox_offline.py --make-example example_input.wav
python octavox_offline.py --in example_input.wav --out example_output_delayline.wav --algo delayline --semitones 4 --voices 3 --json example_delayline.json
python octavox_offline.py --in example_input.wav --out example_output_pv.wav        --algo pv        --semitones 4 --voices 3 --json example_pv.json
python octavox_offline.py --in example_input.wav --out example_output_pvt.wav       --algo pv_transient --semitones 4 --voices 3 --json example_pvt.json
python octavox_offline.py --in example_input.wav --out example_output_pvt_44k.wav   --algo pv_transient --semitones -5 --sr 44100 --json example_pvt_44k.json
python octavox_offline.py --compare
```

---

## 7. What the demo does **not** do

* It is **not** real time. The Python delay line runs at ≈ 0.25× realtime for 3 voices and ≈ 0.15×
  for 8 voices on the recorded machine; the vocoders run ≈ 13–42× realtime but are still offline
  batch code, not a plugin.
* It is **not** a bit-exact model of the target: no target code or data was reused, and the
  coefficients, window lengths and interpolation weights are our own choices where the binary did not
  determine them.
* It makes **no claim** about how the target sounds. In particular, the measured two-tap comb at
  unity ratio (`POC_RESULTS.md`) is a property of *our* reconstruction of the architecture; whether
  the target exhibits it is Q-14 and remains open.
* It performs no protection analysis and does not touch the target file.

---

## 8. File inventory (round 6)

| file | role |
|---|---|
| `octavox_poc.py` | delay-line DSP + synthetic regression harness (round 5, unchanged) |
| `octavox_offline.py` | WAV I/O, CLI, phase vocoder, transient-aware hybrid, metric runner |
| `example_input.wav` | deterministic 2 s example (5 plucked notes, 48 kHz mono) |
| `example_output_delayline.wav` | +4 st, 3 voices, delay line |
| `example_output_pv.wav` | +4 st, 3 voices, phase vocoder |
| `example_output_pvt.wav` | +4 st, 3 voices, transient-aware hybrid |
| `example_output_pvt_44k.wav` | −5 st, 1 voice, processed at 44.1 kHz |
| `example_*.json` | per-run info: sample counts, rates, cost, peak |
| `offline_measurements.json` / `OFFLINE_COMPARISON.md` | comparison suite outputs |
| `poc_measurements.json` / `POC_RESULTS.md` | round-5 synthetic-harness outputs |
