# Round-12 delivery note

This ZIP (`Octavox_RE_evidence_round12.zip`) is the round-12 edition of the Octavox
reverse-engineering evidence package. It supersedes
`Octavox_RE_evidence_round11.zip` (SHA-256
`6ff8173a9e98e41092d762f32862ad88dd399291a6019cc29e71582194cf215b`) and is a complete,
self-verifiable snapshot: nothing else is required except the target binary (which is NOT
included, as in every previous edition).

Round 12 = **static DSP reconstruction advanced from the binary directly** (the target was
present this round; read-only scans) + **the independent native C++17 DSP core** with the
unity artefact fixed, validated and benchmarked. See
`docs/OCTAVOX_ROUND12_FINDINGS.md` for the narrative and the correction changelog.

## Contents (files + `checksums.txt`)

| path | role |
|---|---|
| `README.md` | package front door — updated for round 12 (new round-12 section + native reproduction commands) |
| `docs/OCTAVOX_ROUND12_FINDINGS.md` | **new** — the round-12 findings: the static advance (interpolator/settled-path/crossfade; Q-14 premise answered), the native core and the unity fix, the validation and benchmark results, the round-11 suite re-runs, and the honest UNK residue |
| `native/` | **new** — the independent C++17 DSP core: `include/octavox/dsp.hpp` (public API), `src/dsp.cpp`, `src/obs_kernel_table.h` (OBSERVED target `.rdata` kernel data, bit-exact extraction, clearly labelled), `tests/` (51-case correctness + unity regression suite, WAV I/O, allocation counter), `bench/`, `cli/` (WAV→WAV demo CLI), `CMakeLists.txt`, `README.md`, `ARCHITECTURE.md` (state / memory ownership / threading / channel isolation / limitations note). Build directories are intentionally NOT shipped |
| `evidence/analysis_round12/` | **new** — `r12_scan_table.py/.txt` + `r12_prepare_disasm.py/.txt` + `r12_constants_and_table.py/.txt` + `r12_interp_table.py/.txt` (the four read-only capstone scans of the shipped binary), `r12_obs_kernel_table.h` (generated bit-exact extraction), `r12_static_findings.txt` (the evidence summary), `r12_native_tests.json/.txt` + `r12_native_tests_asan.json` (51/51 release and ASan+UBSan), `r12_native_bench.json`, `r12_native_metrics.py` + `r12_native_metrics_results.json/.txt` (cross-language gates 15/15) |
| `docs/` (canonical docs) | `OCTAVOX_DSP_ARCHITECTURE.md` (S5/S6 rewritten from instruction-level evidence, member-map corrections, §9 round-12 addendum), `OCTAVOX_CONTROL_FLOW_MATRIX.md` (§13 addendum), `OCTAVOX_OPEN_QUESTIONS.md` (Q-14 → PARTIAL with the static answer; new residuals), `OCTAVOX_RESEARCH_EVIDENCE_MATRIX.md` (§16 rows R-62–R-70 + round-12 correction log), `OCTAVOX_DSP_DEMO_USAGE.md` (§9 native build/test/bench instructions) — every other doc unchanged from round 11 |
| `poc/`, `evidence/` (rounds ≤ 11) | **unchanged** — the Python reference implementations and all previous evidence are preserved byte-identically (baseline preservation); the round-11 suites re-run from this package: numeric audit exit 0, acceptance 45/45 |
| `OCTAVOX_AGENT_HANDOVER_REPORT.md` | the round-8 environment acceptance report (status **GO**) — unchanged |
| `checksums.txt` | **regenerated** for this edition (CRLF sha256sum manifest, case-insensitive path order) |

## Manifest

Compared with the round-11 manifest: **247 files byte-identical**, **7 files updated** by
round 12 (`README.md` and the five canonical docs `docs/OCTAVOX_DSP_ARCHITECTURE.md`,
`docs/OCTAVOX_CONTROL_FLOW_MATRIX.md`, `docs/OCTAVOX_OPEN_QUESTIONS.md`,
`docs/OCTAVOX_RESEARCH_EVIDENCE_MATRIX.md`, `docs/OCTAVOX_DSP_DEMO_USAGE.md`, plus
`evidence/analysis_round11/r11_acceptance_results.json` — the documented round-11 suite
RE-RUN required by this round's mandate: its deterministic case rows are unchanged and its
machine-dependent wall-clock cost rows reflect this environment, as designed), **31 files
new** (`DELIVERY_ROUND12.md`, `docs/OCTAVOX_ROUND12_FINDINGS.md`, the 17
`evidence/analysis_round12/` artifacts, and the 12 `native/` files), and **1 removed**
(the superseded `DELIVERY_ROUND11.md`, replaced by this note — the round-11 manifest is
preserved inside `Octavox_RE_evidence_round11.zip`). Total: 285 files + `checksums.txt`.

## Provenance

* The shipped binary was read-only-analysed this round: its SHA-256
  `7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2` was verified before
  and after every scan and the file was never modified and never executed.
* `native/` is our own code except `src/obs_kernel_table.h`, which is OBSERVED DATA
  (the target's static 256×6 interpolator kernel, extracted bit-exactly; the same
  evidence-reuse practice as the quartic coefficients in rounds 9–11, clearly labelled).
* The native core is NOT a VST3 plugin and does NOT reproduce the original plugin's runtime
  behaviour; every native measurement in this package describes our implementation only.

## Verification

```sh
unzip Octavox_RE_evidence_round12.zip
cd Octavox_RE_evidence
sha256sum -c checksums.txt        # all records OK expected

# re-run the round-11 gates (Python 3.11+, numpy):
python3 evidence/analysis_round11/r11_numeric_audit.py        # exit 0; 14 checks PASS
python3 evidence/analysis_round11/r11_acceptance_tests.py     # exit 0; 45/45 PASS (~2.5 min)

# native core (CMake >= 3.16, C++17, GCC or Clang):
cmake -S native -B native/build -DCMAKE_BUILD_TYPE=Release
cmake --build native/build -j
./native/build/octavox_tests --json /tmp/r12.json            # exit 0; 51/51 PASS
cmake -S native -B native/build-asan -DCMAKE_BUILD_TYPE=Debug -DENABLE_SANITIZERS=ON
cmake --build native/build-asan -j && ./native/build-asan/octavox_tests   # 51/51, no sanitizer reports
./native/build/octavox_bench                                  # release benchmark (stdout + --json)
python evidence/analysis_round12/r12_native_metrics.py \\
    --poc poc --native-cli native/build/octavox_cli           # exit 0; 15/15 gates
```

Recorded results on the delivery environment (Debian 13, GCC 14.2, 2 cores):
`octavox_tests` release **51/51**, ASan+UBSan **51/51 with zero sanitizer reports**,
`r12_native_metrics.py` **15/15 gates**, benchmark 1346–1552 ns/frame (1–8 voices, mono,
64-sample control rate) and 410 ns/frame at control interval 512; Python reference timing
50 084–84 240 ns/frame (0.42×/0.25× realtime) — the native core is ≈ 35–55× faster on
identical deterministic input.

The SHA-256 of the ZIP itself is published alongside it (sidecar file
`Octavox_RE_evidence_round12.zip.sha256`).

## Delivery report (round 12)

**Test commands and actual results** (this environment):

| command | result |
|---|---|
| `octavox_tests --json …` (release, GCC 14.2 `-O2`) | **51/51 pass, exit 0**; unity gates bit-exact (max abs diff 0.000000e+00 across tones/noise/chord/silence/low-level/arrival); block-size invariance exactly 0; steady-state allocations 0 |
| `octavox_tests` (ASan+UBSan build) | **51/51 pass, exit 0, zero sanitizer reports** |
| `octavox_bench --json …` | mono 1v/8v: 1346–1552 ns/frame (15.5×/13.9× realtime); stereo 8v 3089 ns/frame (6.7×); ctrl-interval 512: 410 ns/frame (50.9×); RSS 8.6–12.7 MB; allocations 0 |
| `r12_native_metrics.py …` | **15/15 gates pass, exit 0**; unity comb spread native **0.0000 dB** vs Python v2 **16.43 dB** (BEFORE); pitch battery worst error **0.50 ¢**; stereo isolation exact 0 both; Python reference timing 0.42×/0.25× realtime |
| `r11_numeric_audit.py` (re-run) | **exit 0** — all 14 verdicts PASS |
| `r11_acceptance_tests.py` (re-run) | **45/45 pass, exit 0** (~2.5 min) |

**Known limitations** (documented, gated and reported, not hidden):

* The YIN detector's 2048-sample window cannot bracket 60 Hz at 96 kHz → spacing falls
  back to `G` (reference-parity); pitch error −13.8 ¢ at +400 ¢/96 kHz (loose gate).
* The detector is ~73 % of native runtime at the default 64-sample control rate; the
  voice path alone runs at ≈ 51× realtime.
* A fresh near-unity engine (never at exact unity) keeps the static two-tap comb for
  periodic input until its first wrap (−2.41 dB at 220 Hz measured); the unity-exit
  spacing commit removes it after any departure from exact unity.
* Native control timing lags the Python reference's by at most one interval (64 samples)
  with aligned calls — a streaming API cannot reproduce the reference's intra-block
  look-ahead (class-level behaviour unaffected; see ARCHITECTURE.md).
* No dither in the 16-bit writer; write/read asymmetry (round(y·32767) then ÷32768) is the
  reference's own convention (parity).

**Remaining unknowns** (unchanged policy — the target was never executed): the runtime
audibility of the target's settled/crossfade path (Q-14's audible question — the static
premise is now answered); the record-ring first-field scaling (re-arm base `v ≥ 48`); the
exact design formula of the observed kernel (values OBS, class DER); walk statistics and
correction convergence; the m02 double-conversion runtime behaviour; the host-reported
latency value. The controlled Windows-host tests that would close the runtime questions
remain those listed in `OCTAVOX_ROUND11_FINDINGS.md` §6.
