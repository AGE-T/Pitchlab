# OCTAVOX Native DSP Core (Round 12)

Our own C++17 port of the round-11 `delayline_aligned` design plus the
round-12 unity engagement fix. **Not a VST3 plugin and not a reproduction of
the original plugin's runtime behaviour** — see `ARCHITECTURE.md` for the
full note (state, memory ownership, threading, channel isolation,
limitations) and `../docs/OCTAVOX_ROUND12_FINDINGS.md` for the research
context.

## Layout

```
include/octavox/dsp.hpp   public API (AlignedDelayLine, MultichannelShifter)
src/dsp.cpp               implementation
src/obs_kernel_table.h    OBSERVED target .rdata kernel (opt-in mode; data, not code)
tests/test_main.cpp       correctness + unity regression suite (51 cases)
tests/wav_io.*            WAV I/O (harness only; mirrors the Python CLI)
tests/alloc_counter.cpp   global-new counter for the no-alloc gate
bench/bench_main.cpp      release benchmark (deterministic LCG input)
cli/octavox_cli.cpp       WAV->WAV demo CLI (cross-language metrics driver)
```

## Build

Requires CMake ≥ 3.16 and a C++17 compiler (developed with GCC 14.2).

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

Sanitizer build (address + undefined):

```sh
cmake -S . -B build-asan -DCMAKE_BUILD_TYPE=Debug -DENABLE_SANITIZERS=ON
cmake --build build-asan -j
```

## Test / benchmark

```sh
./build/octavox_tests --json results.json      # exit 0 = all pass
./build-asan/octavox_tests --json results_asan.json
./build/octavox_bench --json bench.json
./build/octavox_cli --in ../poc/example_input.wav --out out.wav --cents 400 --voices 3
```

The authoritative cross-language measurements (native vs the preserved Python
reference) are produced by
`../evidence/analysis_round12/r12_native_metrics.py`.

## Recorded results (this round's environment)

* `octavox_tests` (release): **51/51 pass** — unity bit-exactness (tones,
  noise, chord, silence, low level, arrival from a shift), the cent battery
  (0, ±1, ±10, ±50, ±100, ±500, ±1200), 1/8 voices, mono/stereo, channel
  isolation, block-size invariance, repeated prepare, reset determinism,
  long runs, NaN/clip gates, steady-state allocation-freedom.
* ASan+UBSan build: **51/51 pass, zero sanitizer reports**.
* Benchmark (mono 48 kHz, +4 st, LCG noise, best of 3): ≈ 15× realtime
  (1 voice) / ≈ 13.8× (8 voices) at the default 64-sample control interval;
  ≈ 51× realtime with the interval at 512 (the YIN detector is ~73 % of the
  cost). Zero steady-state allocations. Stereo ≈ 6.7× realtime.
* Cross-language (identical input): the Python reference runs at 0.42×
  (1 voice) / 0.25× (8 voices) realtime — the native core is ≈ 35–55× faster
  on the same machine.
