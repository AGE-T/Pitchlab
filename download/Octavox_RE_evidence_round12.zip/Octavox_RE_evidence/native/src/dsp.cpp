// OCTAVOX round 12 -- independent native DSP core (implementation)
// See include/octavox/dsp.hpp for provenance, architecture and the unity
// behaviour note. All code here is our own.

#include "octavox/dsp.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <new>
#include <vector>

#include "obs_kernel_table.h"  // OBS data table (see header comment)

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace octavox {
namespace {

// ---------------------------------------------------------------------------
// Musical spread table (reference parity: poc/octavox_offline.py)
// ---------------------------------------------------------------------------
constexpr double kSpreadSemitones[8] = {0.0, 7.0, 4.0, 12.0, -5.0, -12.0, 3.0, -3.0};

// ---------------------------------------------------------------------------
// Interpolator tables (built once, shared, immutable)
// ---------------------------------------------------------------------------
constexpr int kLag6Taps = 6;

// 6-point Lagrange weights for phase mu, nodes -2,-1,0,1,2,3 (our own design;
// same formula as the Python reference).
void lagrange6Weights(double mu, double* w) {
    static const double xs[6] = {-2.0, -1.0, 0.0, 1.0, 2.0, 3.0};
    for (int i = 0; i < 6; ++i) {
        double v = 1.0;
        for (int j = 0; j < 6; ++j) {
            if (i != j) v *= (mu - xs[j]) / (xs[i] - xs[j]);
        }
        w[i] = v;
    }
}

struct InterpTables {
    double lag2048[2048][6];
    double lag256[256][6];

    InterpTables() {
        double w[6];
        for (int r = 0; r < 2048; ++r) {
            lagrange6Weights((r + 0.5) / 2048.0, w);  // bin centres (Python parity)
            for (int k = 0; k < 6; ++k) lag2048[r][k] = w[k];
        }
        for (int r = 0; r < 256; ++r) {
            lagrange6Weights((r + 0.5) / 256.0, w);
            for (int k = 0; k < 6; ++k) lag256[r][k] = w[k];
        }
    }
};

const InterpTables& interpTables() {
    static const InterpTables t;  // thread-safe magic static
    return t;
}

// ---------------------------------------------------------------------------
// YIN-style pitch detector (port of poc/octavox_poc.py PitchDetector)
// Window 2048, fmin 60, fmax 1200 (the v2 engine's detector defaults); the
// spacing gate in the engine uses the Config fmin/fmax (55/1200) exactly as
// the Python does.
// ---------------------------------------------------------------------------
class PitchDetector {
public:
    static constexpr int kWin = 2048;

    void configure(int sr) {
        sr_ = sr;
        tau_min_ = std::max(2, static_cast<int>(sr_ / 1200.0));
        tau_max_ = std::min(kWin - 2, static_cast<int>(sr_ / 60.0));
        buf_.assign(kWin, 0.0);
        d_.assign(std::max(0, tau_max_ - tau_min_), 0.0);
        cmnd_.assign(d_.size(), 0.0);
        last_f0_ = 0.0;
    }

    void reset() {
        std::fill(buf_.begin(), buf_.end(), 0.0);
        last_f0_ = 0.0;
    }

    // Push a block into the sliding window (Python push_block semantics).
    void pushBlock(const float* x, int n) {
        if (n >= kWin) {
            std::copy(x + n - kWin, x + n, buf_.begin());
            return;
        }
        // roll left by n, append
        std::copy(buf_.begin() + n, buf_.end(), buf_.begin());
        for (int i = 0; i < n; ++i) buf_[kWin - n + i] = static_cast<double>(x[i]);
    }

    double estimate() {
        const std::vector<double>& x = buf_;
        double peak = 0.0;
        for (int i = 0; i < kWin; ++i) peak = std::max(peak, std::abs(x[i]));
        if (peak < 1e-6) {
            last_f0_ = 0.0;
            return 0.0;
        }
        if (tau_max_ <= tau_min_) {
            last_f0_ = 0.0;
            return 0.0;
        }
        // seg = second half of the window; m = len(seg) - tau_max
        const int seg0 = kWin / 2;
        const int m = (kWin - seg0) - tau_max_;
        if (m < 32) {
            last_f0_ = 0.0;
            return 0.0;
        }
        const int ntau = tau_max_ - tau_min_;
        for (int i = 0; i < ntau; ++i) {
            const int tau = tau_min_ + i;
            double s = 0.0;
            for (int j = 0; j < m; ++j) {
                const double a = x[seg0 + j] - x[seg0 + tau + j];
                s += a * a;
            }
            d_[i] = s;
        }
        // cumulative mean normalisation
        double run = 0.0;
        for (int i = 0; i < ntau; ++i) {
            run += d_[i];
            cmnd_[i] = (run > 0.0) ? d_[i] * static_cast<double>(i + 1) / run : 1.0;
        }
        // first minimum below threshold
        int idx = -1;
        const double thr = 0.20;
        for (int i = 1; i < ntau - 1; ++i) {
            if (cmnd_[i] < thr && cmnd_[i] <= cmnd_[i - 1] && cmnd_[i] <= cmnd_[i + 1]) {
                idx = i;
                break;
            }
        }
        if (idx < 0) {
            // argmin
            idx = 0;
            for (int i = 1; i < ntau; ++i)
                if (cmnd_[i] < cmnd_[idx]) idx = i;
        }
        double tau = static_cast<double>(tau_min_ + idx);
        // parabolic refinement
        if (idx > 0 && idx < ntau - 1) {
            const double y0 = cmnd_[idx - 1], y1 = cmnd_[idx], y2 = cmnd_[idx + 1];
            const double den = y0 - 2.0 * y1 + y2;
            if (std::abs(den) > 1e-15) tau += 0.5 * (y0 - y2) / den;
        }
        double f0 = static_cast<double>(sr_) / tau;
        if (!(60.0 <= f0 && f0 <= 1200.0)) f0 = 0.0;
        last_f0_ = f0;
        return f0;
    }

    double lastF0() const { return last_f0_; }

private:
    int sr_ = 48000;
    int tau_min_ = 2, tau_max_ = 800;
    std::vector<double> buf_, d_, cmnd_;
    double last_f0_ = 0.0;
};

// ---------------------------------------------------------------------------
// Per-voice state
// ---------------------------------------------------------------------------
struct VoiceState {
    double ratio_t = 1.0;   // target ratio (2^(st/12))
    double ratio = 1.0;     // gliding ratio
    double base_delay = 256.0;
    double frac = 0.5;      // grain phase [0,1)
    double S = 4096.0;      // current tap spacing
    // unity engagement
    double e = 1.0;         // 1 = dual-tap, 0 = single-tap A
    double a = 0.0;         // parking blend: 1 = parked integer read
    int d_park = -1;        // parked integer delay
    // diagnostics
    long wraps = 0;
    long commits = 0;
};

}  // namespace

// ---------------------------------------------------------------------------
// AlignedDelayLine::Impl
// ---------------------------------------------------------------------------
struct AlignedDelayLine::Impl {
    static constexpr int kRingBits = 18;
    static constexpr int kRingSize = 1 << kRingBits;  // 262144
    static constexpr int kRingMask = kRingSize - 1;

    std::vector<double> ring;        // age-indexed delay line
    int w = 0;                       // newest sample index
    PitchDetector det;
    std::vector<VoiceState> vs;      // [max_voices]
    std::vector<double> f0_hist;     // circular, size f0_history
    std::vector<double> med_scratch; // preallocated median scratch (no alloc)
    std::vector<float> det_pending;  // control-rate accumulator (raw input)
    int det_n = 0;
    int f0_hist_n = 0, f0_hist_i = 0;
    bool have_estimate = false;
    double S_target = 4096.0;
    double fb_state = 0.0;
    double norm = 1.0;               // voice-count normalisation (ramped)
    double norm_target = 1.0;
    double last_f0 = 0.0;
    double e_step = 0.0;             // engagement slew per sample
    Config cfg{};

    // -- ring helpers -------------------------------------------------------
    inline void push(double x) {
        ring[w] = x;
        w = (w - 1) & kRingMask;
    }

    inline double readRaw(int delay) const {
        return ring[(w + delay) & kRingMask];
    }

    // Interpolated read at `delay` (>= 0). Exact-integer delays take the
    // direct sample path (bit-exact; used by the parked unity state).
    double readInterp(double delay) const {
        if (delay < 0.0) delay = 0.0;
        const double d0 = std::floor(delay);
        const double mu = delay - d0;
        const int i0 = static_cast<int>(d0);
        if (mu == 0.0) {
            return ring[(w + i0) & kRingMask];  // exact integer delay
        }
        switch (cfg.interpolation) {
            case Interpolation::Linear: {
                const double a = ring[(w + i0) & kRingMask];
                const double b = ring[(w + i0 + 1) & kRingMask];
                return a + (b - a) * mu;
            }
            case Interpolation::Lagrange6: {
                int ph = static_cast<int>(mu * 2048.0);  // floor, mu < 1
                if (ph > 2047) ph = 2047;
                const double* wv = interpTables().lag2048[ph];
                double s = 0.0;
                for (int k = 0; k < 6; ++k)
                    s += wv[k] * ring[(w + i0 + k - 2) & kRingMask];
                return s;
            }
            case Interpolation::Lagrange6Q: {
                int ph = static_cast<int>(mu * 256.0);
                if (ph > 255) ph = 255;
                const double* wv = interpTables().lag256[ph];
                double s = 0.0;
                for (int k = 0; k < 6; ++k)
                    s += wv[k] * ring[(w + i0 + k - 2) & kRingMask];
                return s;
            }
            case Interpolation::ObsKernel6: {
                // OBS data mode: floor-indexed 256 phases (target phase law).
                int ph = static_cast<int>(mu * 256.0);
                if (ph > 255) ph = 255;
                const float* wv = obs_kernel::kTable[ph];
                double s = 0.0;
                for (int k = 0; k < 6; ++k)
                    s += static_cast<double>(wv[k]) *
                         ring[(w + i0 + k - 2) & kRingMask];
                return s;
            }
        }
        return 0.0;
    }

    // -- spacing management (v2 parity) --------------------------------------
    void updateSpacingTarget(double f0) {
        if (f0 != 0.0 && cfg.fmin <= f0 && f0 <= cfg.fmax) {
            f0_hist[f0_hist_i] = static_cast<double>(cfg.sample_rate) / f0;
            f0_hist_i = (f0_hist_i + 1) % static_cast<int>(f0_hist.size());
            if (f0_hist_n < static_cast<int>(f0_hist.size())) ++f0_hist_n;
            have_estimate = true;
        }
        if (f0_hist_n == 0) {
            S_target = cfg.grain;
            return;
        }
        // median of the history (np.median parity: even count averages the
        // middle two). Uses the preallocated scratch -- NO allocation here
        // (steady-state guarantee).
        med_scratch.assign(f0_hist.begin(), f0_hist.begin() + f0_hist_n);
        std::sort(med_scratch.begin(), med_scratch.end());
        const int n = static_cast<int>(med_scratch.size());
        double t_hat = (n % 2 == 1)
                           ? med_scratch[n / 2]
                           : 0.5 * (med_scratch[n / 2 - 1] + med_scratch[n / 2]);
        // Python round() = round-half-to-even = nearbyint with default env
        const double k = std::nearbyint(cfg.grain / t_hat);
        const double kk = std::max(1.0, k);
        const double S = kk * t_hat;
        S_target = std::min(std::max(S, 0.5 * cfg.grain), 1.5 * cfg.grain);
    }

    // Wrap-time commit (v2 parity, hysteresis gated).
    inline void commitSpacing(VoiceState& v) {
        if (!have_estimate) return;
        if (std::abs(S_target / v.S - 1.0) > cfg.s_hysteresis) {
            v.S = S_target;
            ++v.commits;
        }
    }

    // Unity-exit commit: refresh S while B's weight is ~0, preserving the
    // read point exactly (frac_new = frac*S_old/S_new in [0,1)).
    void exitCommitSpacing(VoiceState& v) {
        if (!have_estimate) return;
        if (std::abs(S_target / v.S - 1.0) <= cfg.s_hysteresis) return;
        const double frac_new = v.frac * v.S / S_target;
        if (frac_new >= 0.0 && frac_new < 1.0) {
            v.S = S_target;
            v.frac = frac_new;
            ++v.commits;
        }
        // else: keep S; the next natural wrap will commit it (v2 rule)
    }

    // Park on the nearest integer delay inside [base, base+S).
    void parkVoice(VoiceState& v) {
        const double d = v.base_delay + v.frac * v.S;
        int d_int = static_cast<int>(std::floor(d + 0.5));
        const double lo = std::ceil(v.base_delay);
        const double hi = std::floor(v.base_delay + v.S) - 1.0;
        if (static_cast<double>(d_int) > hi) d_int = static_cast<int>(hi);
        if (static_cast<double>(d_int) < lo) d_int = static_cast<int>(lo);
        v.d_park = d_int;
    }

    // -- per-sample voice processing -----------------------------------------
    // Returns this voice's output sample.
    inline double processVoiceSample(VoiceState& v) {
        // ratio glide (geometric, reference parity)
        v.ratio = v.ratio_t + (v.ratio - v.ratio_t) * Config::kGlideMult;
        const double r = v.ratio;

        // grain phase ramp + wrap/commit (v2 parity)
        double frac = v.frac + (1.0 - r) / v.S;
        if (r > 1.0) {
            if (frac < 0.0) {
                const double S_old = v.S;
                commitSpacing(v);
                frac = (frac + 1.0) * S_old / v.S;
                while (frac >= 1.0) frac -= 1.0;
                ++v.wraps;
            }
        } else {
            if (frac >= 1.0) {
                const double S_old = v.S;
                commitSpacing(v);
                frac = (frac - 1.0) * S_old / v.S;
                while (frac < 0.0) frac += 1.0;
                ++v.wraps;
            }
        }
        v.frac = frac;

        const double e = v.e;
        const double a = v.a;

        if (e <= 0.0 && a >= 1.0) {
            // Fully parked: bit-exact single integer-tap read.
            return readRaw(v.d_park);
        }

        const double d = v.base_delay + frac * v.S;
        const double A = readInterp(d);

        double dual;
        if (e >= 1.0) {
            const double B = readInterp(d + v.S);
            const double w = 0.5 - 0.5 * std::cos(M_PI * frac);
            dual = w * A + (1.0 - w) * B;
        } else if (e <= 0.0) {
            dual = A;  // single-tap A (wA_eff = 1, wB_eff = 0)
        } else {
            const double B = readInterp(d + v.S);
            const double w = 0.5 - 0.5 * std::cos(M_PI * frac);
            const double wA = e * w + (1.0 - e);
            const double wB = e * (1.0 - w);
            dual = wA * A + wB * B;
        }

        if (a > 0.0) {
            const double park = readInterp(static_cast<double>(v.d_park));
            return (1.0 - a) * dual + a * park;
        }
        return dual;
    }

    // -- engagement slew ------------------------------------------------------
    inline void slewEngagement(VoiceState& v) {
        const bool unity = (v.ratio_t == 1.0);  // bit-exact double compare
        const double e_target = unity ? 0.0 : 1.0;
        // 'a' parks only once e has fully reached 0
        const double a_target = (unity && v.e <= 0.0) ? 1.0 : 0.0;
        if (v.e < e_target) v.e = std::min(e_target, v.e + e_step);
        else if (v.e > e_target) v.e = std::max(e_target, v.e - e_step);
        if (v.a < a_target) {
            if (v.a <= 0.0) parkVoice(v);  // (re)compute the parked delay
            v.a = std::min(a_target, v.a + e_step);
        } else if (v.a > a_target) {
            v.a = std::max(a_target, v.a - e_step);
        }
    }
};

// ---------------------------------------------------------------------------
// AlignedDelayLine
// ---------------------------------------------------------------------------
AlignedDelayLine::AlignedDelayLine() = default;
AlignedDelayLine::~AlignedDelayLine() { delete impl_; }

bool AlignedDelayLine::prepare(const Config& cfg) {
    delete impl_;
    impl_ = nullptr;
    ready_ = false;
    if (!(cfg.sample_rate > 0.0)) return false;
    if (cfg.max_voices < 1 || cfg.max_voices > 64) return false;
    if (cfg.voices < 1 || cfg.voices > cfg.max_voices) return false;
    if (!(cfg.grain > 0.0)) return false;
    if (cfg.base_delay < 8.0) return false;
    // Maximum read delay: B tap at d + S with d < base + 32*(mv-1) + S and
    // S <= 1.5*grain, plus 3 extra taps beyond the anchor -> require the whole
    // range to stay inside the 2^18 ring.
    if (cfg.base_delay + 32.0 * (cfg.max_voices - 1) + 3.0 * cfg.grain + 8.0 >=
        static_cast<double>(1 << 18)) {
        return false;
    }
    if (cfg.fmin <= 0.0 || cfg.fmax <= cfg.fmin) return false;
    if (cfg.s_hysteresis < 0.0) return false;
    if (cfg.f0_history < 1 || cfg.f0_history > 64) return false;
    if (cfg.detection_interval < 1) return false;
    if (cfg.engagement_seconds < 0.0) return false;
    if (!(cfg.feedback > -1.0 && cfg.feedback < 1.0)) return false;

    impl_ = new Impl();
    impl_->cfg = cfg;
    impl_->ring.assign(Impl::kRingSize, 0.0);
    impl_->vs.resize(cfg.max_voices);
    impl_->f0_hist.assign(cfg.f0_history, 0.0);
    impl_->med_scratch.assign(cfg.f0_history, 0.0);
    impl_->det_pending.assign(cfg.detection_interval, 0.0f);
    impl_->det_n = 0;
    impl_->det.configure(static_cast<int>(cfg.sample_rate));
    impl_->e_step =
        cfg.engagement_seconds > 0.0
            ? 1.0 / (cfg.engagement_seconds * cfg.sample_rate)
            : 1.0;
    cfg_ = cfg;
    active_voices_ = cfg.voices;
    ready_ = true;
    reset();
    return true;
}

void AlignedDelayLine::reset() {
    if (!impl_) return;
    Impl& m = *impl_;
    std::fill(m.ring.begin(), m.ring.end(), 0.0);
    m.w = 0;
    m.det.reset();
    const double st = (m.cfg.ratio > 0.0) ? 12.0 * std::log2(m.cfg.ratio) : 0.0;
    for (int i = 0; i < m.cfg.max_voices; ++i) {
        VoiceState& v = m.vs[i];
        const double off = (m.cfg.spread && i < 8) ? kSpreadSemitones[i] : 0.0;
        v.ratio_t = std::pow(2.0, (st + off) / 12.0);
        v.ratio = v.ratio_t;
        v.base_delay = m.cfg.base_delay + 32.0 * i;
        v.frac = 0.5;
        v.S = m.cfg.grain;
        v.wraps = 0;
        v.commits = 0;
        // Unity engagement: start parked if this voice is at exact unity.
        if (v.ratio_t == 1.0) {
            v.e = 0.0;
            v.a = 1.0;
            m.parkVoice(v);
        } else {
            v.e = 1.0;
            v.a = 0.0;
            v.d_park = -1;
        }
    }
    std::fill(m.f0_hist.begin(), m.f0_hist.end(), 0.0);
    m.f0_hist_n = 0;
    m.f0_hist_i = 0;
    m.have_estimate = false;
    m.S_target = m.cfg.grain;
    m.fb_state = 0.0;
    m.norm = 1.0 / active_voices_;
    m.norm_target = m.norm;
    m.det_n = 0;
    m.last_f0 = 0.0;
}

void AlignedDelayLine::setRatio(double ratio) {
    if (!impl_ || !(ratio > 0.0)) return;
    Impl& m = *impl_;
    const double st = 12.0 * std::log2(ratio);
    for (int i = 0; i < m.cfg.max_voices; ++i) {
        VoiceState& v = m.vs[i];
        const double off = (m.cfg.spread && i < 8) ? kSpreadSemitones[i] : 0.0;
        const double new_t = std::pow(2.0, (st + off) / 12.0);
        const bool was_unity = (v.ratio_t == 1.0);
        v.ratio_t = new_t;
        if (was_unity && new_t != 1.0) {
            // Unity exit: refresh the spacing while tap B carries ~0 weight.
            m.exitCommitSpacing(v);
        }
    }
    m.cfg.ratio = ratio;
    cfg_.ratio = ratio;
}

void AlignedDelayLine::setVoices(int n) {
    if (!impl_) return;
    if (n < 1 || n > impl_->cfg.max_voices) return;
    active_voices_ = n;
    impl_->norm_target = 1.0 / n;
}

void AlignedDelayLine::setSpread(bool on) {
    if (!impl_) return;
    if (impl_->cfg.spread == on) return;
    impl_->cfg.spread = on;
    cfg_.spread = on;
    // Re-derive voice targets from the current ratio (audio-thread update).
    const double st = 12.0 * std::log2(impl_->cfg.ratio > 0.0 ? impl_->cfg.ratio : 1.0);
    for (int i = 0; i < impl_->cfg.max_voices; ++i) {
        VoiceState& v = impl_->vs[i];
        const double off = (on && i < 8) ? kSpreadSemitones[i] : 0.0;
        const double new_t = std::pow(2.0, (st + off) / 12.0);
        const bool was_unity = (v.ratio_t == 1.0);
        v.ratio_t = new_t;
        if (was_unity && new_t != 1.0) impl_->exitCommitSpacing(v);
    }
}

void AlignedDelayLine::setFeedback(double fb) {
    if (!impl_) return;
    impl_->cfg.feedback = std::min(0.999999, std::max(-0.999999, fb));
    cfg_.feedback = impl_->cfg.feedback;
}

int AlignedDelayLine::latencySamples() const {
    if (!impl_) return 0;
    return static_cast<int>(impl_->cfg.base_delay + impl_->cfg.grain * 0.5);
}

void AlignedDelayLine::process(const float* in, float* out, int n) {
    if (!impl_ || n <= 0) return;
    Impl& m = *impl_;
    const bool fb_on = (m.cfg.feedback != 0.0);
    const double fb = m.cfg.feedback;
    const int nv = active_voices_;
    const int interval = m.cfg.detection_interval;

    for (int k = 0; k < n; ++k) {
        // Control rate, stream-aligned: accumulate the RAW input (pre-feedback,
        // as the Python pushes xb = x) and fire push+estimate when the interval
        // boundary is crossed. The estimate applies from the boundary sample
        // onward. NOTE (documented delta): the Python reference estimates with
        // the full 64-sample block in the window BEFORE processing that block,
        // which is impossible in a streaming API that writes every output on
        // arrival; with 64-sample-aligned calls the native control timing
        // lags the Python's by at most one interval.
        m.det_pending[m.det_n++] = in[k];
        if (m.det_n >= interval) {
            m.det.pushBlock(m.det_pending.data(), m.det_n);
            m.det_n = 0;
            m.last_f0 = m.det.estimate();
            m.updateSpacingTarget(m.last_f0);
        }

        const double xin = static_cast<double>(in[k]) + (fb_on ? fb * m.fb_state : 0.0);
        m.push(xin);

        double acc = 0.0;
        for (int i = 0; i < nv; ++i) {
            VoiceState& v = m.vs[i];
            m.slewEngagement(v);  // engagement/parking slews (per sample)
            acc += m.processVoiceSample(v);
        }
        // voice-count normalisation (ramped)
        if (m.norm != m.norm_target) {
            const double step = m.e_step;
            if (m.norm < m.norm_target)
                m.norm = std::min(m.norm_target, m.norm + step);
            else
                m.norm = std::max(m.norm_target, m.norm - step);
        }
        const double y = acc * m.norm;
        out[k] = static_cast<float>(y);
        m.fb_state = fb_on ? y : 0.0;
    }
}

const VoiceStats& AlignedDelayLine::voiceStats(int v) const {
    static VoiceStats empty;
    if (!impl_ || v < 0 || v >= impl_->cfg.max_voices) return empty;
    const VoiceState& s = impl_->vs[v];
    static thread_local VoiceStats out;  // diagnostics scratch (copy if kept)
    out.wraps = s.wraps;
    out.commits = s.commits;
    out.engaged = (s.e >= 1.0) ? 1 : 0;
    out.parked = (s.e <= 0.0 && s.a >= 1.0) ? 1 : 0;
    out.spacing = s.S;
    out.phase = s.frac;
    out.parked_delay = out.parked ? s.d_park : -1;
    return out;
}

// ---------------------------------------------------------------------------
// MultichannelShifter
// ---------------------------------------------------------------------------
struct MultichannelShifter::MImpl {
    std::vector<AlignedDelayLine*> engines;
    Config cfg{};
    int channels = 0;
};

MultichannelShifter::MultichannelShifter() = default;
MultichannelShifter::~MultichannelShifter() {
    if (mimpl_) {
        for (auto* e : mimpl_->engines) delete e;
        delete mimpl_;
    }
}

bool MultichannelShifter::prepare(const Config& cfg, int channels) {
    if (channels < 1 || channels > 64) return false;
    if (mimpl_) {
        for (auto* e : mimpl_->engines) delete e;
        delete mimpl_;
        mimpl_ = nullptr;
    }
    mimpl_ = new MImpl();
    mimpl_->cfg = cfg;
    mimpl_->channels = channels;
    for (int c = 0; c < channels; ++c) {
        auto* e = new AlignedDelayLine();
        if (!e->prepare(cfg)) {
            delete e;
            for (auto* x : mimpl_->engines) delete x;
            delete mimpl_;
            mimpl_ = nullptr;
            return false;
        }
        mimpl_->engines.push_back(e);
    }
    return true;
}

void MultichannelShifter::reset() {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->reset();
}

void MultichannelShifter::setRatio(double r) {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->setRatio(r);
}
void MultichannelShifter::setVoices(int n) {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->setVoices(n);
}
void MultichannelShifter::setSpread(bool on) {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->setSpread(on);
}
void MultichannelShifter::setFeedback(double fb) {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->setFeedback(fb);
}

bool MultichannelShifter::ready() const { return mimpl_ != nullptr; }
int MultichannelShifter::channels() const { return mimpl_ ? mimpl_->channels : 0; }
int MultichannelShifter::latencySamples() const {
    return mimpl_ && !mimpl_->engines.empty() ? mimpl_->engines[0]->latencySamples() : 0;
}

void MultichannelShifter::process(const float* const* in, float* const* out,
                                  int channels, int n) {
    if (!mimpl_ || channels != mimpl_->channels) return;
    for (int c = 0; c < channels; ++c) {
        mimpl_->engines[c]->process(in[c], out[c], n);
    }
}

const VoiceStats& MultichannelShifter::voiceStats(int channel, int voice) const {
    static VoiceStats empty;
    if (!mimpl_ || channel < 0 || channel >= mimpl_->channels) return empty;
    return mimpl_->engines[channel]->voiceStats(voice);
}

double AlignedDelayLine::lastEstimateHz() const {
    return impl_ ? impl_->last_f0 : 0.0;
}

const char* versionString() { return "octavox-native 12.0.0"; }

}  // namespace octavox
