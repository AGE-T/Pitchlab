// OCTAVOX round 12 -- independent native DSP core (public API)
// =============================================================
//
// PROVENANCE
// ----------
// This library is OUR OWN implementation of the round-11 "delayline_aligned"
// design (poc/octavox_v2.py, preserved untouched as the Python reference
// baseline) ported to C++17, plus the round-12 unity engagement fix.
// It contains no target code. The single exception is documented data: the
// optional Interpolation::ObsKernel6 mode uses the 256x6 float kernel table
// OBSERVED in the target's .rdata (evidence/analysis_round12/
// r12_obs_kernel_table.h, extraction script r12_interp_table.py) for research
// comparison; that mode is opt-in and clearly labelled.
//
// Nothing here is a VST3 plugin and nothing here claims to reproduce the
// original plugin's runtime behaviour. The target was never executed.
//
// ARCHITECTURE (see native/ARCHITECTURE.md for the full note)
// -----------------------------------------------------------
//  AlignedDelayLine   one mono engine, 1..8 voices, planar float in/out.
//  MultichannelShifter N AlignedDelayLine engines (one per channel) with a
//                     shared parameter surface -- channel isolation is
//                     structural, not conventional.
//  prepare()          allocates every buffer (ring, detector window, work
//                     arrays, per-voice state). No allocation happens after
//                     prepare() returns; process() and the parameter setters
//                     are steady-state allocation-free (verified by the
//                     acceptance suite's global-new counter).
//  reset()            returns the engine to the post-prepare state.
//  process()          block size agnostic: the control-rate detector fires
//                     every `detection_interval` STREAM samples, so the
//                     output is invariant to how the caller splits the
//                     stream into blocks (an intentional improvement over
//                     the Python reference, which restarts its 64-sample
//                     control loop at every process() call).
//
// UNITY BEHAVIOUR (round-12 fix)
// ------------------------------
// The Python reference keeps a continuous complementary two-tap blend whose
// phase freezes at unity -> a measured comb (-2.42 dB @ 220 Hz). The target
// (static evidence, round 12, Finding 3) rests on a SINGLE interpolated tap
// and only crossfades transiently after a re-arm. This core mirrors that
// architecture: when a voice's target ratio is EXACTLY 1.0 (bit-exact) it
// engages a single-tap path morphed in/out over `engagement_seconds`, and
// parks on the nearest INTEGER delay so that exact unity is a bit-exact
// delayed copy of the input (out[k] == in[k - d_park], neutral processing).
// There is no bypass region: any ratio != 1.0 -- including +-1 cent -- gets
// the full dual-tap processing path. Departing unity also refreshes the tap
// spacing S from the live period estimate when the read point can be
// preserved exactly.

#pragma once

#include <cstddef>
#include <cstdint>

namespace octavox {

/// Interpolation for the fractional delay reads.
enum class Interpolation : int {
    Linear = 0,     ///< 2-point linear (the reference CLI's "linear")
    Lagrange6 = 1,  ///< 6-point Lagrange, 2048 bin-centre phases (v2 default)
    Lagrange6Q = 2, ///< 6-point Lagrange, 256 bin-centre phases ("lagrange6_q")
    ObsKernel6 = 3, ///< target's observed static 256x6 .rdata kernel (OBS data)
};

/// Engine configuration (all values validated by prepare()).
struct Config {
    double sample_rate = 48000.0;
    double ratio = 1.0;               ///< target pitch ratio (1.0 = unity)
    int voices = 1;                   ///< active voices (1..max_voices)
    int max_voices = 8;               ///< allocated voices
    bool spread = true;               ///< musical spread table for voices > 1
    double feedback = 0.0;            ///< wet feedback in (-1, 1), 0 = off
    Interpolation interpolation = Interpolation::Lagrange6;
    double grain = 4096.0;            ///< G, samples (delay-line grain)
    double base_delay = 256.0;        ///< first voice base delay, samples
    double fmin = 55.0;               ///< spacing-accept gate (Hz)
    double fmax = 1200.0;             ///< spacing-accept gate (Hz)
    double s_hysteresis = 0.005;      ///< S commit hysteresis (relative)
    int f0_history = 8;               ///< period median window
    int detection_interval = 64;      ///< control-rate period, stream samples
    double engagement_seconds = 0.010;///< unity enter/exit morph time
    /// Geometric glide multiplier per sample (reference parity: 0.9995).
    static constexpr double kGlideMult = 0.9995;
};

/// Per-voice diagnostics (snapshot after processing).
struct VoiceStats {
    long wraps = 0;    ///< grain-phase wraps
    long commits = 0;  ///< tap-spacing commits (wrap commits + unity-exit ones)
    int engaged = 0;   ///< 1 = normal dual-tap voice, 0 = unity single-tap
    int parked = 0;    ///< 1 = parked on an integer delay (bit-exact unity)
    double spacing = 0.0;      ///< current S
    double phase = 0.0;        ///< current frac
    int parked_delay = -1;     ///< d_park when parked, else -1
};

/// One mono engine with 1..max_voices voices (port of the Python
/// AlignedDelayLineShifter + the round-12 unity engagement).
class AlignedDelayLine {
public:
    AlignedDelayLine();
    ~AlignedDelayLine();
    AlignedDelayLine(const AlignedDelayLine&) = delete;
    AlignedDelayLine& operator=(const AlignedDelayLine&) = delete;

    /// Validates the config, allocates all state, resets the engine.
    /// Returns false (and leaves the engine unusable) on invalid input.
    bool prepare(const Config& cfg);

    /// Back to the freshly-prepared state (parameters keep their values).
    void reset();

    // -- parameter updates (audio thread; no allocation, no locks) ---------
    void setRatio(double ratio);      ///< target ratio; exact 1.0 engages unity
    void setVoices(int n);            ///< 1..max_voices (normalisation ramps)
    void setSpread(bool on);
    void setFeedback(double fb);      ///< clamped to (-1, 1)

    const Config& config() const { return cfg_; }
    bool ready() const { return ready_; }
    int latencySamples() const;       ///< nominal (base + grain/2)
    int voices() const { return active_voices_; }

    /// Process a planar mono block of n samples. in/out may not alias.
    /// Any n >= 0; the control rate follows the stream, not the call size.
    void process(const float* in, float* out, int n);

    const VoiceStats& voiceStats(int v) const;
    /// Last detector estimate (Hz; 0 = none). Diagnostics only.
    double lastEstimateHz() const;

private:
    struct Impl;
    Impl* impl_ = nullptr;
    Config cfg_{};
    bool ready_ = false;
    int active_voices_ = 1;
};

/// N independent mono engines behind one parameter surface.
/// Channel isolation is structural: engine per channel, own ring/state.
class MultichannelShifter {
public:
    MultichannelShifter();
    ~MultichannelShifter();
    MultichannelShifter(const MultichannelShifter&) = delete;
    MultichannelShifter& operator=(const MultichannelShifter&) = delete;

    bool prepare(const Config& cfg, int channels);
    void reset();
    void setRatio(double ratio);
    void setVoices(int n);
    void setSpread(bool on);
    void setFeedback(double fb);

    bool ready() const;
    int channels() const;
    int latencySamples() const;

    /// Planar multichannel block: in[c] / out[c] are per-channel pointers.
    void process(const float* const* in, float* const* out, int channels, int n);

    const VoiceStats& voiceStats(int channel, int voice) const;

private:
    struct MImpl;
    MImpl* mimpl_ = nullptr;
};

/// Library version string ("octavox-native 12.0.0").
const char* versionString();

}  // namespace octavox
