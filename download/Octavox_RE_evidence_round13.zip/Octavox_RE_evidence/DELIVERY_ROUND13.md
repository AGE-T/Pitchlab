# OCTAVOX ROUND 13 DELIVERY

Continued from `Octavox_RE_evidence_round12.zip` (SHA-256
`a597546534c3f27bd941dea4a427ececbd9972e63b1fa183485eba509cdb0902`).
This file documents the round-13 package: contents, verification, the
delivery report and the known limits.

## Contents (manifest delta vs round 12)

* 305 files (round 12: 285). Delta: 285 unchanged in role; the round-13
  additions are 22 new evidence files under `evidence/analysis_round13/`,
  the round-13 findings document, this delivery file; the superseded
  `DELIVERY_ROUND12.md` was removed (its content is preserved inside the
  round-12 archive, which ships unchanged in the delivery set); updated:
  the seven canonical docs + README + the native tree (core, tests, bench,
  docs, CMake 13.0.0).
* The Python reference implementations (`poc/`) and every historical
  evidence directory (rounds 6–12) are byte-identical to the round-12
  archive (manifest-verified; the round-11/12 result JSONs that this
  round's re-runs would have overwritten were restored from the archive
  and the re-runs archived separately as `r13_rerun_*`).

## Verification (all from the shipped tree)

```sh
sha256sum -c checksums.txt            # run from inside Octavox_RE_evidence/
sha256sum ../Octavox_RE_evidence_round12.zip   # a5975465... (preserved)

cd native
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
./build/octavox_tests --json ../evidence/analysis_round13/r13_native_tests.json
      # 105/105, exit 0 (10.2 s CPU on the 2-core dev sandbox)
cmake -S . -B build-asan -DCMAKE_BUILD_TYPE=Debug -DENABLE_SANITIZERS=ON
cmake --build build-asan -j
./build-asan/octavox_tests --json ../evidence/analysis_round13/r13_native_tests_asan.json
      # 105/105, exit 0, ZERO sanitizer reports (89.3 s)
./build/octavox_bench --json ../evidence/analysis_round13/r13_native_bench.json
cd ..
python3 evidence/analysis_round11/r11_numeric_audit.py        # exit 0
python3 evidence/analysis_round11/r11_acceptance_tests.py    # 45/45 (~2.5 min)
python3 evidence/analysis_round12/r12_native_metrics.py \
    --poc poc --native-cli native/build/octavox_cli          # 15/15 gates
python3 evidence/analysis_round13/r13_kernel_fit.py          # kernel fit table
```

## Delivery report

Completed:
* Priority 1 (cold start): splice commit + ghost blend + startup wrap
  guard + B-tap readiness; full cent matrix, reset/restart, transitions,
  signal types measured before/after (`r13_coldstart_before/after.json`);
  acceptance covers cold start AND steady state (gates in the 105-case
  suite).
* Priority 2 (rates): decimated analysis path + config-driven range +
  edge rejection + valley selection; 44.1/48/96/192 kHz × 55–440 Hz
  battery + shifted + noise + capability report; detector valid range,
  control interval, cost and memory reported (bench + DetectorInfo).
* Priority 3 (real-time preparation): tables built at prepare (gated by
  three dedicated cases including a first-call timing/allocation check);
  `process()` contains no static locals; `voiceStats()` by value.
* Priority 4 (suite time): 105 cases in 10.2 s CPU (per-case durations in
  JSON); the 60-s/30-s coverage kept; the round-12 benchmark harness bug
  found, fixed and documented; performance re-measured.
* Priority 5 (static): record-ring ownership/writer/scaling (OBS, §6.1 of
  the findings) and the kernel characterisation (§6.2).
* Round-11/12 suites re-run from the package: audit exit 0, acceptance
  45/45, cross-language 15/15.

Known limits / open:
* The tracker's input quantity units (`xmm1`) and its ratio limiter's full
  semantics remain UNK (static residue, §6.1).
* The observed kernel's exact design formula remains UNK (§6.2).
* All runtime questions about the original plugin remain UNK (it was never
  executed; the controlled Windows-host tests listed in
  `OCTAVOX_ROUND11_FINDINGS.md` §6 remain the way to close them).
* Noise through the dual-tap blend is ~−3 dB RMS by design (the v2
  reference class) — documented and gated, not hidden.
* Absolute timings are machine-dependent (2-core sandbox, getrusage CPU
  time, best-of-3); the JSONs carry per-case values for cross-environment
  comparison.

No test in this round failed to complete; every gate result above is from
an actual run recorded in the shipped JSON files.
