#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OCTAVOX round 13 -- mathematical characterisation of the OBSERVED 256x6
interpolation kernel (target .rdata at VA 0x1803B6170, extracted bit-exactly
in round 12 as evidence/analysis_round12/r12_obs_kernel_table.h).

Question (round-12 residue): is the kernel a recognisable design family?
Method: least-squares fits of windowed-sinc / polynomial families to every
row (phase mu_r = (r+0.5)/256, taps at x_k = k-2-mu_r), reporting the RMS
residual per family. Purely numerical analysis of OBSERVED DATA.

Output: r13_kernel_fit.txt
"""

import math
import re
import sys

import numpy as np

TABLE_H = ("evidence/analysis_round12/r12_obs_kernel_table.h")
OUT = "/home/z/octavox/analysis/r13_kernel_fit.txt"


def load_table():
    txt = open(TABLE_H).read()
    rows = []
    for line in txt.splitlines():
        line = line.split("//")[0].strip()   # drop the trailing row comment
        if not (line.startswith("{") and line.endswith("},")):
            continue
        body = line[1:-2]
        parts = [p.strip() for p in body.split(",")]
        if len(parts) == 6:
            rows.append([float.fromhex(p) for p in parts])
    assert len(rows) == 256, len(rows)
    return np.array(rows, dtype=np.float64)


def sinc(x):
    out = np.ones_like(x)
    nz = x != 0
    out[nz] = np.sin(math.pi * x[nz]) / (math.pi * x[nz])
    return out


def window(name, x, half):
    # x measured from the kernel centre; support [-half, half]
    t = x / half
    if name == "hann":
        return 0.5 + 0.5 * np.cos(math.pi * np.clip(t, -1, 1))
    if name == "blackman":
        a = math.pi * np.clip(t, -1, 1)
        return 0.42 + 0.5 * np.cos(a) + 0.08 * np.cos(2 * a)
    if name == "hamming":
        return 0.54 + 0.46 * np.cos(math.pi * np.clip(t, -1, 1))
    if name == "blackman_harris":
        a = math.pi * np.clip(t, -1, 1)
        return 0.35875 + 0.48829 * np.cos(a) + 0.14128 * np.cos(2 * a) + 0.01168 * np.cos(3 * a)
    if name == "lanczos":  # sinc window (a = half)
        return sinc(t)
    if name == "none":
        return np.ones_like(x)
    raise ValueError(name)


def fit_row(row, mu, family, half):
    """LS fit h[k] ~= A * W(x_k) * sinc(c * x_k), x_k = k-2-mu.
    Unknowns: A, c (nonlinear in c -> 1-D grid search over c, LS for A)."""
    x = np.array([k - 2 - mu for k in range(6)])
    w = window(family, x, half)
    best = None
    # c = cutoff in cycles/sample of the sinc argument (0.3 .. 1.4)
    for c in np.linspace(0.30, 1.40, 441):
        basis = w * sinc(c * x)
        A = float(np.dot(row, basis) / np.dot(basis, basis)) if np.dot(basis, basis) > 0 else 0.0
        r = row - A * basis
        e = float(np.sqrt(np.mean(r * r)))
        if best is None or e < best[0]:
            best = (e, A, c)
    return best


def main():
    T = load_table()
    lines = []
    lines.append("OCTAVOX round 13 -- OBS kernel family fit (256 rows x 6 taps)")
    lines.append(f"source: {TABLE_H} (bit-exact .rdata extraction, round 12)")
    lines.append("model per row r: h[k] ~ A * W(k-2-mu_r) * sinc(c*(k-2-mu_r)),")
    lines.append("  mu_r = (r+0.5)/256, taps k=0..5; window centred on the kernel")
    lines.append("  centre with half-width `half` (grid taps span -2.5..+2.5).")
    lines.append("")
    families = [
        ("blackman", 3.0), ("blackman", 2.5), ("blackman", 3.5),
        ("hann", 3.0), ("hann", 2.5),
        ("hamming", 3.0),
        ("blackman_harris", 3.0),
        ("lanczos", 3.0), ("lancicz", 3.0),  # placeholder removed below
        ("none", 3.0),
    ]
    families = [f for f in families if f[0] != "lancicz"]
    results = []
    for fam, half in families:
        errs, As, cs = [], [], []
        for r in range(256):
            mu = (r + 0.5) / 256.0
            e, A, c = fit_row(T[r], mu, fam, half)
            errs.append(e)
            As.append(A)
            cs.append(c)
        rms = float(np.sqrt(np.mean(np.array(errs) ** 2)))
        results.append((rms, fam, half, np.mean(As), np.std(As), np.mean(cs), np.std(cs)))
    results.sort()
    lines.append(f"{'family':16s} {'half':>5s} {'rms':>10s} {'A mean':>8s} {'A std':>8s} {'c mean':>7s} {'c std':>7s}")
    for rms, fam, half, Am, As, cm, cs in results:
        lines.append(f"{fam:16s} {half:5.1f} {rms:10.3e} {Am:8.4f} {As:8.4f} {cm:7.4f} {cs:7.4f}")
    lines.append("")
    best = results[0]
    lines.append(f"best family: {best[1]} half={best[2]} rms={best[0]:.3e}")
    lines.append("")

    # Also: how close is the best family per-row (worst rows)?
    fam, half = best[1], best[2]
    worst = []
    for r in range(256):
        mu = (r + 0.5) / 256.0
        e, A, c = fit_row(T[r], mu, fam, half)
        worst.append((e, r, A, c))
    worst.sort(reverse=True)
    lines.append("worst 8 rows under the best family (err, row, A, c):")
    for e, r, A, c in worst[:8]:
        lines.append(f"  row {r:3d}: err={e:.3e} A={A:.4f} c={c:.4f}")

    # Row-sum and unity-DC check (round 12 observed 1.0000-1.0001)
    sums = T.sum(axis=1)
    lines.append("")
    lines.append(f"row sums: min={sums.min():.6f} max={sums.max():.6f} (round-12 OBS)")

    # Symmetry check
    sym = float(np.abs(T - T[::-1, ::-1]).max())
    lines.append(f"mirror symmetry max |T[r,k]-T[255-r,5-k]| = {sym:.3e}")

    with open(OUT, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    sys.exit(main())
