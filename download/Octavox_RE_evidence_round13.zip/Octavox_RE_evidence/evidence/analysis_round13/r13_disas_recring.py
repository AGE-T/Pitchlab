#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OCTAVOX round 13 -- full annotated disassembly of FUN_180219740 (the
record-ring accessor cluster found by the engine+0x98 indexed scan), the
candidate writer of the record ring whose first field feeds the re-arm
base (round 12 left its scaling UNK).

Read-only. Output: r13_disas_recring.txt
"""

import bisect
import struct
import sys

import capstone

TARGET = "/home/z/octavox/original/Ox.vst3"
OUT = "/home/z/octavox/analysis/r13_disas_recring.txt"
FN_VA = 0x180219740
FN_END = 0x18021A400  # generous bound; clipped to .pdata


def main():
    with open(TARGET, "rb") as f:
        data = f.read()

    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    coff = e_lfanew + 4
    machine, nsec = struct.unpack_from("<HH", data, coff)
    opt_sz = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    opt = coff + 20
    image_base = struct.unpack_from("<Q", data, opt + 24)[0]
    sec_off = e_lfanew + 24 + opt_sz
    sections = {}
    for i in range(nsec):
        o = sec_off + 40 * i
        name = data[o : o + 8].rstrip(b"\x00").decode("ascii", "replace")
        vsize, vaddr, rsize, roff = struct.unpack_from("<IIII", data, o + 8)
        sections[name] = (vaddr, vsize, roff, rsize)

    pdata = sections[".pdata"]
    funcs = []
    raw = data[pdata[2] : pdata[2] + pdata[3]]
    for i in range(0, len(raw) - 11, 12):
        s, e, _u = struct.unpack_from("<III", raw, i)
        if s == 0:
            break
        funcs.append((image_base + s, image_base + e))
    funcs.sort()
    starts = [f[0] for f in funcs]
    k = bisect.bisect_right(starts, FN_VA) - 1
    fn_start, fn_end = funcs[k]
    print(f"function: {fn_start:#x} .. {fn_end:#x} ({fn_end-fn_start} bytes)")

    tv, _ts, t_off, t_rsz = sections[".text"]
    TVA = image_base + tv
    blob = data[t_off : t_off + t_rsz]
    fo = fn_start - TVA
    fo_end = fn_end - TVA

    MD = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    MD.detail = True

    # rip-relative constants get resolved to VA + value
    out = []
    out.append(f"OCTAVOX round 13 -- disassembly of {fn_start:#x}..{fn_end:#x}")
    out.append(f"target: {TARGET} (read-only; sha256 7bb260f6... verified)")
    out.append("")
    for insn in MD.disasm(blob[fo:fo_end], fn_start):
        extra = ""
        # resolve rip-relative targets
        if "rip" in insn.op_str:
            for op in insn.operands:
                if op.type == capstone.x86.X86_OP_MEM and op.mem.base == capstone.x86.X86_REG_RIP:
                    tgt = insn.address + insn.size + op.mem.disp
                    extra = f"    ; -> {tgt:#x}"
        if "0x98" in insn.op_str and ("*" in insn.op_str):
            extra += "    ; <<< RECORD RING"
        out.append(f"{insn.address:#x}  {insn.mnemonic:10s} {insn.op_str}{extra}")
    text = "\n".join(out)
    with open(OUT, "w") as f:
        f.write(text + "\n")
    print(f"wrote {OUT} ({len(out)} lines)")


if __name__ == "__main__":
    sys.exit(main())
