#include <cstdio>
#include <cmath>
#include <vector>
// Replica of the suite's pitchFFT to check its own accuracy at low f.
void fft(double* re, double* im, int n) {
    for (int i = 1, j = 0; i < n; ++i) { int bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit;
        if (i < j) { std::swap(re[i], re[j]); std::swap(im[i], im[j]); } }
    for (int len = 2; len <= n; len <<= 1) { const double ang = -2.0*M_PI/len; const double wr = std::cos(ang), wi = std::sin(ang);
        for (int i = 0; i < n; i += len) { double cr = 1.0, ci = 0.0;
            for (int k = 0; k < len/2; ++k) { const double ur = re[i+k], ui = im[i+k];
                const double vr = re[i+k+len/2]*cr - im[i+k+len/2]*ci, vi = re[i+k+len/2]*ci + im[i+k+len/2]*cr;
                re[i+k] = ur+vr; im[i+k] = ui+vi; re[i+k+len/2] = ur-vr; im[i+k+len/2] = ui-vi;
                const double nr = cr*wr - ci*wi; ci = cr*wi + ci*wr; cr = nr; } } }
}
double pitchFFT(const float* x, int n, int sr, double fmin, double fmax) {
    int N = 1; while (N < n && N < 262144) N <<= 1; if (N < 16) return 0.0;
    std::vector<double> re(N, 0.0), im(N, 0.0); const int off = n - N;
    for (int i = 0; i < N; ++i) { const double w = 0.5 - 0.5*std::cos(2.0*M_PI*i/N); re[i] = (double)x[off+i]*w; }
    fft(re.data(), im.data(), N);
    const int kmin = std::max(1, (int)(fmin*N/sr)), kmax = std::min(N/2-2, (int)(fmax*N/sr));
    int kp = kmin; double best = 0.0;
    for (int k = kmin; k <= kmax; ++k) { const double m = re[k]*re[k]+im[k]*im[k]; if (m > best) { best = m; kp = k; } }
    const double a = re[kp-1]*re[kp-1]+im[kp-1]*im[kp-1], b = best, c = re[kp+1]*re[kp+1]+im[kp+1]*im[kp+1];
    double d = 0.0; const double den = a - 2*b + c; if (std::abs(den) > 1e-300) d = 0.5*(a-c)/den;
    if (d > 0.5) d = 0.5; if (d < -0.5) d = -0.5;
    return (double)sr*(kp+d)/N;
}
int main() {
    for (double f : {69.2957, 75.6, 100.8, 138.6, 277.18, 554.36}) {  // expected outputs of +400c
        const int sr = 48000; const int n = 72000;  // 1.5 s like the suite
        std::vector<float> x(n);
        const double fshift = f;
        for (int i = 0; i < n; ++i) x[i] = (float)(0.5*std::sin(2*M_PI*fshift*i/sr));
        const double fm = pitchFFT(x.data()+24000, n-24000, sr, 30.0, 6000.0);
        printf("true %8.3f Hz -> meter %8.3f Hz  error %+6.3f cents\n", fshift, fm, 1200*std::log2(fm/fshift));
    }
    return 0;
}
