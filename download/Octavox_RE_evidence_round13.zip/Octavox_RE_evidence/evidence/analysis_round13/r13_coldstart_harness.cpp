// OCTAVOX round 13 -- BEFORE-measurement harness (round-12 library, unmodified)
// Captures the documented defects as machine-readable JSON:
//   P1 cold-start near-unity behaviour, P2 detector vs sample rate,
//   P4 cost of the expensive long-run cases.
// This file links against the ROUND-12 library and is archived as evidence of
// the BEFORE state; the AFTER harness is the same measurement code built
// against the round-13 library (r13_coldstart_after.json).
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "octavox/dsp.hpp"

using namespace octavox;

// ---- deterministic generators (same formulas as the round-12 suite) --------
namespace gen {
struct Lcg {
    uint64_t s;
    explicit Lcg(uint64_t seed) : s(seed * 6364136223846793005ULL + 1442695040888963407ULL) {}
    double next() {
        s = s * 6364136223846793005ULL + 1442695040888963407ULL;
        return ((s >> 11) * (1.0 / 9007199254740992.0));
    }
};
std::vector<float> tone(double f, int sr, int n, double a) {
    std::vector<float> x(n);
    for (int i = 0; i < n; ++i) x[i] = (float)(a * std::sin(2.0 * M_PI * f * i / sr));
    return x;
}
std::vector<float> noise(uint64_t seed, int n, double a) {
    Lcg r(seed);
    std::vector<float> x(n);
    for (int i = 0; i < n; ++i) x[i] = (float)((2.0 * r.next() - 1.0) * a);
    return x;
}
}  // namespace gen

// ---- measurements -----------------------------------------------------------
namespace meas {
double rms(const float* x, int n) {
    double s = 0.0;
    for (int i = 0; i < n; ++i) s += (double)x[i] * x[i];
    return std::sqrt(s / std::max(1, n));
}
double peak(const float* x, int n) {
    double p = 0.0;
    for (int i = 0; i < n; ++i) p = std::max(p, std::abs((double)x[i]));
    return p;
}
double maxStep(const float* x, int n) {
    double m = 0.0;
    for (int i = 1; i < n; ++i) m = std::max(m, std::abs((double)x[i] - x[i - 1]));
    return m;
}
bool allFinite(const float* x, int n) {
    for (int i = 0; i < n; ++i)
        if (!std::isfinite(x[i])) return false;
    return true;
}
// FFT pitch (Goertzel-dense peak search, same approach as the r12 suite)
double pitchFFT(const float* x, int n, int sr, double flo, double fhi) {
    // Hann + zero-padded DFT via direct correlation over a log-spaced grid
    // then parabolic refine (deterministic; adequate for cent-level accuracy).
    const int N = 1 << 15;
    std::vector<double> re(N, 0.0), im(N, 0.0);
    const int m = std::min(n, N);
    for (int i = 0; i < m; ++i) {
        const double w = 0.5 - 0.5 * std::cos(2.0 * M_PI * i / m);
        re[i] = (double)x[i] * w;
    }
    double bestF = 0.0, bestA = -1.0;
    const double lo = std::max(flo, 1.0), hi = fhi;
    for (double lf = std::log2(lo); lf <= std::log2(hi); lf += 0.001) {
        const double f = std::pow(2.0, lf);
        double srAcc = 0.0, siAcc = 0.0;
        for (int i = 0; i < m; ++i) {
            const double ph = 2.0 * M_PI * f * i / sr;
            srAcc += re[i] * std::cos(ph) + im[i] * 0;  // im is zero (real input)
            siAcc += re[i] * std::sin(ph);
        }
        const double a = srAcc * srAcc + siAcc * siAcc;
        if (a > bestA) { bestA = a; bestF = f; }
    }
    return bestF;
}
// period-synchronous envelope modulation (r11 lesson: window = input period)
double envModDb(const float* x, int n, int sr, int skip, int perW) {
    if (perW < 2) return 0.0;
    std::vector<double> env;
    for (int i0 = skip; i0 + perW <= n; i0 += perW) {
        env.push_back(rms(x + i0, perW));
    }
    if (env.size() < 3) return 0.0;
    const double mx = *std::max_element(env.begin(), env.end());
    const double mn = *std::min_element(env.begin(), env.end());
    if (mn <= 0.0) return 0.0;
    return 20.0 * std::log10(mx / mn);
}
}  // namespace meas

static std::string g_json;
void jbegin() { g_json = "{\n  \"harness\": \"r13_before (round-12 library)\",\n  \"cases\": [\n"; }
int g_idx = 0;
void jcase(const std::string& name, const std::vector<std::pair<std::string, double>>& vals) {
    char buf[512];
    std::string j = "    {\"name\": \"" + name + "\", \"values\": {";
    for (size_t i = 0; i < vals.size(); ++i) {
        std::snprintf(buf, sizeof(buf), "\"%s\": %.10g", vals[i].first.c_str(), vals[i].second);
        j += buf;
        if (i + 1 < vals.size()) j += ", ";
    }
    j += "}}";
    if (++g_idx > 1) g_json += ",\n";
    g_json += j;
}
void jend(const char* path) {
    g_json += "\n  ]\n}\n";
    FILE* f = std::fopen(path, "wb");
    if (f) { std::fwrite(g_json.data(), 1, g_json.size(), f); std::fclose(f); }
}

double semitoneRatio(double c) { return std::pow(2.0, c / 1200.0); }

// ---- P1: cold-start matrix --------------------------------------------------
// For a fresh engine at `cents`: 3 s of 220 Hz tone; measure windows.
void coldStart(const std::string& tag, double cents, int sr, double f0,
               std::vector<std::pair<std::string, double>>* extra = nullptr) {
    Config cfg;
    cfg.ratio = semitoneRatio(cents);
    cfg.sample_rate = sr;
    const int n = 3 * sr;
    const auto in = gen::tone(f0, sr, n, 0.5);
    AlignedDelayLine e;
    e.prepare(cfg);
    std::vector<float> out(n, 0.f);
    // poll voice stats every block to find the first commit sample
    int firstCommit = -1, block = 256;
    long lastC = 0;
    for (int i0 = 0; i0 < n; i0 += block) {
        const int m = std::min(block, n - i0);
        e.process(in.data() + i0, out.data() + i0, m);
        const long c = e.voiceStats(0).commits;
        if (c > lastC && firstCommit < 0) firstCommit = i0 + m;
        lastC = c;
    }
    const double ri = meas::rms(in.data(), n);
    std::vector<std::pair<std::string, double>> v;
    auto add = [&](const char* k, double x) { v.push_back({k, x}); };
    add("cents", cents);
    add("sr", sr);
    add("f0", f0);
    add("gain_db_first100ms",
        20.0 * std::log10(meas::rms(out.data(), sr / 10) / meas::rms(in.data(), sr / 10)));
    add("gain_db_first1s", 20.0 * std::log10(meas::rms(out.data(), sr) / meas::rms(in.data(), sr)));
    add("gain_db_steady_2to3s",
        20.0 * std::log10(meas::rms(out.data() + 2 * sr, sr) / meas::rms(in.data() + 2 * sr, sr)));
    {
        const double fm = meas::pitchFFT(out.data() + 1500 * sr / 1000, n - 1500 * sr / 1000, sr,
                                         50.0, 4000.0);
        add("pitch_error_cents", 1200.0 * std::log2(fm / f0) - cents);
    }
    {
        const int perW = std::max(2, (int)std::lround(sr / f0));
        add("env_mod_db_after200ms", meas::envModDb(out.data(), n, sr, sr / 5, perW));
    }
    add("first_commit_sample", firstCommit < 0 ? -1 : firstCommit);
    add("first_commit_ms", firstCommit < 0 ? -1.0 : 1000.0 * firstCommit / sr);
    add("spacing_final", e.voiceStats(0).spacing);
    add("commits_final", (double)e.voiceStats(0).commits);
    add("wraps_final", (double)e.voiceStats(0).wraps);
    add("max_step_out_first1s", meas::maxStep(out.data(), sr));
    add("max_step_in", meas::maxStep(in.data(), sr));
    add("finite", meas::allFinite(out.data(), n) ? 1.0 : 0.0);
    if (extra) for (auto& p : *extra) v.push_back(p);
    jcase("coldstart_" + tag, v);
}

int main(int argc, char** argv) {
    const char* outPath = "/tmp/r13_before.json";
    if (argc > 1) outPath = argv[1];
    jbegin();
    const int sr = 48000;

    // ---- P1 cold-start battery -------------------------------------------
    const double centsList[] = {0.0, 1.0, -1.0, 10.0, -10.0, 50.0, -50.0, 100.0, -100.0, 500.0, -500.0, 1200.0, -1200.0};
    for (double c : centsList) {
        char tag[32]; std::snprintf(tag, sizeof(tag), "%+gc_220hz", c);
        coldStart(tag, c, sr, 220.0);
    }
    // a couple of alternate frequencies at the worst case (+/-10 c)
    coldStart("+10c_110hz", 10.0, sr, 110.0);
    coldStart("-10c_440hz", -10.0, sr, 440.0);

    // reset/restart determinism at each ratio (fresh vs reset engine, first 1 s)
    {
        for (double c : centsList) {
            Config cfg; cfg.ratio = semitoneRatio(c);
            const auto in = gen::tone(220.0, sr, sr, 0.5);
            AlignedDelayLine a, b;
            a.prepare(cfg); b.prepare(cfg);
            std::vector<float> oa(sr, 0.f), ob(sr, 0.f), ob2(sr, 0.f);
            a.process(in.data(), oa.data(), sr);
            b.process(in.data(), ob.data(), sr);
            b.reset();
            b.process(in.data(), ob2.data(), sr);
            double d = 0.0;
            for (int i = 0; i < sr; ++i)
                d = std::max(d, std::abs((double)oa[i] - ob[i]));
            double d2 = 0.0;
            for (int i = 0; i < sr; ++i)
                d2 = std::max(d2, std::abs((double)ob[i] - ob2[i]));
            char tag[32]; std::snprintf(tag, sizeof(tag), "reset_restart_%+gc", c);
            jcase(tag, {{"cents", c}, {"fresh_vs_fresh", d}, {"reset_vs_fresh", d2}});
        }
    }

    // ---- P2 detector vs sample rate --------------------------------------
    {
        const int rates[] = {44100, 48000, 96000, 192000};
        const double freqs[] = {55.0, 60.0, 80.0, 110.0, 220.0, 440.0};
        for (int rsr : rates) {
            for (double f : freqs) {
                Config cfg;
                cfg.sample_rate = rsr;
                cfg.ratio = semitoneRatio(400.0);
                const int n = 3 * rsr;
                const auto in = gen::tone(f, rsr, n, 0.5);
                AlignedDelayLine e;
                const bool ok = e.prepare(cfg);
                std::vector<float> out(n, 0.f);
                e.process(in.data(), out.data(), n);
                const double fm = meas::pitchFFT(out.data() + rsr, 2 * rsr, rsr, 30.0, 6000.0);
                char tag[64];
                std::snprintf(tag, sizeof(tag), "rate_%d_f%.0f", rsr, f);
                jcase(tag, {
                    {"prepared", ok ? 1.0 : 0.0},
                    {"last_estimate_hz", e.lastEstimateHz()},
                    {"pitch_error_cents", 1200.0 * std::log2(fm / f) - 400.0},
                    {"finite", meas::allFinite(out.data(), n) ? 1.0 : 0.0},
                });
            }
            // noise at this rate: no estimate expected -> fallback behaviour
            {
                Config cfg;
                cfg.sample_rate = rsr;
                cfg.ratio = semitoneRatio(400.0);
                const int n = rsr;
                const auto in = gen::noise(9, n, 0.5);
                AlignedDelayLine e;
                e.prepare(cfg);
                std::vector<float> out(n, 0.f);
                e.process(in.data(), out.data(), n);
                char tag[64];
                std::snprintf(tag, sizeof(tag), "rate_%d_noise", rsr);
                jcase(tag, {{"last_estimate_hz", e.lastEstimateHz()},
                            {"finite", meas::allFinite(out.data(), n) ? 1.0 : 0.0},
                            {"peak", meas::peak(out.data(), n)}});
            }
        }
    }

    // ---- P4 cost of the expensive cases -----------------------------------
    {
        using clk = std::chrono::steady_clock;
        // 60 s noise 8 voices feedback (the suite's longrun case)
        {
            Config cfg;
            cfg.ratio = semitoneRatio(1200.0);
            cfg.voices = 8;
            cfg.feedback = 0.35;
            const int n = 60 * sr;
            const auto in = gen::noise(2025, n, 0.5);
            AlignedDelayLine e;
            e.prepare(cfg);
            std::vector<float> out(n, 0.f);
            const auto t0 = clk::now();
            e.process(in.data(), out.data(), n);
            const auto t1 = clk::now();
            const double sec = std::chrono::duration<double>(t1 - t0).count();
            jcase("cost_60s_8voice_noise", {{"seconds", sec},
                                            {"ns_per_sample", sec * 1e9 / n},
                                            {"realtime_factor", 60.0 / sec}});
        }
        // 30 s chirp-ish: swept tone (chirp generator: quad sweep)
        {
            Config cfg;
            cfg.ratio = semitoneRatio(700.0);
            const int n = 30 * sr;
            std::vector<float> in(n);
            double ph = 0.0;
            for (int i = 0; i < n; ++i) {
                const double f = 100.0 * std::pow(10.0, i / (double)n);  // 100->1000 Hz
                ph += 2.0 * M_PI * f / sr;
                in[i] = (float)(0.5 * std::sin(ph));
            }
            AlignedDelayLine e;
            e.prepare(cfg);
            std::vector<float> out(n, 0.f);
            const auto t0 = clk::now();
            e.process(in.data(), out.data(), n);
            const auto t1 = clk::now();
            const double sec = std::chrono::duration<double>(t1 - t0).count();
            jcase("cost_30s_chirp", {{"seconds", sec},
                                     {"ns_per_sample", sec * 1e9 / n},
                                     {"realtime_factor", 30.0 / sec}});
        }
        // detector cost probe: tonal input (early-exit potential) at 48 k
        {
            Config cfg;
            cfg.ratio = semitoneRatio(400.0);
            const int n = 10 * sr;
            const auto in = gen::tone(220.0, sr, n, 0.5);
            AlignedDelayLine e;
            e.prepare(cfg);
            std::vector<float> out(n, 0.f);
            const auto t0 = clk::now();
            e.process(in.data(), out.data(), n);
            const auto t1 = clk::now();
            const double sec = std::chrono::duration<double>(t1 - t0).count();
            jcase("cost_10s_tone_1voice", {{"seconds", sec},
                                           {"ns_per_sample", sec * 1e9 / n},
                                           {"realtime_factor", 10.0 / sec}});
        }
    }

    jend(outPath);
    std::printf("wrote %s (%d cases)\n", outPath, g_idx);
    return 0;
}
