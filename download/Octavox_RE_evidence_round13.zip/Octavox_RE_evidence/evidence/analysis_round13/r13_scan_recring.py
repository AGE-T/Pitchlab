#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OCTAVOX round 13 -- static scan: find every .text site whose memory operand
carries displacement 0x98 (the engine's record ring base, per the round-12
prepare disassembly at 0x1800E2600/0x1800E2630/0x1800E264A: reads
`[rsi + rcx*4 + 0x98]` with the 0xFFF ring mask) together with any nearby
0xFFF masks, to locate the WRITER of the record ring's fields and the
scaling of its first field (the re-arm base `v = ring[recidx]·2^-11`
clamped to [48, 480] -- round 12 left this UNK).

Read-only scan of the shipped image. Output: r13_scan_recring.txt
"""

import bisect
import struct
import sys

import capstone

TARGET = "/home/z/octavox/original/Ox.vst3"
OUT = "/home/z/octavox/analysis/r13_scan_recring.txt"
RING_DISP = 0x98


def main():
    with open(TARGET, "rb") as f:
        data = f.read()

    e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
    coff = e_lfanew + 4
    machine, nsec = struct.unpack_from("<HH", data, coff)
    opt_sz = struct.unpack_from("<H", data, e_lfanew + 20)[0]
    opt = coff + 20
    image_base = struct.unpack_from("<Q", data, opt + 24)[0]  # PE32+
    sec_off = e_lfanew + 24 + opt_sz
    sections = {}
    for i in range(nsec):
        o = sec_off + 40 * i
        name = data[o : o + 8].rstrip(b"\x00").decode("ascii", "replace")
        vsize, vaddr, rsize, roff = struct.unpack_from("<IIII", data, o + 8)
        sections[name] = (vaddr, vsize, roff, rsize)

    tv, _ts, t_off, t_rsz = sections[".text"]
    TVA = image_base + tv
    TBLOB = data[t_off : t_off + t_rsz]

    pdata = sections[".pdata"]
    funcs = []
    raw = data[pdata[2] : pdata[2] + pdata[3]]
    for i in range(0, len(raw) - 11, 12):
        s, e, _u = struct.unpack_from("<III", raw, i)
        if s == 0:
            break
        funcs.append((image_base + s, image_base + e))
    funcs.sort()
    starts = [f[0] for f in funcs]

    def fn_of(va):
        k = bisect.bisect_right(starts, va) - 1
        if k >= 0 and va < funcs[k][1]:
            return k
        return -1

    MD = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    MD.detail = True

    # Round-9/12 raw-byte method: find the 4-byte displacement needle, then
    # walk backwards to the instruction that ends on it and verify the memory
    # operand (robust against linear-disassembly desynchronisation).
    needle = struct.pack("<i", RING_DISP)
    hits = []
    start = 0
    while True:
        i = TBLOB.find(needle, start)
        if i < 0:
            break
        start = i + 1
        ctx = None
        for back in range(1, 13):
            begin = i - back
            if begin < 0:
                break
            try:
                insns = list(MD.disasm(TBLOB[begin : i + 4], TVA + begin, count=1))
            except Exception:
                continue
            if insns and insns[0].size == back + 4:
                ins = insns[0]
                for op in ins.operands:
                    if (
                        op.type == capstone.x86.X86_OP_MEM
                        and op.mem.disp == RING_DISP
                    ):
                        ctx = ins
                        break
                if ctx is not None:
                    break
        if ctx is not None:
            hits.append(ctx)

    # annotate each hit with its function and whether a 0xfff appears within
    # the surrounding instruction window (ring-mask signature)
    lines = []
    per_fn = {}
    for insn in hits:
        k = fn_of(insn.address)
        fname = f"FUN_{insn.address - 0x180000000:08X}" if k < 0 else (
            f"FUN_{funcs[k][0] - 0x180000000:08X}")
        # surrounding window for mask detection
        lo = max(TVA, insn.address - 64)
        hi = min(TVA + len(TBLOB), insn.address + 64)
        window = list(MD.disasm(TBLOB[lo - TVA : hi - TVA], lo))
        has_mask = any(
            (i.op_str.find("0xfff") >= 0) or (i.op_str.find("0xfff,") >= 0)
            for i in window
        )
        writes = insn.mnemonic.startswith("mov") and (
            insn.op_str.split(",")[0].strip().startswith("dword ptr [") or
            insn.op_str.split(",")[0].strip().startswith("qword ptr ["))
        tag = ""
        if has_mask:
            tag += " RINGMASK"
        if writes:
            tag += " WRITE"
        lines.append(f"{insn.address:#x}  {insn.mnemonic:10s} {insn.op_str}"
                     f"    [{fname}{tag}]")
        key = (k if k >= 0 else -1, fname)
        per_fn.setdefault(key, [0, 0])
        per_fn[key][0] += 1
        if writes:
            per_fn[key][1] += 1

    with open(OUT, "w") as f:
        f.write("OCTAVOX round 13 -- record-ring (engine+0x98) access scan\n")
        f.write(f"target: {TARGET} (read-only)\n")
        f.write(f"sites with memory displacement 0x{RING_DISP:x}: "
                f"{len(hits)}\n\n")
        f.write("per-function summary (count, writes):\n")
        for (k, fname), (cnt, wr) in sorted(per_fn.items(), key=lambda x: -x[1][0]):
            f.write(f"  {fname:20s} accesses={cnt:4d} writes={wr:4d}\n")
        f.write("\nsites:\n")
        for ln in lines:
            f.write(ln + "\n")
    print(f"wrote {OUT}: {len(hits)} sites across {len(per_fn)} functions")
    for (k, fname), (cnt, wr) in sorted(per_fn.items(), key=lambda x: -x[1][0])[:12]:
        print(f"  {fname:20s} accesses={cnt:4d} writes={wr:4d}")


if __name__ == "__main__":
    sys.exit(main())
