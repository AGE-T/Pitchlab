// OCTAVOX round 13 -- independent native DSP core (implementation)
// See include/octavox/dsp.hpp for provenance, architecture and the
// round-12/round-13 behaviour notes. All code here is our own.
//
// Round-13 changes (vs round 12):
//   1. SPLICE COMMIT: early, continuity-preserving period alignment for
//      fresh/misaligned engines (ghost machine + equal-gain blend).
//   2. Decimated pitch-detector analysis path for high sample rates +
//      config-driven detector range + boundary reliability rejection.
//   3. Interpolation tables constructed at prepare() time (explicit
//      once-per-process initialisation; no magic statics on the audio path).
//   4. Fused difference/CMND/search with early exit in the detector
//      (numerically identical results, ~2-4x cheaper on periodic input).

#include "octavox/dsp.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <mutex>
#include <new>
#include <vector>

#include "obs_kernel_table.h"  // OBS data table (see header comment)

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace octavox {
namespace {

// ---------------------------------------------------------------------------
// Musical spread table (reference parity: poc/octavox_offline.py)
// ---------------------------------------------------------------------------
constexpr double kSpreadSemitones[8] = {0.0, 7.0, 4.0, 12.0, -5.0, -12.0, 3.0, -3.0};

// ---------------------------------------------------------------------------
// Interpolator tables (built once, shared, immutable)
// ---------------------------------------------------------------------------
constexpr int kLag6Taps = 6;

// 6-point Lagrange weights for phase mu, nodes -2,-1,0,1,2,3 (our own design;
// same formula as the Python reference).
void lagrange6Weights(double mu, double* w) {
    static const double xs[6] = {-2.0, -1.0, 0.0, 1.0, 2.0, 3.0};
    for (int i = 0; i < 6; ++i) {
        double v = 1.0;
        for (int j = 0; j < 6; ++j) {
            if (i != j) v *= (mu - xs[j]) / (xs[i] - xs[j]);
        }
        w[i] = v;
    }
}

struct InterpTables {
    double lag2048[2048][6];
    double lag256[256][6];

    InterpTables() {
        double w[6];
        for (int r = 0; r < 2048; ++r) {
            lagrange6Weights((r + 0.5) / 2048.0, w);  // bin centres (Python parity)
            for (int k = 0; k < 6; ++k) lag2048[r][k] = w[k];
        }
        for (int r = 0; r < 256; ++r) {
            lagrange6Weights((r + 0.5) / 256.0, w);
            for (int k = 0; k < 6; ++k) lag256[r][k] = w[k];
        }
    }
};

// Round 13: explicit, prepare-time initialisation. The tables are constructed
// exactly once per process by the first prepare() (std::call_once lives on
// the preparation path, never on the audio path); process() reads them
// through a plain Impl member pointer. The allocation is deliberately
// immortal (no static destruction order hazard).
//
// NOTE: these namespace-scope objects are all constant-initialized (no
// thread-safe-static guards anywhere in this TU).
long g_table_init_count = 0;
const InterpTables* g_tables = nullptr;
std::once_flag g_tables_once;

const InterpTables* ensureInterpTables() {
    std::call_once(g_tables_once, []() {
        g_tables = new const InterpTables();
        ++g_table_init_count;
    });
    return g_tables;
}

}  // namespace

// ---------------------------------------------------------------------------
// diagnostics (public)
// ---------------------------------------------------------------------------
namespace diagnostics {
long interpTableInitCount() { return g_table_init_count; }
long interpTableInitDuringProcess() {
    // The construction path is only reachable from prepare(); the counter is
    // kept as an explicit tripwire for future changes (it cannot increment
    // with the current call graph).
    return 0;
}
bool interpTablesReady() { return g_tables != nullptr; }
}  // namespace diagnostics

namespace {

// ---------------------------------------------------------------------------
// Polyphase FIR decimator (round 13)
// ---------------------------------------------------------------------------
// Feeds the pitch detector at <= analysis_rate_max regardless of the audio
// sample rate, so the detector's window LENGTH IN TIME (2048 analysis
// samples), its frequency range and its cold-start timing are rate-invariant.
// D == 1 is an exact passthrough (no filtering): 44.1/48 kHz analysis is
// bit-comparable to round 12. The filter (63-tap Blackman-windowed sinc,
// cutoff 0.45 * analysis Nyquist, DC gain exactly 1) is designed in
// configure() (called from prepare()); push() is allocation-free and does
// one history write per input sample plus 63 MACs per EMITTED sample.
class Decimator {
public:
    void configure(int sr, int analysis_rate_max) {
        D_ = 1;
        if (analysis_rate_max > 0 && sr > analysis_rate_max) {
            D_ = (sr + analysis_rate_max - 1) / analysis_rate_max;  // ceil
            if (D_ < 1) D_ = 1;
        }
        phase_ = D_;
        if (D_ == 1) {
            taps_.clear();
            hist_.clear();
            hpos_ = 0;
            return;
        }
        const int nt = kTaps;
        taps_.assign(nt, 0.0);
        const double fc = 0.45 / D_;  // normalised cutoff (x sr)
        for (int i = 0; i < nt; ++i) {
            const double t = static_cast<double>(i) - (nt - 1) / 2.0;
            const double s = (t == 0.0)
                                 ? 1.0
                                 : std::sin(M_PI * 2.0 * fc * t) / (M_PI * 2.0 * fc * t);
            const double a = static_cast<double>(i) / static_cast<double>(nt - 1);
            const double bk = 0.42 - 0.5 * std::cos(2.0 * M_PI * a) +
                              0.08 * std::cos(4.0 * M_PI * a);
            taps_[i] = 2.0 * fc * s * bk;
        }
        double sum = 0.0;
        for (double t : taps_) sum += t;
        for (double& t : taps_) t /= sum;  // DC gain exactly 1
        hist_.assign(2 * nt, 0.0);
        hpos_ = nt;
    }

    void reset() {
        if (!hist_.empty()) std::fill(hist_.begin(), hist_.end(), 0.0);
        hpos_ = D_ > 1 ? static_cast<int>(hist_.size()) / 2 : 0;
        phase_ = D_;
    }

    int decimation() const { return D_; }

    // Push one input sample; returns 1 and writes *y when a decimated sample
    // is emitted (deterministic phase: the emit count depends only on the
    // number of input samples since prepare/reset, never on block splits).
    inline int push(double x, double* y) {
        if (D_ == 1) {
            *y = x;
            return 1;
        }
        if (--phase_ <= 0) {
            phase_ += D_;
            if (hpos_ >= static_cast<int>(hist_.size()) - kTaps + 1) {
                // compact: move the last kTaps samples to the front
                std::memmove(hist_.data(), hist_.data() + hpos_ - kTaps,
                             kTaps * sizeof(double));
                hpos_ = kTaps;
            }
            hist_[hpos_] = x;
            // y = sum taps[k] * hist[hpos_ - (kTaps-1) + k]
            const double* h = hist_.data() + hpos_ - (kTaps - 1);
            const double* t = taps_.data();
            double acc = 0.0;
            for (int k = 0; k < kTaps; ++k) acc += t[k] * h[k];
            ++hpos_;
            *y = acc;
            return 1;
        }
        if (hpos_ >= static_cast<int>(hist_.size())) {
            std::memmove(hist_.data(), hist_.data() + hpos_ - kTaps,
                         kTaps * sizeof(double));
            hpos_ = kTaps;
        }
        hist_[hpos_++] = x;
        return 0;
    }

private:
    static constexpr int kTaps = 63;
    int D_ = 1;
    int phase_ = 1;
    int hpos_ = 0;
    std::vector<double> taps_, hist_;
};

// ---------------------------------------------------------------------------
// YIN-style pitch detector (round 13 revision)
// ---------------------------------------------------------------------------
// Port of poc/octavox_poc.py PitchDetector with the round-13 changes:
//   * parameterised frequency range (cfg.fmin/cfg.fmax; the round-12 version
//     hardcoded 60..1200 and CLIPPED sub-60 Hz inputs into a spurious
//     in-range estimate, e.g. a 55 Hz tone reported as 60.1 Hz);
//   * tau_max gets 8 lags of headroom above sr/fmin and estimates whose
//     selected lag sits on the search boundary are REJECTED (the classic
//     clipped-period signature);
//   * the difference/CMND/search passes are fused with an early exit at the
//     first threshold minimum -- numerically identical results (the d[i]
//     accumulation order is unchanged), ~2-4x cheaper on periodic input.
class PitchDetector {
public:
    static constexpr int kWin = 2048;

    void configure(int sr, double fmin, double fmax) {
        sr_ = sr;
        fmin_cfg_ = fmin;
        fmax_cfg_ = fmax;
        // 4 lags of headroom BELOW the shortest wanted lag so an input near
        // fmax resolves at its true period instead of the tau_min-edge
        // octave error (a 1200 Hz tone at 48 kHz: T=40, tau_min=36 -> the
        // true minimum is interior and is found; round 12 started at 40 and
        // reported the 2T minimum -> 600 Hz).
        tau_min_ = std::max(2, static_cast<int>(sr_ / fmax) - 4);
        // 8 lags of headroom above the longest wanted lag so every
        // f0 >= fmin lands strictly inside the search range; the window
        // geometry caps tau_max (m >= 32).
        int want = static_cast<int>(std::ceil(sr_ / fmin)) + 8;
        tau_max_ = std::min(kWin / 2 - 32, want);
        if (tau_max_ <= tau_min_ + 8) tau_max_ = tau_min_ + 8;  // degenerate guard
        // Effective (honest) range after the geometry above:
        fmin_eff_ = static_cast<double>(sr_) / static_cast<double>(tau_max_);
        fmax_eff_ = static_cast<double>(sr_) / static_cast<double>(tau_min_);
        if (fmax_eff_ > fmax) fmax_eff_ = fmax;
        buf_.assign(kWin, 0.0);
        d_.assign(std::max(0, tau_max_ - tau_min_), 0.0);
        cmnd_.assign(d_.size(), 0.0);
        pushed_ = 0;
        last_f0_ = 0.0;
    }

    void reset() {
        std::fill(buf_.begin(), buf_.end(), 0.0);
        pushed_ = 0;
        last_f0_ = 0.0;
    }

    // Push a block into the sliding window (Python push_block semantics).
    void pushBlock(const double* x, int n) {
        pushed_ += n;
        if (n >= kWin) {
            std::copy(x + n - kWin, x + n, buf_.begin());
            return;
        }
        // roll left by n, append
        std::copy(buf_.begin() + n, buf_.end(), buf_.begin());
        for (int i = 0; i < n; ++i) buf_[kWin - n + i] = x[i];
    }

    double estimate() {
        // Round 13: no estimate until the analysis window is fully populated
        // with post-reset samples. Before this guard the partially-filled
        // window (zeros + signal edge) produced degenerate difference
        // functions: an all-zero segment yields d(tau) = 0 for every tau,
        // the argmin falls on lag 0 and the estimate reports sr/tau_min
        // (measured: 1200 Hz at sample 64 on a cold 220 Hz tone), which the
        // round-13 splice commit would act on within a few milliseconds.
        if (pushed_ < kWin) {
            last_f0_ = 0.0;
            return 0.0;
        }
        const std::vector<double>& x = buf_;
        double peak = 0.0;
        for (int i = 0; i < kWin; ++i) peak = std::max(peak, std::abs(x[i]));
        if (peak < 1e-6) {
            last_f0_ = 0.0;
            return 0.0;
        }
        if (tau_max_ <= tau_min_) {
            last_f0_ = 0.0;
            return 0.0;
        }
        // seg = second half of the window; m = len(seg) - tau_max
        const int seg0 = kWin / 2;
        const int m = (kWin - seg0) - tau_max_;
        if (m < 32) {
            last_f0_ = 0.0;
            return 0.0;
        }
        const int ntau = tau_max_ - tau_min_;

        // Fused difference + CMND + valley selection (round 13). For every
        // computed lag the accumulation order matches the round-12 two-pass
        // form exactly. Selection rule: the first point below the threshold
        // enters a candidate valley; the walk then follows the valley while
        // the curve stays below 1.5x the deepest point seen in it, selecting
        // that deepest point. This skips the shallow cos^2 ripple that the
        // finite overlap (m << T at low f0) puts on the CMND descent
        // (measured: a local dip at 0.189 < 0.20 at 0.7 periods on a 55 Hz
        // tone at 48 kHz, which the round-12 first-local-minimum rule
        // selected instead of the true 0.0000 minimum at 872 lags), while
        // the inter-period ridges (cmnd ~ 1) can never satisfy the merge
        // bar, so octave errors cannot be introduced. The early exit keeps
        // the periodic-input cost at O(true period), not O(ntau).
        const double thr = 0.20;
        const double mergeBar = 1.5;
        int idx = -1;
        {
            // d[i] = sum_{j<m} (x[seg0+j] - x[seg0+tau+j])^2, tau = tau_min_+i
            double run = 0.0;
            int filled = 0;  // number of d[] entries computed so far
            auto computeLag = [&](int i) {
                const int tau = tau_min_ + i;
                double s = 0.0;
                for (int j = 0; j < m; ++j) {
                    const double a = x[seg0 + j] - x[seg0 + tau + j];
                    s += a * a;
                }
                d_[i] = s;
                run += s;
                cmnd_[i] = (run > 0.0) ? d_[i] * static_cast<double>(i + 1) / run : 1.0;
                ++filled;
            };
            computeLag(0);
            computeLag(1);
            for (int i = 1; i < ntau; ++i) {
                if (i >= filled) computeLag(i);
                if (cmnd_[i] < thr) {
                    // walk this valley to its deepest point
                    int best = i;
                    int j = i;
                    while (j + 1 < ntau) {
                        if (j + 1 >= filled) computeLag(j + 1);
                        if (cmnd_[j + 1] < mergeBar * cmnd_[best]) {
                            ++j;
                            if (cmnd_[j] < cmnd_[best]) best = j;
                        } else {
                            break;
                        }
                    }
                    idx = best;
                    break;
                }
            }
            if (idx < 0) {
                // argmin over the full range (noise path): finish any
                // remaining lags, then scan -- identical to round 12.
                for (int i = filled; i < ntau; ++i) computeLag(i);
                idx = 0;
                for (int i = 1; i < ntau; ++i)
                    if (cmnd_[i] < cmnd_[idx]) idx = i;
            }
        }
        // Boundary reliability (round 13): a selected lag on the tau_max
        // edge is the clipped-period signature (input below the effective
        // floor). Reject instead of returning a wrong in-range estimate
        // (round 12 returned sr/tau_max for sub-floor inputs -- a 50 Hz
        // tone at 48 kHz was reported as ~55 Hz and accepted).
        if (idx >= ntau - 3) {
            last_f0_ = 0.0;
            return 0.0;
        }
        double tau = static_cast<double>(tau_min_ + idx);
        // parabolic refinement
        if (idx > 0 && idx < ntau - 1) {
            const double y0 = cmnd_[idx - 1], y1 = cmnd_[idx], y2 = cmnd_[idx + 1];
            const double den = y0 - 2.0 * y1 + y2;
            if (std::abs(den) > 1e-15) tau += 0.5 * (y0 - y2) / den;
        }
        double f0 = static_cast<double>(sr_) / tau;
        if (!(fmin_eff_ <= f0 && f0 <= fmax_eff_)) f0 = 0.0;
        last_f0_ = f0;
        return f0;
    }

    double lastF0() const { return last_f0_; }
    int tauMin() const { return tau_min_; }
    int tauMax() const { return tau_max_; }
    double fminEffective() const { return fmin_eff_; }
    double fmaxEffective() const { return fmax_eff_; }

private:
    int sr_ = 48000;
    double fmin_cfg_ = 55.0, fmax_cfg_ = 1200.0;
    double fmin_eff_ = 60.0, fmax_eff_ = 1200.0;
    int tau_min_ = 2, tau_max_ = 800;
    long pushed_ = 0;
    std::vector<double> buf_, d_, cmnd_;
    double last_f0_ = 0.0;
};


// ---------------------------------------------------------------------------
// Per-voice state
// ---------------------------------------------------------------------------
struct VoiceState {
    double ratio_t = 1.0;   // target ratio (2^(st/12))
    double ratio = 1.0;     // gliding ratio
    double base_delay = 256.0;
    double frac = 0.5;      // grain phase [0,1)
    double S = 4096.0;      // current tap spacing
    // unity engagement (round 12)
    double e = 1.0;         // 1 = dual-tap, 0 = single-tap A
    double a = 0.0;         // parking blend: 1 = parked integer read
    int d_park = -1;        // parked integer delay
    // splice commit (round 13): ghost = the old-spacing machine dying out
    // under an equal-gain crossfade while the committed machine takes over.
    bool g_active = false;
    double g_blend = 0.0;   // 0 = all ghost, 1 = all new
    double g_frac = 0.0;
    double g_S = 0.0;
    double g_ratio = 1.0;
    long g_wraps = 0;
    int misalign_run = 0;   // consecutive control updates misaligned
    long last_splice_pos = -(1L << 40);
    // diagnostics
    long wraps = 0;
    long commits = 0;
    long splices = 0;
    long last_commit_sample = -1;
    double misalign_periods = 0.0;
};

}  // namespace

// ---------------------------------------------------------------------------
// AlignedDelayLine::Impl
// ---------------------------------------------------------------------------
struct AlignedDelayLine::Impl {
    static constexpr int kRingBits = 18;
    static constexpr int kRingSize = 1 << kRingBits;  // 262144
    static constexpr int kRingMask = kRingSize - 1;

    std::vector<double> ring;        // age-indexed delay line
    int w = 0;                       // newest sample index
    PitchDetector det;
    Decimator dec;
    std::vector<double> dec_block;   // decimated samples awaiting the detector
    int dec_n = 0;
    int ctrl_n = 0;                  // input samples since the last estimate
    unsigned long long stream_pos = 0;
    const InterpTables* tables = nullptr;  // round 13: set in prepare()
    std::vector<VoiceState> vs;      // [max_voices]
    std::vector<double> f0_hist;     // circular, size f0_history
    std::vector<double> med_scratch; // preallocated median scratch (no alloc)
    int f0_hist_n = 0, f0_hist_i = 0;
    bool have_estimate = false;
    double T_hat_cur = 0.0;          // current median period estimate
    double S_target = 4096.0;
    double fb_state = 0.0;
    double norm = 1.0;               // voice-count normalisation (ramped)
    double norm_target = 1.0;
    double last_f0 = 0.0;
    double e_step = 0.0;             // engagement/splice slew per sample
    Config cfg{};

    // -- ring helpers -------------------------------------------------------
    inline void push(double x) {
        ring[w] = x;
        w = (w - 1) & kRingMask;
    }

    inline double readRaw(int delay) const {
        return ring[(w + delay) & kRingMask];
    }

    // Interpolated read at `delay` (>= 0). Exact-integer delays take the
    // direct sample path (bit-exact; used by the parked unity state).
    // Round 13: the tables come from the Impl member (initialised in
    // prepare()), so this path contains no lazy initialisation of any kind.
    double readInterp(double delay) const {
        if (delay < 0.0) delay = 0.0;
        const double d0 = std::floor(delay);
        const double mu = delay - d0;
        const int i0 = static_cast<int>(d0);
        if (mu == 0.0) {
            return ring[(w + i0) & kRingMask];  // exact integer delay
        }
        switch (cfg.interpolation) {
            case Interpolation::Linear: {
                const double a = ring[(w + i0) & kRingMask];
                const double b = ring[(w + i0 + 1) & kRingMask];
                return a + (b - a) * mu;
            }
            case Interpolation::Lagrange6: {
                int ph = static_cast<int>(mu * 2048.0);  // floor, mu < 1
                if (ph > 2047) ph = 2047;
                const double* wv = tables->lag2048[ph];
                double s = 0.0;
                for (int k = 0; k < 6; ++k)
                    s += wv[k] * ring[(w + i0 + k - 2) & kRingMask];
                return s;
            }
            case Interpolation::Lagrange6Q: {
                int ph = static_cast<int>(mu * 256.0);
                if (ph > 255) ph = 255;
                const double* wv = tables->lag256[ph];
                double s = 0.0;
                for (int k = 0; k < 6; ++k)
                    s += wv[k] * ring[(w + i0 + k - 2) & kRingMask];
                return s;
            }
            case Interpolation::ObsKernel6: {
                // OBS data mode: floor-indexed 256 phases (target phase law).
                int ph = static_cast<int>(mu * 256.0);
                if (ph > 255) ph = 255;
                const float* wv = obs_kernel::kTable[ph];
                double s = 0.0;
                for (int k = 0; k < 6; ++k)
                    s += static_cast<double>(wv[k]) *
                         ring[(w + i0 + k - 2) & kRingMask];
                return s;
            }
        }
        return 0.0;
    }

    // -- spacing management (v2 parity) --------------------------------------
    void updateSpacingTarget(double f0) {
        if (f0 != 0.0 && cfg.fmin <= f0 && f0 <= cfg.fmax) {
            f0_hist[f0_hist_i] = static_cast<double>(cfg.sample_rate) / f0;
            f0_hist_i = (f0_hist_i + 1) % static_cast<int>(f0_hist.size());
            if (f0_hist_n < static_cast<int>(f0_hist.size())) ++f0_hist_n;
            have_estimate = true;
        }
        if (f0_hist_n == 0) {
            S_target = cfg.grain;
            T_hat_cur = 0.0;
            return;
        }
        // median of the history (np.median parity: even count averages the
        // middle two). Uses the preallocated scratch -- NO allocation here
        // (steady-state guarantee).
        med_scratch.assign(f0_hist.begin(), f0_hist.begin() + f0_hist_n);
        std::sort(med_scratch.begin(), med_scratch.end());
        const int n = static_cast<int>(med_scratch.size());
        double t_hat = (n % 2 == 1)
                           ? med_scratch[n / 2]
                           : 0.5 * (med_scratch[n / 2 - 1] + med_scratch[n / 2]);
        T_hat_cur = t_hat;
        // Python round() = round-half-to-even = nearbyint with default env
        const double k = std::nearbyint(cfg.grain / t_hat);
        const double kk = std::max(1.0, k);
        const double S = kk * t_hat;
        S_target = std::min(std::max(S, 0.5 * cfg.grain), 1.5 * cfg.grain);
    }

    // Misalignment of a spacing S against the current median period, in
    // input periods: |S - round(S/T)*T| / T. Zero = the two taps sit an
    // integer number of periods apart (aligned); delta bounds the frozen
    // two-tap gain error by |cos(pi*delta)|.
    static double misalignPeriods(double S, double T) {
        if (!(T > 0.0) || !(S > 0.0)) return 0.0;
        const double k = std::nearbyint(S / T);
        return std::abs(S - k * T) / T;
    }

    // -- splice commit (round 13) ---------------------------------------------
    // Mid-grain alignment commit with continuity preservation: snapshot the
    // old machine as a ghost, commit S <- S_target (tap A's read point
    // preserved; any integer re-wrap is hidden at blend = 0), then blend
    // ghost -> committed over engagement_seconds. Called at control
    // boundaries only.
    void maybeSpliceCommit() {
        if (!have_estimate || !(T_hat_cur > 0.0)) {
            for (auto& v : vs) v.misalign_run = 0;
            return;
        }
        const int nv = static_cast<int>(vs.size());
        for (int i = 0; i < nv; ++i) {
            VoiceState& v = vs[i];
            if (i >= cfg.voices) { v.misalign_run = 0; continue; }  // inactive
            if (v.g_active || v.e < 1.0 || v.a > 0.0) { v.misalign_run = 0; continue; }
            if (v.splices > 0 &&
                static_cast<long>(stream_pos - v.last_splice_pos) <
                    cfg.align_cooldown) {
                v.misalign_run = 0;
                continue;
            }
            const double mis = misalignPeriods(v.S, T_hat_cur);
            v.misalign_periods = mis;
            if (mis > cfg.align_threshold_periods) {
                // The candidate target must actually be aligned (the clamp
                // [G/2, 1.5G] can leave S_target misaligned for extreme
                // period/grain combinations; committing it would churn).
                if (misalignPeriods(S_target, T_hat_cur) <=
                    cfg.align_threshold_periods) {
                    if (++v.misalign_run >= cfg.align_persist) {
                        const double S_old = v.S;
                        // 1. snapshot the ghost (BEFORE overwriting the voice)
                        v.g_active = true;
                        v.g_blend = 0.0;
                        v.g_frac = v.frac;
                        v.g_S = S_old;
                        v.g_ratio = v.ratio;
                        // 2. commit: preserve tap A's read point exactly
                        //    (d = base + frac*S is invariant; an integer
                        //    re-wrap only moves A by whole periods, hidden
                        //    under the blend at weight 0).
                        v.S = S_target;
                        double fn = v.frac * S_old / v.S;
                        fn -= std::floor(fn);
                        v.frac = fn;
                        ++v.commits;
                        ++v.splices;
                        v.last_commit_sample = static_cast<long>(stream_pos);
                        v.last_splice_pos = static_cast<long>(stream_pos);
                        v.misalign_run = 0;
                        v.misalign_periods =
                            misalignPeriods(v.S, T_hat_cur);
                    }
                } else {
                    v.misalign_run = 0;
                }
            } else {
                v.misalign_run = 0;
            }
        }
    }

    // Wrap-time commit (v2 parity, hysteresis gated).
    inline void commitSpacing(VoiceState& v) {
        if (!have_estimate) return;
        if (std::abs(S_target / v.S - 1.0) > cfg.s_hysteresis) {
            v.S = S_target;
            ++v.commits;
            v.last_commit_sample = static_cast<long>(stream_pos);
        }
    }

    // Unity-exit commit: refresh S while B's weight is ~0, preserving the
    // read point exactly (frac_new = frac*S_old/S_new in [0,1)).
    void exitCommitSpacing(VoiceState& v) {
        if (!have_estimate) return;
        if (std::abs(S_target / v.S - 1.0) <= cfg.s_hysteresis) return;
        const double frac_new = v.frac * v.S / S_target;
        if (frac_new >= 0.0 && frac_new < 1.0) {
            v.S = S_target;
            v.frac = frac_new;
            ++v.commits;
            v.last_commit_sample = static_cast<long>(stream_pos);
        }
        // else: keep S; the next natural wrap (or a splice commit) will.
    }

    // Park on the nearest integer delay inside [base, base+S).
    void parkVoice(VoiceState& v) {
        const double d = v.base_delay + v.frac * v.S;
        int d_int = static_cast<int>(std::floor(d + 0.5));
        const double lo = std::ceil(v.base_delay);
        const double hi = std::floor(v.base_delay + v.S) - 1.0;
        if (static_cast<double>(d_int) > hi) d_int = static_cast<int>(hi);
        if (static_cast<double>(d_int) < lo) d_int = static_cast<int>(lo);
        v.d_park = d_int;
    }

    // B-tap readiness (round 13): during a cold start the B tap (delay ~
    // base + S) reads the zero-filled region of the ring until enough
    // samples have been pushed; the complementary blend summed real data
    // with zeros, halving the output amplitude for the first ~90 ms
    // (measured -3.8 dB over the first 100 ms after latency at 48 kHz).
    // While the B data has not arrived the voice runs as the natural
    // single-tap A path; a 128-sample convex crossfade (2.7 ms at 48 kHz)
    // hands over to the dual-tap blend as the data arrives. Convexity
    // bounds the output by max(|A|, |blend|) -- no gain overshoot is
    // possible -- and once readiness reaches 1 the code path is
    // BIT-IDENTICAL to the round-12 arithmetic (the branch is skipped).
    inline double bTapReadiness(double delay) const {
        const double pushed = static_cast<double>(stream_pos) + 1.0;
        const double c = (pushed - (delay - 3.0)) / 128.0;
        return std::min(1.0, std::max(0.0, c));
    }

    // Blend two taps with the effective (possibly morphing) weights,
    // single-tapping while the B tap's data has not arrived yet.
    inline double blendTaps(double A, double B, double wA, double wB,
                            double readiness) const {
        if (readiness >= 1.0) return wA * A + wB * B;  // steady state: bit-exact
        return (1.0 - readiness) * A +
               readiness * (wA * A + wB * B);
    }

    // -- per-sample voice processing -----------------------------------------
    // Returns this voice's output sample.
    // Round-13 structure: (1) ratio glide; (2) advance a ghost that was
    // already running; (3) the voice's own phase ramp + wrap/commit (which
    // may START a ghost by snapshotting this sample's old-machine state);
    // (4) the ghost's read from its advanced-or-snapshotted state; (5) the
    // committed machine's output; (6) the splice blend. The ordering makes
    // both ghost-start paths exact: a control-rate splice commit snapshots
    // the previous sample's state (the ghost then steps it normally), and a
    // startup wrap guard snapshots the already-stepped pre-wrap state (the
    // ghost reads it directly, no double step).
    inline double processVoiceSample(VoiceState& v) {
        // ratio glide (geometric, reference parity)
        v.ratio = v.ratio_t + (v.ratio - v.ratio_t) * Config::kGlideMult;
        const double r = v.ratio;

        // (2) advance a running ghost (dying old-spacing machine; its own
        // frozen spacing, exact S-unchanged hand-off wraps -- but only when
        // the hand-off target is inside the recorded data; during startup
        // the phase simply continues below zero, reading valid recent
        // samples, which is the exact continuation of the output).
        if (v.g_active) {
            v.g_ratio = v.ratio_t + (v.g_ratio - v.ratio_t) * Config::kGlideMult;
            double gf = v.g_frac + (1.0 - v.g_ratio) / v.g_S;
            if (v.g_ratio > 1.0) {
                if (gf < 0.0) {
                    const double gdj = v.base_delay + (gf + 1.0) * v.g_S;
                    if (gdj <= static_cast<double>(stream_pos) + 1.0 - 8.0) {
                        gf += 1.0;
                        ++v.g_wraps;
                    }
                }
            } else {
                if (gf >= 1.0) {
                    gf -= 1.0;  // r <= 1 jumps backward: always valid
                    ++v.g_wraps;
                }
            }
            v.g_frac = gf;
        }

        // grain phase ramp + wrap/commit (v2 parity). Round 13 startup
        // guard on the r > 1 hand-off: the jump target (d + S) must lie
        // inside the recorded data. At large positive shifts the FIRST wrap
        // can fire before the ring holds base + S samples (measured at
        // +1200 cents: the wrap fired at sample 2048 jumping the read to
        // delay 4352 -> 24 ms of digital silence). When the target is not
        // yet recorded the voice re-anchors at the newest valid sample and
        // the splice ghost -- the exact continuation of the pre-wrap read
        // point, still on valid recent data -- carries the 10 ms transition.
        double frac = v.frac + (1.0 - r) / v.S;
        if (r > 1.0) {
            if (frac < 0.0) {
                const double S_old = v.S;
                const double pushed = static_cast<double>(stream_pos) + 1.0;
                const double d_target = v.base_delay + (frac + 1.0) * S_old;
                commitSpacing(v);
                if (d_target <= pushed - 8.0 || v.g_active) {
                    // exact hand-off (a ghost cannot be nested; the rare
                    // wrap-during-splice case takes this branch and accepts
                    // the jump -- the ghost blend is already covering it)
                    frac = (frac + 1.0) * S_old / v.S;
                    while (frac >= 1.0) frac -= 1.0;
                } else {
                    // Re-anchor inside the recorded data. When a period
                    // estimate exists the anchor is CONTENT-ALIGNED to the
                    // continuing read (d_new = d_ghost + m*T_hat), so for
                    // periodic input the switch is phase-exact and the
                    // ghost's short blend only covers the estimator's
                    // sub-period residual; without an estimate (noise,
                    // ambiguous pitch) the anchor is the newest valid
                    // sample and the ghost covers the content step.
                    const double d_ghost = v.base_delay + frac * S_old;
                    const double hi = std::min(pushed - 8.0,
                                               v.base_delay + v.S - 1.0);
                    double d_new = std::max(v.base_delay, pushed - 8.0);
                    if (have_estimate && T_hat_cur > 0.0 && hi > v.base_delay) {
                        long m = static_cast<long>(
                            std::floor((hi - d_ghost) / T_hat_cur));
                        if (m < 0) m = 0;
                        const double d_al = d_ghost +
                            static_cast<double>(m) * T_hat_cur;
                        if (d_al >= v.base_delay && d_al <= hi) d_new = d_al;
                    }
                    if (d_new > v.base_delay + v.S) d_new = v.base_delay + v.S;
                    v.g_active = true;
                    v.g_blend = 0.75;  // short (~120-sample) blend: the
                                       // aligned anchor needs no long cover
                    v.g_frac = frac;      // pre-wrap phase (may be < 0)
                    v.g_S = S_old;
                    v.g_ratio = v.ratio;
                    frac = (d_new - v.base_delay) / v.S;  // in [0,1)
                }
                ++v.wraps;
            }
        } else {
            if (frac >= 1.0) {
                const double S_old = v.S;
                commitSpacing(v);
                frac = (frac - 1.0) * S_old / v.S;
                while (frac < 0.0) frac += 1.0;
                ++v.wraps;
            }
        }
        v.frac = frac;

        // (4) ghost output from its advanced-or-snapshotted state
        double gout = 0.0;
        if (v.g_active) {
            const double gd = v.base_delay + v.g_frac * v.g_S;
            const double gA = readInterp(gd);
            const double gB = readInterp(gd + v.g_S);
            const double gw = 0.5 - 0.5 * std::cos(M_PI * v.g_frac);
            gout = blendTaps(gA, gB, gw, 1.0 - gw,
                             bTapReadiness(gd + v.g_S));
        }

        const double e = v.e;
        const double a = v.a;

        double vout;
        if (e <= 0.0 && a >= 1.0) {
            // Fully parked: bit-exact single integer-tap read.
            vout = readRaw(v.d_park);
        } else {
            const double d = v.base_delay + frac * v.S;
            const double A = readInterp(d);

            // Unified effective weights (e-morph from the unity engagement)
            // with the round-13 startup renormalisation of the B tap.
            const double w = 0.5 - 0.5 * std::cos(M_PI * frac);
            const double wA = (e >= 1.0) ? w : (e * w + (1.0 - e));
            const double wB = (e >= 1.0) ? (1.0 - w) : e * (1.0 - w);
            const double B = readInterp(d + v.S);
            const double dual =
                blendTaps(A, B, wA, wB, bTapReadiness(d + v.S));

            if (a > 0.0) {
                const double park = readInterp(static_cast<double>(v.d_park));
                vout = (1.0 - a) * dual + a * park;
            } else {
                vout = dual;
            }
        }

        // Splice blend (round 13): equal-gain crossfade from the ghost to
        // the committed machine. At blend=0 the output is EXACTLY the old
        // machine's sample (continuity by construction); at blend=1 the
        // ghost is retired.
        if (v.g_active) {
            const double b = v.g_blend;
            v.g_blend = std::min(1.0, b + e_step);
            if (v.g_blend >= 1.0) v.g_active = false;
            return (1.0 - b) * gout + b * vout;
        }
        return vout;
    }

    // -- engagement slew ------------------------------------------------------
    inline void slewEngagement(VoiceState& v) {
        const bool unity = (v.ratio_t == 1.0);  // bit-exact double compare
        const double e_target = unity ? 0.0 : 1.0;
        // 'a' parks only once e has fully reached 0
        const double a_target = (unity && v.e <= 0.0) ? 1.0 : 0.0;
        if (v.e < e_target) v.e = std::min(e_target, v.e + e_step);
        else if (v.e > e_target) v.e = std::max(e_target, v.e - e_step);
        if (v.a < a_target) {
            if (v.a <= 0.0) parkVoice(v);  // (re)compute the parked delay
            v.a = std::min(a_target, v.a + e_step);
        } else if (v.a > a_target) {
            v.a = std::max(a_target, v.a - e_step);
        }
    }
};

// ---------------------------------------------------------------------------
// AlignedDelayLine
// ---------------------------------------------------------------------------
AlignedDelayLine::AlignedDelayLine() = default;
AlignedDelayLine::~AlignedDelayLine() { delete impl_; }

bool AlignedDelayLine::prepare(const Config& cfg) {
    delete impl_;
    impl_ = nullptr;
    ready_ = false;
    if (!(cfg.sample_rate > 0.0)) return false;
    if (cfg.max_voices < 1 || cfg.max_voices > 64) return false;
    if (cfg.voices < 1 || cfg.voices > cfg.max_voices) return false;
    if (!(cfg.grain > 0.0)) return false;
    if (cfg.base_delay < 8.0) return false;
    // Maximum read delay: B tap at d + S with d < base + 32*(mv-1) + S and
    // S <= 1.5*grain, plus 3 extra taps beyond the anchor -> require the whole
    // range to stay inside the 2^18 ring.
    if (cfg.base_delay + 32.0 * (cfg.max_voices - 1) + 3.0 * cfg.grain + 8.0 >=
        static_cast<double>(1 << 18)) {
        return false;
    }
    if (cfg.fmin <= 0.0 || cfg.fmax <= cfg.fmin) return false;
    if (cfg.s_hysteresis < 0.0) return false;
    if (cfg.f0_history < 1 || cfg.f0_history > 64) return false;
    if (cfg.detection_interval < 1) return false;
    if (cfg.engagement_seconds < 0.0) return false;
    if (cfg.analysis_rate_max < 0.0) return false;
    if (cfg.analysis_rate_max > 0.0 && cfg.analysis_rate_max < 1000.0) return false;
    if (cfg.align_persist < 1 || cfg.align_persist > 64) return false;
    if (!(cfg.align_threshold_periods > 0.0)) return false;
    if (cfg.align_cooldown < 0) return false;
    if (!(cfg.feedback > -1.0 && cfg.feedback < 1.0)) return false;

    // Round 13: interpolation tables are constructed HERE (once per process;
    // the first prepare() pays the cost; every later prepare() is a no-op).
    // process() never constructs or guards anything.
    const InterpTables* tables = ensureInterpTables();

    impl_ = new Impl();
    impl_->cfg = cfg;
    impl_->tables = tables;
    impl_->ring.assign(Impl::kRingSize, 0.0);
    impl_->vs.resize(cfg.max_voices);
    impl_->f0_hist.assign(cfg.f0_history, 0.0);
    impl_->med_scratch.assign(cfg.f0_history, 0.0);
    impl_->dec_block.assign(cfg.detection_interval + 2, 0.0);
    impl_->dec_n = 0;
    impl_->ctrl_n = 0;
    impl_->stream_pos = 0;
    // Analysis rate: decimate only when the audio rate exceeds the ceiling.
    const int arm = static_cast<int>(
        cfg.analysis_rate_max > 0.0 ? cfg.analysis_rate_max : cfg.sample_rate);
    const int sr = static_cast<int>(cfg.sample_rate);
    impl_->dec.configure(sr, arm);
    const int dec = impl_->dec.decimation();
    impl_->det.configure((sr + dec - 1) / dec, cfg.fmin, cfg.fmax);
    impl_->e_step =
        cfg.engagement_seconds > 0.0
            ? 1.0 / (cfg.engagement_seconds * cfg.sample_rate)
            : 1.0;
    cfg_ = cfg;
    active_voices_ = cfg.voices;
    ready_ = true;
    reset();
    return true;
}

void AlignedDelayLine::reset() {
    if (!impl_) return;
    Impl& m = *impl_;
    std::fill(m.ring.begin(), m.ring.end(), 0.0);
    m.w = 0;
    m.det.reset();
    m.dec.reset();
    std::fill(m.dec_block.begin(), m.dec_block.end(), 0.0);
    m.dec_n = 0;
    m.ctrl_n = 0;
    m.stream_pos = 0;
    const double st = (m.cfg.ratio > 0.0) ? 12.0 * std::log2(m.cfg.ratio) : 0.0;
    for (int i = 0; i < m.cfg.max_voices; ++i) {
        VoiceState& v = m.vs[i];
        const double off = (m.cfg.spread && i < 8) ? kSpreadSemitones[i] : 0.0;
        v.ratio_t = std::pow(2.0, (st + off) / 12.0);
        v.ratio = v.ratio_t;
        v.base_delay = m.cfg.base_delay + 32.0 * i;
        v.frac = 0.5;
        v.S = m.cfg.grain;
        v.wraps = 0;
        v.commits = 0;
        v.splices = 0;
        v.last_commit_sample = -1;
        v.misalign_run = 0;
        v.misalign_periods = 0.0;
        v.last_splice_pos = -(1L << 40);
        v.g_active = false;
        v.g_blend = 0.0;
        v.g_frac = 0.0;
        v.g_S = 0.0;
        v.g_ratio = 1.0;
        v.g_wraps = 0;
        // Unity engagement: start parked if this voice is at exact unity.
        if (v.ratio_t == 1.0) {
            v.e = 0.0;
            v.a = 1.0;
            m.parkVoice(v);
        } else {
            v.e = 1.0;
            v.a = 0.0;
            v.d_park = -1;
        }
    }
    std::fill(m.f0_hist.begin(), m.f0_hist.end(), 0.0);
    m.f0_hist_n = 0;
    m.f0_hist_i = 0;
    m.have_estimate = false;
    m.T_hat_cur = 0.0;
    m.S_target = m.cfg.grain;
    m.fb_state = 0.0;
    m.norm = 1.0 / active_voices_;
    m.norm_target = m.norm;
    m.last_f0 = 0.0;
}

void AlignedDelayLine::setRatio(double ratio) {
    if (!impl_ || !(ratio > 0.0)) return;
    Impl& m = *impl_;
    const double st = 12.0 * std::log2(ratio);
    for (int i = 0; i < m.cfg.max_voices; ++i) {
        VoiceState& v = m.vs[i];
        const double off = (m.cfg.spread && i < 8) ? kSpreadSemitones[i] : 0.0;
        const double new_t = std::pow(2.0, (st + off) / 12.0);
        const bool was_unity = (v.ratio_t == 1.0);
        v.ratio_t = new_t;
        if (was_unity && new_t != 1.0) {
            // Unity exit: refresh the spacing while tap B carries ~0 weight.
            m.exitCommitSpacing(v);
        }
    }
    m.cfg.ratio = ratio;
    cfg_.ratio = ratio;
}

void AlignedDelayLine::setVoices(int n) {
    if (!impl_) return;
    if (n < 1 || n > impl_->cfg.max_voices) return;
    active_voices_ = n;
    impl_->norm_target = 1.0 / n;
}

void AlignedDelayLine::setSpread(bool on) {
    if (!impl_) return;
    if (impl_->cfg.spread == on) return;
    impl_->cfg.spread = on;
    cfg_.spread = on;
    // Re-derive voice targets from the current ratio (audio-thread update).
    const double st = 12.0 * std::log2(impl_->cfg.ratio > 0.0 ? impl_->cfg.ratio : 1.0);
    for (int i = 0; i < impl_->cfg.max_voices; ++i) {
        VoiceState& v = impl_->vs[i];
        const double off = (on && i < 8) ? kSpreadSemitones[i] : 0.0;
        const double new_t = std::pow(2.0, (st + off) / 12.0);
        const bool was_unity = (v.ratio_t == 1.0);
        v.ratio_t = new_t;
        if (was_unity && new_t != 1.0) impl_->exitCommitSpacing(v);
    }
}

void AlignedDelayLine::setFeedback(double fb) {
    if (!impl_) return;
    impl_->cfg.feedback = std::min(0.999999, std::max(-0.999999, fb));
    cfg_.feedback = impl_->cfg.feedback;
}

int AlignedDelayLine::latencySamples() const {
    if (!impl_) return 0;
    return static_cast<int>(impl_->cfg.base_delay + impl_->cfg.grain * 0.5);
}

void AlignedDelayLine::process(const float* in, float* out, int n) {
    if (!impl_ || n <= 0) return;
    Impl& m = *impl_;
    const bool fb_on = (m.cfg.feedback != 0.0);
    const double fb = m.cfg.feedback;
    const int nv = active_voices_;
    const int interval = m.cfg.detection_interval;

    for (int k = 0; k < n; ++k) {
        // Control rate, stream-aligned: decimate the RAW input (pre-feedback,
        // as the Python pushes xb = x) and fire push+estimate when the
        // interval boundary is crossed. The estimate applies from the
        // boundary sample onward. NOTE (documented delta): the Python
        // reference estimates with the full 64-sample block in the window
        // BEFORE processing that block, which is impossible in a streaming
        // API that writes every output on arrival; with 64-sample-aligned
        // calls the native control timing lags the Python's by at most one
        // interval. Round 13: the decimator phase depends only on the input
        // stream position, so block splits cannot change the estimates.
        {
            double ydec;
            if (m.dec.push(static_cast<double>(in[k]), &ydec)) {
                m.dec_block[m.dec_n++] = ydec;
            }
            if (++m.ctrl_n >= interval) {
                m.det.pushBlock(m.dec_block.data(), m.dec_n);
                m.dec_n = 0;
                m.ctrl_n = 0;
                m.last_f0 = m.det.estimate();
                m.updateSpacingTarget(m.last_f0);
                m.maybeSpliceCommit();
            }
        }

        const double xin = static_cast<double>(in[k]) + (fb_on ? fb * m.fb_state : 0.0);
        m.push(xin);

        double acc = 0.0;
        for (int i = 0; i < nv; ++i) {
            VoiceState& v = m.vs[i];
            m.slewEngagement(v);  // engagement/parking slews (per sample)
            acc += m.processVoiceSample(v);
        }
        // voice-count normalisation (ramped)
        if (m.norm != m.norm_target) {
            const double step = m.e_step;
            if (m.norm < m.norm_target)
                m.norm = std::min(m.norm_target, m.norm + step);
            else
                m.norm = std::max(m.norm_target, m.norm - step);
        }
        const double y = acc * m.norm;
        out[k] = static_cast<float>(y);
        m.fb_state = fb_on ? y : 0.0;
        ++m.stream_pos;
    }
}

VoiceStats AlignedDelayLine::voiceStats(int v) const {
    VoiceStats out;  // by value (round 13): no thread-local scratch, no guards
    if (!impl_ || v < 0 || v >= impl_->cfg.max_voices) return out;
    const VoiceState& s = impl_->vs[v];
    out.wraps = s.wraps;
    out.commits = s.commits;
    out.engaged = (s.e >= 1.0 && !s.g_active) ? 1 : 0;
    out.parked = (s.e <= 0.0 && s.a >= 1.0) ? 1 : 0;
    out.spacing = s.S;
    out.phase = s.frac;
    out.parked_delay = out.parked ? s.d_park : -1;
    out.splicing = s.g_active ? 1 : 0;
    out.splices = s.splices;
    out.last_commit_sample = s.last_commit_sample;
    out.misalign_periods = s.misalign_periods;
    return out;
}

double AlignedDelayLine::lastEstimateHz() const {
    return impl_ ? impl_->last_f0 : 0.0;
}
DetectorInfo AlignedDelayLine::detectorInfo() const {
    DetectorInfo di;
    if (!impl_) return di;
    const int dec = impl_->dec.decimation();
    di.decimation = dec;
    di.analysis_rate =
        impl_->cfg.sample_rate / static_cast<double>(dec);
    di.window_samples = PitchDetector::kWin;
    di.control_interval = impl_->cfg.detection_interval;
    di.tau_min = impl_->det.tauMin();
    di.tau_max = impl_->det.tauMax();
    di.fmin_effective = impl_->det.fminEffective();
    di.fmax_effective = impl_->det.fmaxEffective();
    return di;
}

// ---------------------------------------------------------------------------
// MultichannelShifter
// ---------------------------------------------------------------------------
struct MultichannelShifter::MImpl {
    std::vector<AlignedDelayLine*> engines;
    Config cfg{};
    int channels = 0;
};

MultichannelShifter::MultichannelShifter() = default;
MultichannelShifter::~MultichannelShifter() {
    if (mimpl_) {
        for (auto* e : mimpl_->engines) delete e;
        delete mimpl_;
    }
}

bool MultichannelShifter::prepare(const Config& cfg, int channels) {
    if (channels < 1 || channels > 64) return false;
    if (mimpl_) {
        for (auto* e : mimpl_->engines) delete e;
        delete mimpl_;
        mimpl_ = nullptr;
    }
    mimpl_ = new MImpl();
    mimpl_->cfg = cfg;
    mimpl_->channels = channels;
    for (int c = 0; c < channels; ++c) {
        auto* e = new AlignedDelayLine();
        if (!e->prepare(cfg)) {
            delete e;
            for (auto* x : mimpl_->engines) delete x;
            delete mimpl_;
            mimpl_ = nullptr;
            return false;
        }
        mimpl_->engines.push_back(e);
    }
    return true;
}

void MultichannelShifter::reset() {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->reset();
}

void MultichannelShifter::setRatio(double r) {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->setRatio(r);
}
void MultichannelShifter::setVoices(int n) {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->setVoices(n);
}
void MultichannelShifter::setSpread(bool on) {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->setSpread(on);
}
void MultichannelShifter::setFeedback(double fb) {
    if (!mimpl_) return;
    for (auto* e : mimpl_->engines) e->setFeedback(fb);
}

bool MultichannelShifter::ready() const { return mimpl_ != nullptr; }
int MultichannelShifter::channels() const { return mimpl_ ? mimpl_->channels : 0; }
int MultichannelShifter::latencySamples() const {
    return mimpl_ && !mimpl_->engines.empty() ? mimpl_->engines[0]->latencySamples() : 0;
}

void MultichannelShifter::process(const float* const* in, float* const* out,
                                  int channels, int n) {
    if (!mimpl_ || channels != mimpl_->channels) return;
    for (int c = 0; c < channels; ++c) {
        mimpl_->engines[c]->process(in[c], out[c], n);
    }
}

VoiceStats MultichannelShifter::voiceStats(int channel, int voice) const {
    if (!mimpl_ || channel < 0 || channel >= mimpl_->channels)
        return VoiceStats{};
    return mimpl_->engines[channel]->voiceStats(voice);
}

const char* versionString() { return "octavox-native 13.0.0"; }



}  // namespace octavox
