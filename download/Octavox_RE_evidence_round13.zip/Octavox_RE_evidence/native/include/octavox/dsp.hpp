// OCTAVOX round 13 -- independent native DSP core (public API)
// =============================================================
//
// PROVENANCE
// ----------
// This library is OUR OWN implementation of the round-11 "delayline_aligned"
// design (poc/octavox_v2.py, preserved untouched as the Python reference
// baseline) ported to C++17 in round 12, plus the round-12 unity engagement
// and the round-13 robustness work:
//   * cold-start period alignment (splice commit with a continuity-preserving
//     ghost blend) -- a fresh engine no longer waits for a distant first
//     grain wrap before committing the period-aligned tap spacing;
//   * a sample-rate-robust pitch detector (decimated analysis path for rates
//     above the analysis-rate ceiling + a config-driven frequency range and
//     boundary reliability rejection);
//   * deterministic real-time preparation (the interpolation tables are built
//     during prepare(), never on the first process() call).
// It contains no target code. The single exception is documented data: the
// optional Interpolation::ObsKernel6 mode uses the 256x6 float kernel table
// OBSERVED in the target's .rdata (evidence/analysis_round12/
// r12_obs_kernel_table.h, extraction script r12_interp_table.py) for research
// comparison; that mode is opt-in and clearly labelled.
//
// Nothing here is a VST3 plugin and nothing here claims to reproduce the
// original plugin's runtime behaviour. The target was never executed.
//
// ARCHITECTURE (see native/ARCHITECTURE.md for the full note)
// -----------------------------------------------------------
//  AlignedDelayLine   one mono engine, 1..max_voices voices, planar float in/out.
//  MultichannelShifter N AlignedDelayLine engines (one per channel) with a
//                     shared parameter surface -- channel isolation is
//                     structural, not conventional.
//  prepare()          allocates every buffer (ring, detector window, work
//                     arrays, per-voice state) AND initialises the shared
//                     interpolation tables (round 13: explicit, once per
//                     process; no lazy construction on the audio path).
//                     No allocation happens after prepare() returns;
//                     process() and the parameter setters are steady-state
//                     allocation-free (verified by the acceptance suite's
//                     global-new counter, including the FIRST process call).
//  reset()            returns the engine to the post-prepare state (including
//                     the cold-start alignment state, so a restart re-runs the
//                     early alignment deterministically).
//  process()          block size agnostic: the control-rate detector fires
//                     every `detection_interval` STREAM samples and the
//                     decimator phase follows the absolute stream position,
//                     so the output is invariant to how the caller splits
//                     the stream into blocks.
//
// UNITY BEHAVIOUR (round-12 fix, unchanged)
// ------------------------------
// When a voice's target ratio is EXACTLY 1.0 (bit-exact) it engages a
// single-tap path morphed in/out over `engagement_seconds` and parks on the
// nearest INTEGER delay so that exact unity is a bit-exact delayed copy of
// the input. There is no bypass region: any ratio != 1.0 -- including +-1
// cent -- gets the full dual-tap processing path.
//
// COLD-START ALIGNMENT (round-13 fix)
// -----------------------------------
// Round 12 kept the v2 rule "S is only committed AT a grain wrap"; a fresh
// near-unity engine never wraps (at +-1 cent the first wrap is minutes away),
// so the static two-tap comb persisted (measured -2.41 dB at 220 Hz / +-1
// cent, first commit: never). Round 13 adds the SPLICE COMMIT: once the
// smoothed period estimate is reliable (misalignment above
// `align_threshold_periods` input periods for `align_persist` consecutive
// control updates, engine in the dual-tap regime, cooldown respected), the
// engine commits S <- S_target immediately while a "ghost" copy of the old
// spacing keeps running for `engagement_seconds`; the output is the
// equal-gain crossfade between the ghost and the committed machine, so the
// splice is continuous BY CONSTRUCTION (both endpoints are exact, the blend
// is convex). Non-periodic input (no accepted estimate) falls back to S = G
// exactly as before; the persisted/median-gated trigger keeps transients and
// ambiguous estimates safe. There is still no bypass region.

#pragma once

#include <cstddef>
#include <cstdint>

namespace octavox {

/// Interpolation for the fractional delay reads.
enum class Interpolation : int {
    Linear = 0,     ///< 2-point linear (the reference CLI's "linear")
    Lagrange6 = 1,  ///< 6-point Lagrange, 2048 bin-centre phases (v2 default)
    Lagrange6Q = 2, ///< 6-point Lagrange, 256 bin-centre phases ("lagrange6_q")
    ObsKernel6 = 3, ///< target's observed static 256x6 .rdata kernel (OBS data)
};

/// Engine configuration (all values validated by prepare()).
struct Config {
    double sample_rate = 48000.0;
    double ratio = 1.0;               ///< target pitch ratio (1.0 = unity)
    int voices = 1;                   ///< active voices (1..max_voices)
    int max_voices = 8;               ///< allocated voices
    bool spread = true;               ///< musical spread table for voices > 1
    double feedback = 0.0;            ///< wet feedback in (-1, 1), 0 = off
    Interpolation interpolation = Interpolation::Lagrange6;
    double grain = 4096.0;            ///< G, samples (delay-line grain)
    double base_delay = 256.0;        ///< first voice base delay, samples
    double fmin = 55.0;               ///< detector/spacing floor (Hz)
    double fmax = 1200.0;             ///< detector/spacing ceiling (Hz)
    double s_hysteresis = 0.005;      ///< S commit hysteresis at wraps (relative)
    int f0_history = 8;               ///< period median window
    int detection_interval = 64;      ///< control-rate period, stream samples
    double engagement_seconds = 0.010;///< unity morph / splice blend time
    /// Analysis-rate ceiling for the pitch detector, Hz (round 13). At
    /// sample rates above this the detector runs on a decimated copy of the
    /// input (polyphase FIR, designed in prepare()); 0 disables decimation
    /// (native-rate analysis). The default 48000 keeps 44.1/48 kHz analysis
    /// native and decimates 88.2/96/176.4/192 kHz by 2/2/3/4 respectively,
    /// preserving the detector's frequency range and cold-start timing.
    double analysis_rate_max = 48000.0;
    /// Consecutive control updates with sustained misalignment required
    /// before a mid-grain splice commit fires (round 13; rejects transient
    /// estimates). >= 1.
    int align_persist = 3;
    /// Misalignment threshold for the splice commit, in input PERIODS
    /// (round 13). The comb depth of a misaligned two-tap blend is
    /// |cos(pi*delta)| with delta the misalignment in periods, so 0.05
    /// bounds the worst frozen-weight gain error to -0.019 dB. > 0.
    double align_threshold_periods = 0.05;
    /// Minimum spacing (input samples) between splice-commit starts
    /// (round 13). 0 = no cooldown.
    int align_cooldown = 4096;
    /// Geometric glide multiplier per sample (reference parity: 0.9995).
    static constexpr double kGlideMult = 0.9995;
};

/// Per-voice diagnostics (snapshot after processing; returned BY VALUE since
/// round 13 -- the old const-ref API returned a thread-local scratch object).
struct VoiceStats {
    long wraps = 0;    ///< grain-phase wraps
    long commits = 0;  ///< tap-spacing commits (wrap + unity-exit + splice)
    int engaged = 0;   ///< 1 = normal dual-tap voice, 0 = unity single-tap
    int parked = 0;    ///< 1 = parked on an integer delay (bit-exact unity)
    double spacing = 0.0;      ///< current S
    double phase = 0.0;        ///< current frac
    int parked_delay = -1;     ///< d_park when parked, else -1
    int splicing = 0;          ///< 1 = a splice blend is running (round 13)
    long splices = 0;          ///< splice commits performed (round 13)
    long last_commit_sample = -1; ///< stream sample of the last commit (-1 = none)
    double misalign_periods = 0.0; ///< current S misalignment vs the median period
};

/// Pitch-detector capability report (round 13) -- what the detector ACTUALLY
/// supports for the prepared configuration (after the window geometry and
/// decimation are resolved). Reported by detectorInfo(); tests gate on the
/// REPORTED range so unsupported configurations cannot hide behind
/// permissive gates.
struct DetectorInfo {
    double analysis_rate = 0.0;   ///< effective analysis sample rate (Hz)
    int decimation = 1;           ///< input samples per analysis sample
    int window_samples = 0;       ///< analysis-domain window length
    int control_interval = 0;     ///< input samples between estimates
    int tau_min = 0;              ///< analysis-domain lag range
    int tau_max = 0;
    double fmin_effective = 0.0;  ///< lowest reliably detectable frequency
    double fmax_effective = 0.0;  ///< highest reliably detectable frequency
};

/// One mono engine with 1..max_voices voices (port of the Python
/// AlignedDelayLineShifter + the round-12 unity engagement + the round-13
/// cold-start splice alignment).
class AlignedDelayLine {
public:
    AlignedDelayLine();
    ~AlignedDelayLine();
    AlignedDelayLine(const AlignedDelayLine&) = delete;
    AlignedDelayLine& operator=(const AlignedDelayLine&) = delete;

    /// Validates the config, allocates all state, initialises the shared
    /// interpolation tables (round 13) and resets the engine.
    /// Returns false (and leaves the engine unusable) on invalid input.
    bool prepare(const Config& cfg);

    /// Back to the freshly-prepared state (parameters keep their values;
    /// the cold-start alignment re-runs deterministically).
    void reset();

    // -- parameter updates (audio thread; no allocation, no locks) ---------
    void setRatio(double ratio);      ///< target ratio; exact 1.0 engages unity
    void setVoices(int n);            ///< 1..max_voices (normalisation ramps)
    void setSpread(bool on);
    void setFeedback(double fb);      ///< clamped to (-1, 1)

    const Config& config() const { return cfg_; }
    bool ready() const { return ready_; }
    int latencySamples() const;       ///< nominal (base + grain/2)
    int voices() const { return active_voices_; }

    /// Process a planar mono block of n samples. in/out may not alias.
    /// Any n >= 0; the control rate follows the stream, not the call size.
    void process(const float* in, float* out, int n);

    VoiceStats voiceStats(int v) const;
    /// Last detector estimate (Hz; 0 = none). Diagnostics only.
    double lastEstimateHz() const;
    /// Effective detector capability for this configuration (round 13).
    DetectorInfo detectorInfo() const;

private:
    struct Impl;
    Impl* impl_ = nullptr;
    Config cfg_{};
    bool ready_ = false;
    int active_voices_ = 1;
};

/// N independent mono engines behind one parameter surface.
/// Channel isolation is structural: engine per channel, own ring/state.
class MultichannelShifter {
public:
    MultichannelShifter();
    ~MultichannelShifter();
    MultichannelShifter(const MultichannelShifter&) = delete;
    MultichannelShifter& operator=(const MultichannelShifter&) = delete;

    bool prepare(const Config& cfg, int channels);
    void reset();
    void setRatio(double ratio);
    void setVoices(int n);
    void setSpread(bool on);
    void setFeedback(double fb);

    bool ready() const;
    int channels() const;
    int latencySamples() const;

    /// Planar multichannel block: in[c] / out[c] are per-channel pointers.
    void process(const float* const* in, float* const* out, int channels, int n);

    VoiceStats voiceStats(int channel, int voice) const;

private:
    struct MImpl;
    MImpl* mimpl_ = nullptr;
};

/// Real-time-safety diagnostics (round 13). The interpolation tables are
/// constructed exactly once per process, during the first prepare() call
/// (never inside process()). initDuringProcess() would be non-zero only if
/// some future change reintroduced lazy construction on the audio path; the
/// acceptance suite gates it at zero.
namespace diagnostics {
/// Number of times the interpolation tables have been constructed.
long interpTableInitCount();
/// Constructions that occurred inside process() (must stay 0).
long interpTableInitDuringProcess();
/// True once the tables have been initialised (by prepare()).
bool interpTablesReady();

}  // namespace diagnostics

/// Library version string ("octavox-native 13.0.0").
const char* versionString();

}  // namespace octavox
