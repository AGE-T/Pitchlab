// ---------------------------------------------------------------------------
// OCTAVOX round 20 -- FullRate vs Decimated vs Hybrid detector comparison
// on a REALISTIC-MATERIAL corpus (R20-P2).
// ============================================================================
// PROVENANCE / HONESTY: the corpus below is SYNTHESISED in-process (formula
// + LCG generators). No real recordings exist in this sandbox and none were
// downloaded (licensing cannot be verified for downloaded audio); every
// corpus item is a deterministic, reproducible SURROGATE for the requested
// material classes (monophonic vocal / spoken voice / bass / guitar /
// sustained / vibrato / portamento / transient-rich / noisy-breathy / two
// simultaneous pitched sources), built with physically-motivated models
// (formant synthesis, pulse trains, Karplus-Strong strings, AM noise). The
// comparison therefore measures the three detector architectures on
// controlled surrogates with KNOWN ground-truth f0(t) -- the honest limit is
// stated in the findings: perceptual quality on actual recordings remains
// user-side (the Windows validation kit).
//
// For every corpus item x mode {fullrate, decimated, hybrid}:
//   * the RAW estimate trajectory (every detection_interval samples),
//   * cent-error vs ground truth (median / max, where truth exists),
//   * pitch jitter (median |dEstimate| in cents between updates),
//   * transient recovery (samples from a note-change boundary until the
//     estimate is within 50 cents of the new truth),
//   * tracking latency (median signed lag of the estimate vs truth, in
//     estimation periods, for the portamento item),
//   * octave-error rate (estimates off by >1100 cents from truth),
//   * dropout rate (est == 0 while truth is voiced),
//   * per-estimate CPU (ns, best-of-3 timing runs),
//   * the FINAL audio output (32-bit float WAV, per mode) and its max
//     sample-to-sample step.
// Output: JSON (machine readable) + per-item WAVs + a trajectory JSON for
// visualisation. Exit code 0 iff every gate holds (see kGates).
// ---------------------------------------------------------------------------

#include "octavox/dsp.hpp"
#include "wav_io.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

namespace {

using octavox::AlignedDelayLine;
using octavox::Config;
using octavox::DetectorMode;
using octavox::MultichannelShifter;

// ---------------------------------------------------------------------------
// deterministic generators (shared-law LCG -- same constants as the suite)
// ---------------------------------------------------------------------------
struct Lcg {
    uint64_t s;
    explicit Lcg(uint64_t seed)
        : s(seed ? seed * 6364136223846793005ULL + 1442695040888963407ULL : 1) {}
    double u01() {
        s = s * 6364136223846793005ULL + 1442695040888963407ULL;
        return static_cast<double>(s >> 11) / 9007199254740992.0;
    }
    double bip() { return 2.0 * u01() - 1.0; }
};

double sine(double phase) { return std::sin(2.0 * M_PI * phase); }

// A vocal-like source: glottal pulse train (pulse-shaped, richer harmonics
// than a sine) + 3 formant resonators (2-pole, one-pole-each approximations)
// + breath noise + slow vibrato + micro-jitter. f0(t) from a callable.
struct Formant {
    double f, bw, z1, z2;
    Formant(double f, double bw) : f(f), bw(bw) {}
    double process(double x, double sr) {
        // 2-pole resonator, one-step bilinear approximation
        const double r = 1.0 - M_PI * bw / sr;
        const double w = 2.0 * M_PI * f / sr;
        const double a1 = -2.0 * r * std::cos(w), a2 = r * r;
        const double y = x - a1 * z1 - a2 * z2;
        z2 = z1;
        z1 = y;
        return y;
    }
};

std::vector<double> genVocalish(double f0a, double f0b, double vibHz,
                                double vibCents, int sr, int n, uint64_t seed,
                                std::vector<double>& truth) {
    std::vector<double> x(n);
    Lcg rng(seed);
    Formant f1(700.0, 90.0), f2(1220.0, 110.0), f3(2600.0, 160.0);
    double phase = 0.0, prev = 0.0;
    truth.assign(n, 0.0);
    for (int i = 0; i < n; ++i) {
        const double t = i / double(sr);
        const double vib = vibCents ? vibCents * std::sin(2 * M_PI * vibHz * t) / 1200.0 : 0.0;
        const double f0 = f0a * std::pow(2.0, vib) * std::pow(f0b / f0a, std::min(1.0, t / (n / double(sr))));
        truth[i] = f0;
        // glottal pulse: derivative-of-window pulse train (jittered)
        const double jitter = 1.0 + 0.002 * rng.bip();
        phase += f0 * jitter / sr;
        if (phase >= 1.0) {
            phase -= std::floor(phase);
            prev = 1.0;  // retrigger
        }
        double gl = prev * 0.85;  // decaying excitation
        prev *= 0.72;
        gl += 0.04 * rng.bip();  // aspiration noise
        const double voiced = f1.process(gl, sr) * 1.0 +
                              f2.process(gl, sr) * 0.55 +
                              f3.process(gl, sr) * 0.25;
        x[i] = voiced;
    }
    return x;
}

// spoken-voice surrogate: 4 syllable bursts/sec, f0 stepping 120->95 Hz with
// intra-syllable declination, pauses between syllables (truth = 0 in pauses)
std::vector<double> genSpokenish(int sr, int n, uint64_t seed,
                                 std::vector<double>& truth) {
    std::vector<double> x(n, 0.0);
    truth.assign(n, 0.0);
    Lcg rng(seed);
    Formant f1(500.0, 100.0), f2(1500.0, 130.0);
    const double syl = sr / 4.0;  // 250 ms per syllable
    double phase = 0.0, prev = 0.0;
    for (int i = 0; i < n; ++i) {
        const int k = static_cast<int>(i / syl);
        const double u = (i - k * syl) / syl;  // 0..1 within syllable
        const bool voiced = u < 0.72;          // 72% voicing, 28% pause
        if (voiced) {
            const double f0 = (120.0 - 8.0 * (k % 40)) * (1.0 - 0.12 * u);
            truth[i] = f0;
            phase += f0 / sr;
            if (phase >= 1.0) {
                phase -= std::floor(phase);
                prev = 1.0;
            }
            double gl = prev * 0.85;
            prev *= 0.72;
            gl += 0.05 * rng.bip();
            x[i] = f1.process(gl, sr) + 0.5 * f2.process(gl, sr);
        } else {
            // breath noise in pauses
            x[i] = 0.12 * rng.bip();
            phase = 0.0;
            prev = 0.0;
            f1.z1 = f1.z2 = 0.0;
            f2.z1 = f2.z2 = 0.0;
        }
    }
    return x;
}

// bass surrogate: 82.4 Hz saw-ish (naive saw + mild lowpass), steady
std::vector<double> genBass(int sr, int n, std::vector<double>& truth) {
    std::vector<double> x(n);
    truth.assign(n, 82.41);
    double ph = 0.0, z = 0.0;
    for (int i = 0; i < n; ++i) {
        ph += 82.41 / sr;
        ph -= std::floor(ph);
        const double saw = 2.0 * ph - 1.0;
        z += 0.35 * (saw - z);  // one-pole LP
        x[i] = z * 0.8;
    }
    return x;
}

// guitar surrogate: Karplus-Strong plucks, 2 notes/sec, 110 -> 146.8 Hz
std::vector<double> genGuitar(int sr, int n, uint64_t seed,
                              std::vector<double>& truth) {
    std::vector<double> x(n, 0.0);
    truth.assign(n, 0.0);
    Lcg rng(seed);
    const double syl = sr / 2.0;
    const double notes[2] = {110.0, 146.83};
    std::vector<double> dl(512, 0.0);
    int dp = 0;
    double lastPluck = -1e9;
    double curF = notes[0];
    for (int i = 0; i < n; ++i) {
        const int k = static_cast<int>(i / syl);
        const double noteT = i - k * syl;
        const double f = notes[k % 2];
        if (noteT == 0.0) {
            curF = f;
            lastPluck = i;
            const int D = std::max(2, static_cast<int>(std::lround(sr / f)));
            for (size_t j = 0; j < dl.size(); ++j) dl[j] = 0.0;
            for (int j = 0; j < D; ++j) dl[j] = rng.bip();
            dp = 0;
        }
        const int D = std::max(2, static_cast<int>(std::lround(sr / curF)));
        const double cur = dl[dp];
        const double nxt = dl[(dp + 1) % D];
        dl[dp] = 0.5 * (cur + nxt) * 0.996;  // damping
        dp = (dp + 1) % D;
        x[i] = cur;
        // truth: the intended note, decaying confidence; zero for the first
        // 5 ms after the pluck (the KS burst is not yet periodic)
        truth[i] = (i - lastPluck > sr / 200) ? curF : 0.0;
    }
    return x;
}

// two simultaneous pitched sources: 220 Hz + 277.2 Hz sines (a whole-tone
// apart), truth = the 220 Hz one (documented ambiguity for any estimator)
std::vector<double> genTwoPitch(int sr, int n, std::vector<double>& truth) {
    std::vector<double> x(n);
    truth.assign(n, 220.0);
    for (int i = 0; i < n; ++i) {
        const double t = i / double(sr);
        x[i] = 0.45 * sine(220.0 * t) + 0.35 * sine(277.18 * t) +
               0.05 * sine(440.0 * t);
    }
    return x;
}

// portamento: exponential glide 130 -> 260 Hz over 1.5 s, then steady
std::vector<double> genPortamento(int sr, int n, std::vector<double>& truth) {
    std::vector<double> x(n);
    truth.assign(n, 0.0);
    double ph = 0.0;
    const double glideN = 1.5 * sr;
    for (int i = 0; i < n; ++i) {
        const double f = (i < glideN)
                             ? 130.0 * std::pow(2.0, i / glideN)
                             : 260.0;
        truth[i] = f;
        ph += f / sr;
        ph -= std::floor(ph);
        x[i] = 0.5 * (2.0 * ph - 1.0) * 0.7 + 0.3 * sine(ph);  // saw+sine mix
    }
    return x;
}

// transient-rich: bright sine bursts + impulsive attacks (congas-like),
// stepped pitches 196/246/293 Hz, 3 bursts/sec
std::vector<double> genTransients(int sr, int n, uint64_t seed,
                                  std::vector<double>& truth) {
    std::vector<double> x(n, 0.0);
    truth.assign(n, 0.0);
    Lcg rng(seed);
    const double syl = sr / 3.0;
    const double fs[3] = {196.0, 246.94, 293.66};
    double ph = 0.0;
    for (int i = 0; i < n; ++i) {
        const int k = static_cast<int>(i / syl);
        const double u = (i - k * syl) / syl;
        const double f = fs[k % 3];
        ph += f / sr;
        ph -= std::floor(ph);
        const double env = std::exp(-6.0 * u);
        const double attack = (u < 0.01) ? 1.0 - u / 0.01 : 0.0;
        x[i] = env * (0.6 * sine(ph) + 0.3 * sine(2.0 * ph)) +
               attack * rng.bip() * 0.8;
        truth[i] = (u > 0.05) ? f : 0.0;  // ambiguous during the attack
    }
    return x;
}

// noisy/breathy: strong noise + a weak 330 Hz periodic component (SNR ~0 dB)
std::vector<double> genNoisy(int sr, int n, uint64_t seed,
                             std::vector<double>& truth) {
    std::vector<double> x(n);
    truth.assign(n, 330.0);
    Lcg rng(seed);
    double ph = 0.0;
    for (int i = 0; i < n; ++i) {
        ph += 330.0 / sr;
        ph -= std::floor(ph);
        x[i] = 0.18 * sine(ph) + 0.55 * rng.bip();
    }
    return x;
}

// ---------------------------------------------------------------------------
struct CorpusItem {
    std::string name;
    std::string klass;
    std::vector<double> x;
    std::vector<double> truth;   // f0(t) per sample; 0 = unvoiced/ambiguous
    bool hasTruth;
    double noteBoundariesSec[8];
    int nBoundaries;
};

// per-sample CPU of the whole 1-voice engine on a steady 1 s window
// (best of 3); x64 gives ns per ESTIMATE at the 64-sample cadence. The
// detector-ONLY cost lives in the instrumented bench (stage attribution).
double g_nsPerSample1v = 0.0;

struct ModeResult {
    double medianCentErr = 0.0;
    double maxCentErr = 0.0;
    double p95CentErr = 0.0;
    double jitterCents = 0.0;
    double octaveErrRate = 0.0;   // fraction of voiced-truth estimates
    double dropoutRate = 0.0;     // est==0 while truth voiced
    double transientRecoveryMs = -1.0;  // worst boundary; -1 = no boundary
    double latencyEstimates = 0.0;      // median lag in estimation periods
    double nsPerEstimate = 0.0;
    double outMaxStep = 0.0;
    long nEst = 0, nVoicedTruth = 0, nOctave = 0, nDropout = 0;
};

// run one corpus item through one detector mode; record trajectory + metrics
ModeResult runMode(const CorpusItem& it, DetectorMode mode, int sr,
                   std::vector<double>& trajOut, std::vector<float>& wavOut) {
    const int n = static_cast<int>(it.x.size());
    AlignedDelayLine e;
    Config cfg;
    cfg.sample_rate = sr;
    cfg.ratio = std::pow(2.0, 5.0 / 12.0);  // +5 semitones: real shifting load
    cfg.detector_mode = mode;
    e.prepare(cfg);
    std::vector<float> in(n), out(n, 0.0f);
    for (int i = 0; i < n; ++i) in[i] = static_cast<float>(it.x[i]);
    const int interval = cfg.detection_interval;  // 64
    trajOut.clear();
    trajOut.reserve(n / interval + 16);
    int done = 0;
    while (done < n) {
        const int k = std::min(1024, n - done);
        e.process(in.data() + done, out.data() + done, k);
        done += k;
        for (int p = 0; p < k; ++p) trajOut.push_back(e.lastEstimateHz());
    }

    // CPU: best-of-3 re-run over a 1 s steady window (estimates fire inside)
    {
        const int m = std::min(sr, n - sr);
        double best = 1e300;
        for (int r = 0; r < 3; ++r) {
            AlignedDelayLine e2;
            e2.prepare(cfg);
            const auto t0 = std::chrono::steady_clock::now();
            int d2 = 0;
            while (d2 < m) {
                const int k = std::min(1024, m - d2);
                e2.process(in.data() + d2, out.data() + d2, k);
                d2 += k;
            }
            const auto t1 = std::chrono::steady_clock::now();
            const double ns =
                std::chrono::duration<double, std::nano>(t1 - t0).count();
            best = std::min(best, ns);
        }
        g_nsPerSample1v = best / std::max(1, m);
    }

    ModeResult r;
    r.nsPerEstimate = g_nsPerSample1v * 64.0;
    wavOut = out;

    // metrics vs truth (skip the first 0.75 s: window fill/lock-in)
    std::vector<double> errs;
    double prevEst = 0.0;
    std::vector<double> jit;
    long nEst = 0, nVoiced = 0, nOct = 0, nDrop = 0;
    const int skip = static_cast<int>(0.75 * sr);
    for (size_t k = 0; k < trajOut.size(); ++k) {
        const int sample = static_cast<int>(k);
        if (sample < skip) {
            if (trajOut[k] > 0) prevEst = trajOut[k];
            continue;
        }
        ++nEst;
        const double est = trajOut[k];
        const double tr = (sample < n) ? it.truth[sample] : 0.0;
        if (tr > 0.0) {
            ++nVoiced;
            if (est <= 0.0) {
                ++nDrop;
            } else {
                const double c = 1200.0 * std::log2(est / tr);
                errs.push_back(std::abs(c));
                if (std::abs(c) > 1100.0) ++nOct;  // octave-class error
            }
        }
        if (est > 0.0 && prevEst > 0.0)
            jit.push_back(std::abs(1200.0 * std::log2(est / prevEst)));
        if (est > 0.0) prevEst = est;
    }
    r.nEst = nEst;
    r.nVoicedTruth = nVoiced;
    r.nOctave = nOct;
    r.nDropout = nDrop;
    r.octaveErrRate = nVoiced ? double(nOct) / nVoiced : 0.0;
    r.dropoutRate = nVoiced ? double(nDrop) / nVoiced : 0.0;
    if (!errs.empty()) {
        std::sort(errs.begin(), errs.end());
        r.medianCentErr = errs[errs.size() / 2];
        r.maxCentErr = errs.back();
        r.p95CentErr = errs[size_t(double(errs.size()) * 0.95)];
    }
    if (!jit.empty()) {
        std::sort(jit.begin(), jit.end());
        r.jitterCents = jit[jit.size() / 2];
    }
    // transient recovery: after each note boundary, samples until the
    // estimate is within 50 cents of the new truth (worst boundary)
    if (it.nBoundaries > 0) {
        double worstMs = 0.0;
        for (int b = 0; b < it.nBoundaries; ++b) {
            const int bs = static_cast<int>(it.noteBoundariesSec[b] * sr);
            double recMs = -1.0;
            for (size_t k = 0; k < trajOut.size(); ++k) {
                const int sample = static_cast<int>(k);
                if (sample < bs) continue;
                const double tr = it.truth[sample];
                if (tr <= 0.0) continue;
                const double est = trajOut[k];
                if (est > 0.0 && std::abs(1200.0 * std::log2(est / tr)) <= 50.0) {
                    recMs = double(sample - bs) / sr * 1000.0;
                    break;
                }
            }
            worstMs = std::max(worstMs, recMs);
        }
        r.transientRecoveryMs = worstMs;
    }
    // output max step (final audio discontinuity metric)
    double mx = 0.0;
    for (int i = 1; i < n; ++i)
        mx = std::max(mx, std::fabs(double(out[i]) - double(out[i - 1])));
    r.outMaxStep = mx;
    return r;
}

// ---------------------------------------------------------------------------
int g_fail = 0;

void jprint(const char* k, double v) { std::printf("    \"%s\": %.10g,\n", k, v); }
void jprints(const char* k, const std::string& v) {
    std::printf("    \"%s\": \"%s\",\n", k, v.c_str());
}

}  // namespace

int main(int argc, char** argv) {
    std::string outDir = "detcompare";
    bool dumpWav = true;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--out") == 0 && i + 1 < argc)
            outDir = argv[++i];
        else if (std::strcmp(argv[i], "--no-wav") == 0)
            dumpWav = false;
    }
    const int sr = 48000;
    const double dur = 4.0;
    const int n = static_cast<int>(dur * sr);

    std::vector<CorpusItem> corpus;
    auto add = [&](const char* name, const char* klass, std::vector<double> x,
                   std::vector<double> truth, bool hasTruth,
                   const std::vector<double>& bounds = {}) {
        CorpusItem it;
        it.name = name;
        it.klass = klass;
        it.x = std::move(x);
        it.truth = std::move(truth);
        it.hasTruth = hasTruth;
        it.nBoundaries = static_cast<int>(bounds.size());
        for (size_t i = 0; i < bounds.size() && i < 8; ++i)
            it.noteBoundariesSec[i] = bounds[i];
        corpus.push_back(std::move(it));
    };
    {
        std::vector<double> tr;
        auto x = genVocalish(196.0, 196.0, 5.5, 35.0, sr, n, 424242, tr);
        add("monophonic_vocal_vibrato", "vocal", std::move(x), std::move(tr), true);
    }
    {
        std::vector<double> tr;
        auto x = genSpokenish(sr, n, 777, tr);
        add("spoken_voice_syllabic", "spoken", std::move(x), std::move(tr), true,
            {0.25, 0.5, 0.75});
    }
    {
        std::vector<double> tr;
        auto x = genBass(sr, n, tr);
        add("bass_steady_82hz", "bass", std::move(x), std::move(tr), true);
    }
    {
        std::vector<double> tr;
        auto x = genGuitar(sr, n, 31337, tr);
        add("guitar_karplus_plucks", "guitar", std::move(x), std::move(tr), true,
            {0.5, 1.0, 1.5});
    }
    {
        std::vector<double> tr;
        auto x = genVocalish(330.0, 330.0, 0.0, 0.0, sr, n, 555, tr);
        add("sustained_note_330hz", "sustained", std::move(x), std::move(tr), true);
    }
    {
        std::vector<double> tr;
        auto x = genPortamento(sr, n, tr);
        add("portamento_130_260", "portamento", std::move(x), std::move(tr), true);
    }
    {
        std::vector<double> tr;
        auto x = genTransients(sr, n, 999, tr);
        add("transient_rich_bursts", "transients", std::move(x), std::move(tr), true,
            {1.0 / 3, 2.0 / 3, 1.0});
    }
    {
        std::vector<double> tr;
        auto x = genNoisy(sr, n, 616, tr);
        add("noisy_breathy_snr0db", "noisy", std::move(x), std::move(tr), true);
    }
    {
        std::vector<double> tr;
        auto x = genTwoPitch(sr, n, tr);
        add("two_simultaneous_pitches", "twopitch", std::move(x), std::move(tr), true);
    }

    struct ModeName { DetectorMode m; const char* s; };
    const ModeName modes[3] = {{DetectorMode::FullRate, "fullrate"},
                               {DetectorMode::Decimated, "decimated"},
                               {DetectorMode::Hybrid, "hybrid"}};

    std::printf("{\n  \"tool\": \"octavox_r20_detcompare\",\n");
    std::printf("  \"version\": \"%s\",\n", octavox::versionString());
    std::printf("  \"sample_rate\": %d,\n  \"duration_seconds\": %.1f,\n", sr, dur);
    std::printf("  \"corpus_honesty\": \"SYNTHETIC deterministic surrogates "
                "(formula+LCG, known ground truth); no real recordings were "
                "available or downloaded in this sandbox\",\n");
    std::printf("  \"items\": [\n");

    // gates (documented; loose -- this is a COMPARISON dataset, the hard
    // accuracy gates live in the acceptance suite)
    int itemIdx = 0;
    for (const auto& it : corpus) {
        std::printf("    {\n");
        jprints("name", it.name);
        jprints("class", it.klass);
        std::printf("      \"modes\": [\n");
        for (int mi = 0; mi < 3; ++mi) {
            std::vector<double> traj;
            std::vector<float> wav;
            ModeResult r = runMode(it, modes[mi].m, sr, traj, wav);
            std::printf("        {\n");
            jprints("mode", modes[mi].s);
            jprint("median_cent_err", r.medianCentErr);
            jprint("p95_cent_err", r.p95CentErr);
            jprint("max_cent_err", r.maxCentErr);
            jprint("jitter_cents_median", r.jitterCents);
            jprint("octave_err_rate", r.octaveErrRate);
            jprint("dropout_rate", r.dropoutRate);
            jprint("transient_recovery_ms_worst", r.transientRecoveryMs);
            jprint("ns_per_estimate_1voice_engine", r.nsPerEstimate);
            jprint("out_max_step", r.outMaxStep);
            std::printf("          \"n_est\": %ld, \"n_voiced\": %ld, "
                        "\"n_octave\": %ld, \"n_dropout\": %ld\n",
                        r.nEst, r.nVoicedTruth, r.nOctave, r.nDropout);
            std::printf("        }%s\n", mi < 2 ? "," : "");
            if (dumpWav) {
                // WAV per item+mode (32-bit float; the FINAL audio output)
                std::string p = outDir + "/" + it.name + "_" + modes[mi].s + ".wav";
                writeWavF32(p, wav.data(), static_cast<int>(wav.size()), 1, sr);
                // trajectory JSON per item+mode (visualisation data)
                std::string tp = outDir + "/traj_" + it.name + "_" + modes[mi].s + ".json";
                std::FILE* tf = std::fopen(tp.c_str(), "w");
                if (tf) {
                    std::fprintf(tf, "{\"item\": \"%s\", \"mode\": \"%s\", "
                                     "\"sample_rate\": %d, \"interval\": 1, "
                                     "\"truth_every_sample\": true, "
                                     "\"estimates\": [",
                                 it.name.c_str(), modes[mi].s, sr);
                    // decimate the dump to every 8th estimate (file size);
                    // the full-resolution analysis above used every estimate.
                    const int step = 8;
                    bool first = true;
                    for (size_t k = 0; k < traj.size(); k += step) {
                        std::fprintf(tf, "%s%.6f", first ? "" : ",",
                                     traj[k]);
                        first = false;
                    }
                    std::fprintf(tf, "]}\n");
                    std::fclose(tf);
                }
            }
        }
        std::printf("      ]\n    }%s\n", itemIdx + 1 < (int)corpus.size() ? "," : "");
        ++itemIdx;
    }
    std::printf("  ]\n}\n");
    std::printf("detcompare: %d items x 3 modes%s\n", (int)corpus.size(),
                dumpWav ? " (+ WAVs + trajectories)" : "");
    return g_fail == 0 ? 0 : 1;
}
