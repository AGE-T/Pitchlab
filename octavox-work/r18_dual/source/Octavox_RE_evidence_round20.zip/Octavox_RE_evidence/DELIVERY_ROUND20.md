# OCTAVOX ROUND 20 — DELIVERY

Contents delta vs round 19: the 17.0.0 core (the R20-P0 VST3 default-state
fix + the third detector mode DetectorMode::Hybrid with its study knob;
defaults UNCHANGED — the Decimated detector stays the default), the
97-case suite (4 new r20 cases: hybrid battery / hybrid-vs-fullrate /
neighbourhood study / dual-mono stereo integrity; no gate weakened), FOUR
reference-hash records (r15 legacy + r18-obs legacy + r19 default — all
reproducing on 17.0.0 — + the new r20 hybrid record), the R20-P1 original
feature-reconstruction matrix (machine-readable JSON + extraction
artifacts: UI strings, parameter name blocks, registration-site analysis
with ranges/defaults, xrefs, choice tables), the r20_detcompare corpus
comparison tool + dataset (9 synthetic-surrogate items × 3 detector modes
with trajectories + float WAVs + 11 metrics each), the hybrid clickscan
(288 renders), the 224-row r20 bench matrix (200 dec + 12 full + 12
hybrid), vst3/PARAMETER_SEMANTICS.md (the P4 document),
octavox_r15refcap --detector hybrid, octavox_r19_clickscan --detector,
the setComponentState implementation + the wrapper suite's 16th case
(param_default_state_sync — the six default/state-sync scenarios, 38
parameters, no control moved),
docs/OCTAVOX_ROUND20_FINDINGS.md.

Verification from a fresh extraction:
  cd Octavox_RE_evidence/native
  cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
  ./build/octavox_tests                        # 97/97
  ./build/octavox_r15refcap --legacy           # r15_reference_hashes.txt 4/4
  ./build/octavox_r15refcap                    # r19_reference_hashes.txt 4/4
  ./build/octavox_r15refcap --detector hybrid  # r20_reference_hashes.txt 4/4
  ./build/octavox_r20_detcompare --out detcmp  # the corpus comparison
  sha256sum -c ../checksums.txt

NOT included (by design): the VST3 SDK (pinned-SHA acquisition via
tools/get_vst3_sdk.sh), the Windows dual-build delivery (separate
OctavoxRE_R20_Windows_x64_Dual_Build.zip — built by tools/r20_dual_build.sh
from THIS source; its identity record ships in the zip and the chain logs
are mirrored in evidence/logs/r20_*), build directories.

The original Eventide binary was never executed; runtime behaviour of the
target remains UNK. The ObsKernel6 interpolation mode remains the only
target-derived data in this package (the statically observed 256x6 .rdata
kernel table, round 12; the R20-P1 feature matrix adds STATICALLY observed
UI strings, parameter registrations and choice tables from the same
binary — never executed).
