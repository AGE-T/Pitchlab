# OCTAVOX ROUND 20 — FINDINGS
## Complete Feature Reconstruction and Adaptive YIN Pitch Tracking

Generated: 2026-10-31 (Europe/Budapest), in the development sandbox
(Debian 13 x86_64, 2-core Intel Xeon, GCC 14.2.0 Linux builds; llvm-mingw
clang 23.1.2 release 20260922-ucrt-ubuntu-22.04-x86_64 for the Windows
cross-builds — the toolchain was LOST to a sandbox reset this round and
re-acquired byte-identically by release tag; recorded deviation below).
The reference machine for every CPU number is THIS 2-core sandbox.

Three evidence classes remain strictly separated: (1) static observations
of the original target (the P1 feature matrix — all static, the binary
never executed), (2) measurements of OUR OWN independent implementation
(everything else), (3) runtime observations of the original target (NONE;
standing rule).

Environment recovery note: the /home/z/octavox and /home/z/tools trees
were wiped by a sandbox reset before this round. The original binary was
re-verified intact from the persistent upload copy
(/home/z/my-project/upload/Ox.vst3, sha256
7bb260f66bb9c1b21b27f64f29e6fdd2865c34f8a31ad1c0ef21a1db7f32f1f2 —
identical to the round-1 preserved original), cmake/pefile/capstone
reinstalled, llvm-mingw re-acquired. NO UI screenshot exists in this
environment (the upload directory contains only Ox.vst3 and the round-8
zip) — P1 was driven by the binary's own UI string tables, parameter
registration code and PNG resource names instead; entries that would
require the screenshot are marked UNK.

---

## VERDICT TABLE

| Task-book item | Verdict | Key number |
|---|---|---|
| P0 VST3 default parameter initialization | **DONE — real bug found, fixed, gated** | Every parameter of a NEW instance reported normalized 0 (Pitch −24, Wet 0%, gains 0 — **24-semitone worst display error, measured**) while the engine ran the true defaults; after the fix: 0 error, all six scenarios, 38 params, no control moved |
| P0 `setComponentState` | **DONE** | Implemented (rewind + delegate to setState); the SDK base returned kNotImplemented |
| P1 feature reconstruction matrix | **DONE** | 40-entry matrix (machine+human readable); the original's parameter table extracted statically: 30+ families with 4cc ids, ranges, defaults, choice tables |
| P1 Randomize semantics | **RESOLVED** | rdep = random pitch-modulation depth → dtonicii9.modamt1..8 (slew-limited random walk = modN); it does NOT randomize settings/snapshots |
| P1 Crossfade semantics | **RESOLVED to UNK-consumer** | xfad: 0..0.1 s, default 0.03 s; TWO crossfade mechanisms exist statically (per-voice grain xf_v; delay_xf in the global feedback path) but NO netlist string wires xfad to either — consumer UNK, honestly recorded; NOT equivalent to our 8 ms commit crossfade |
| P1 Spread naming collision | **CONFIRMED** | The original's spread = stereo width (inspread/outspread, default 0); ours = harmony map. Documented, NOT renamed (compatibility) |
| P2 Hybrid detector | **DONE** | Coarse decimated search (verbatim R19 stage-1) + full-rate restricted-lag refinement with the normalised first-minimum law; W sweep 8..128 all ≤ 0.02 cents on the battery |
| P2 3-mode comparison corpus | **DONE** | 9 synthetic-surrogate items × 3 modes × (trajectory JSON + 32-bit float WAV + 11 metrics); honesty note: no real recordings available |
| P2 adaptive mode | **ASSESSED — NOT implemented** | The measured data does not justify an adaptive controller: Hybrid already delivers FullRate-class trajectories at 1.3× Decimated cost; no host parameter added |
| P3 dual-mono / Haas | **DONE — explained and gated** | Dual-mono → L/R BIT-IDENTICAL (7 configs, both interpolators, 48/96 kHz); the "Haas-like" impression = the engine's intrinsic 2304-sample (48 ms @48k) wet delay at unity+wet100% (base+grain/2, measured by cross-correlation), identical in both channels; the second voice adds a second parked read — the classic harmonizer-at-unity doubling |
| P4 parameter semantics doc | **DONE** | native/vst3/PARAMETER_SEMANTICS.md (all 38 params, the ratio-composition law incl. the zero-offset fallback, the collision, the original-vs-ours mapping) |
| P5 regression gates | **DONE** | 97/97 release + 97/97 ASan/UBSan ZERO reports; hashes: legacy 4/4 + legacy-obs 4/4 + r19-default 4/4 (both reproduce on 17.0.0) + NEW r20-hybrid 4/4; clickscan 288 renders ALSO for the Hybrid mode; 96 kHz stereo 8 voices: Decimated 11.2% / Hybrid 15.2% / FullRate 101.3% CPU; 0 allocations; 0 locks (unchanged design) |
| Windows dual builds | **DONE** | OctavoxRE_R20_Windows_x64 (v1.2.0, both variants, byte-reproducible links, 3-hash proof, validation kit incl. the dual null test) |
| Evidence archive | **DONE** | Octavox_RE_evidence_round20.zip + checksum manifest |

---

## 1. PRIORITY 0 — the VST3 default-state bug (found, fixed, gated)

### 1.1 Root cause (source-level)

`OctavoxParameter`'s constructor called the SDK's default `Parameter()`
constructor — which does NOT initialise the parameter's CURRENT value
(`valueNormalized` stays `{0.}`) — and then set only
`info.defaultNormalizedValue`. The SDK's own constructors seed BOTH
(`Parameter::Parameter(const ParameterInfo&)` initialises
`valueNormalized(info.defaultNormalizedValue)`). Result: after
`initialize()`, every one of the 38 parameter OBJECTS reported normalized 0
— plain-minimum values: Pitch Shift **−24**, Wet/Dry **0%**, every voice
gain **0**, every voice delay **0 ms**, Spread **off** — while the DSP
engine (`surface_ = defaultSurface()`) ran the documented defaults.

This is EXACTLY the user report: the Generic Editor disagrees with the DSP
state at creation, and "appears correctly only after manually moving a
control" (the host's first `setParamNormalized`/`performEdit` overwrites
the stale 0). A parameter-metadata scan could never catch it (the metadata
was always correct) — only value reads without touching a control can.

### 1.2 Fix (two parts)

1. `OctavoxParameter` ctor now seeds `valueNormalized =
   info.defaultNormalizedValue` (the same mechanism as the SDK's
   Parameter(info) ctor; no `changed()` notification — no dependents
   exist at registration time).
2. `OctavoxNativeProcessor::setComponentState` implemented: the SDK's
   `EditController::setComponentState` returns kNotImplemented, leaving
   hosts that drive the combined component through the IEditController
   protocol unsynced. Ours rewinds the stream defensively (a host may pass
   the SAME stream it already fed to setState) and delegates to the
   authoritative `setState`.

### 1.3 The six-scenario gate (`param_default_state_sync`, wrapper case 16)

1. New instance (factory + IEditController interface only): worst plain
   error **0** (was 24 semitones — measured by reverting the fix for the
   proof run); engine surface == defaults == controller values.
2. New instance after prepare + one block: unchanged.
3. Save + restore (same instance): all 38 restored values match.
4. State restore into a FRESH instance: BOTH via `IComponent::setState`
   AND via `IEditController::setComponentState` (through the interface
   vtable, stream NOT pre-rewound — the rewind is proven).
5. Repeated initialize/terminate cycles ×4: defaults re-published every
   cycle (the parameter container is cleared in terminate and rebuilt).
6. Host display ↔ processor state: host sets a value via
   setParamNormalized, the queue applies the same value, display ==
   parameter object == DSP surface == persisted state.

Wrapper suite: 15 → **16 cases**; 16/16 per variant (release); the bug
proof (revert → scenarios 1/2/5 fail with 24-semitone display error,
surface still correct) is recorded in the delivery log.

## 2. PRIORITY 1 — the original's feature architecture, statically

Full matrix: `evidence/analysis_round20/r20_feature_matrix.json` (40
entries; every entry: UI label, parameter/module id, ranges, defaults,
producer/consumer, DSP fields, exact evidence addresses, OBS/DER/UNK,
our implementation status) + the extraction artifacts
(`r20_ui_strings_raw.json`, `r20_param_name_blocks.json`,
`r20_param_regs.json`, `r20_xrefs.json`, `r20_ptr_refs.json`).

### 2.1 What was newly recovered this round (all STATIC, from the binary)

* The original's **parameter registration function**
  (`0x1801A0A00..0x1801A3400`): 30 registration sites, each
  `lea r8,[name-block]; mov edx,<4cc id>; call 0x18030BA60`, with the
  calling convention **xmm3 = min, [rsp+0x20] = max, [rsp+0x28] =
  default** (verified by Master Tune 392..494 def 440 and Input Level
  −95..+12 def 0).
* The **parameter name table** (triple-strings "Long\nShort\nAlt"): the
  original's full host surface is far larger than ours —
  Tempo/Session-Tempo/Master-Tune/Scale/Pitch-Tracking/Instrument/Minimum-
  Pitch/Crossfade/Input-Level/Output-Level/Wet-Dry/Loop-Feedback/Loop-Delay/
  Beat-Loop/**Randomize**/Live-Mode/Key-Lock/Mix-Lock + per-voice
  **Level%d/Feedback%d/Pan%d/Delay%d/Shift%d/Interval%d/Enable%d/Beat%d** +
  Voice-Select/MIDI-Control/Meter-Num/Meter-Den + Bypass.
* The **choice tables** (static .data pointer lists): 17 keys (with
  enharmonic Db/Eb/Gb/Ab/Bb/Cb), 16 Instruments (Soprano..Bass Voice,
  Bass Guitar, Guitar, Piano/Synth, Tenor/Soprano Sax, Synth Lead/Bass/Pad,
  Drums), 48 Low-Note choices (C0..B3), 3 sync modes (Off/Session/Manual),
  15 scales (Major..Whole-Tone + a legacy User-scale list with
  userscale1..12 nets), **29 musical intervals** (+2oct..−2oct) for
  Interval%d.
* **Per-voice defaults tables**: Shift defaults at `0x18039C8C8`
  (diagonal 8×8: +4, −4, +14, +10, +14, +17, +7, +21 semitone values),
  beat-delay fractions at `0x18039CC68` ([0.036, 0.25, 0.5, 0.75, 1,
  1.25, 1.5, 1.75] + −3 sentinels = ms mode), and the ±2400-cent Shift
  range constants.
* **Parameter identities**: Randomize = `rdep` (the SAME 4cc id as the
  graph's "rnd dpth" input) — resolving its semantics (see verdict);
  Crossfade = `xfad`; Input Level = `igan` (matches the `gain=igan-out`
  net); per-voice Shift = the `shtN→pcentN` chain; the sync-mode selection
  is the `c_switch` in `c_adderN = dlyN + c_switch → delayamtN`.

### 2.2 Answers to the task's specific questions

* **Crossfade**: the original has TWO crossfade mechanisms statically
  (the per-voice grain-boundary two-tap crossfade `xf_v`, fixed
  arithmetic; and `delay_xf` modules, xfadetime=20 ms, in the global
  feedback path) but NO netlist wiring from the `xfad` parameter to
  either — its exact consumer is **UNK** (the evidence gap: no
  `xfad=`-style record string exists; resolving it would need the JUCE
  parameter→module delivery path, which the graph records do not cover).
  It is **NOT equivalent** to our 8 ms grain-commit crossfade (different
  mechanism class; ours is an independent design for the analogous
  purpose).
* **Randomize**: RESOLVED — `rdep` ("rnd dpth", UI 0..100 default 20,
  module record 0..200 default 50 — both readings recorded) is the
  **random pitch-modulation DEPTH**: it feeds `dtonicii9.modamt1..8`
  while the slew-limited random walk (`rdm slew N`) feeds `modN`. It does
  not randomize pitch targets, delays, snapshots or voice placement.
* **Spread collision**: CONFIRMED — the original's spread
  (`inspread`/`outspread`, both default 0) is stereo width. Our Spread is
  the harmony map. Documented in PARAMETER_SEMANTICS.md §4; not renamed
  (session compatibility; the task's compatibility-handling requirement).

### 2.3 Roadmap output (the prioritised extension list)

P1 (fills audible gaps in our engine): per-voice pan; per-voice feedback;
musical Interval%d surface over the recovered 29-interval table + the
R17 Q-D diatonic mapping; per-voice Beat/tempo sync. P2: key/scale/tune
host surface (tables already recovered); Minimum Pitch; Loop Delay
(global feedback delay); instrument-adaptive filters (CutFreq tables
already recovered). P3: snapshots (16 slots + revert + current/global);
Live Mode delay compensation; Randomize (rdep) modulation; MIDI Control.
Every entry carries its evidence addresses in the matrix JSON.

## 3. PRIORITY 2 — the three detector modes

### 3.1 The Hybrid architecture (`DetectorMode::Hybrid`, NOT the default)

Stage 1: the EXACT R19 Decimated estimator (same anti-alias cascade,
window, threshold, cumulative-mean laws — an intentional verbatim copy so
the coarse behaviour is the documented R19 estimator) → coarse fractional
lag τ_dec. Stage 2: τ_host = τ_dec·D is mapped to the host grid and the
RAW full-rate difference function is evaluated over the R13-b full-rate
window in a restricted neighbourhood [τ_host−W, τ_host+W] (default W=32
host samples; `hybrid_half_width` 1..128 is a validated study knob), with
the **cumulative-mean normalisation + first-minimum-below-threshold law
applied to the neighbourhood** and parabolic refinement on the raw d at
full sample resolution. Cadence and the ~42.7 ms window time span are
preserved; the coarse stage still searches the COMPLETE lag range (no
coverage removed).

**A measured design correction (recorded)**: the first implementation
took the raw argmin of the neighbourhood — W=128 at 880 Hz/48 kHz picked
the sub-octave dip (exactly 1200.02 cents low) because a periodic
signal's raw d approaches zero at BOTH T and 2T. The normalised
first-minimum law (the YIN octave discrimination, restricted to the
neighbourhood) fixed it; the finding is documented in the source.

### 3.2 Accuracy (acceptance suite, gates unchanged — 93→97 cases)

* `detector_hybrid_accuracy_battery` (110/220/440/880 Hz @ 48+96 kHz):
  worst **0.0196 cents** (gate ≤ 1 cent).
* `detector_hybrid_vs_fullrate_delta`: steady-tone delta
  **0.36 cents** worst (gate ≤ 2); chirp octave-folded residual within
  the 20-cent gate with equal octave-jump counts.
* `detector_hybrid_neighborhoods`: W ∈ {8,16,32,64,128} × the battery ×
  both rates: worst **0.0196 cents** — every width holds the gate (the
  coarse stage's refined lag is far more accurate than the smallest W).
* `dual_mono_stereo_integrity` (see P3 below).

### 3.3 The corpus comparison (r20_detcompare; 9 items × 3 modes)

HONESTY: the corpus is SYNTHETIC (deterministic formula+LCG surrogates
with known ground truth: formant-synthesis vocal with vibrato/jitter,
syllabic spoken voice with pauses, steady bass, Karplus-Strong guitar,
sustained note, portamento glide, transient bursts, SNR-0 dB noisy,
two simultaneous pitches). No real recordings exist in this sandbox and
none were downloaded (licensing unverifiable). The comparison measures
the three architectures on controlled surrogates; perceptual quality on
real material remains user-side (the validation kit).

Headline numbers (48 kHz, +5 st shifting load, 1 voice):

| item | FullRate med ¢ | Decimated med ¢ | Hybrid med ¢ | Hybrid CPU vs Dec |
|---|---|---|---|---|
| vocal vibrato | 6.255 | 6.319 | **6.251** | 1.31× |
| spoken syllabic | 2089.7 | 1844.6 | 1879.9 | 1.31× |
| bass steady | 0.001 | 0.000 | **0.000** (max 2.8¢ vs FR's 91¢) | 1.32× |
| guitar KS plucks | 2.177 | 2.586 | **2.175** | 1.31× |
| sustained 330 Hz | 1212.4 | 1201.5 | 1201.6 | 1.31× |
| portamento 130→260 | 3.549 | 3.513 | 3.581 | 1.29× |
| transient bursts | 0.817 | 0.742 | 0.800 | 1.30× |
| noisy SNR-0 dB | 1225.7 | 1893.8 | 1876.7 | 1.30× |
| two simultaneous pitches | 202.3 | 1335.9 | 1337.0 | 1.31× |

Reading (all recorded, nothing cherry-picked): on the vocable items the
three architectures track within cents of each other — the median errors
are dominated by the shared 42.7 ms window lag on moving pitch (vibrato/
portamento), not by the estimator grid. The "large" medians on
spoken/sustained/noisy/two-pitch items are **YIN-family octave/harmonic
dip choices that all three modes make nearly identically** (the
sustained-330 item was probed: the surrogate's autocorrelation at the
true period is 0.989 — the signal IS 330 Hz; the estimators'
sub-octave preference is a genuine family behaviour, measured, not a
corpus defect). Notable Hybrid wins: bass max error 2.8¢ vs FullRate's
91¢; on every vocable item Hybrid is CLOSER to FullRate than Decimated
is. CPU: Hybrid ≈ 1.3× Decimated ≈ 0.34× FullRate at 48 kHz (the gap
grows with rate).

Trajectories + WAVs: `evidence/analysis_round20/detcompare/` (56 files:
27 float WAVs + 27 trajectory JSONs + the report).

### 3.4 CPU (bench matrix, 224 rows: 200 dec + 12 full + 12 hyb)

| config (stereo, b128) | Decimated | Hybrid | FullRate |
|---|---|---|---|
| 96 kHz 8 voices | 11.2% CPU (8.96× RT) | **15.2% CPU (6.59× RT)** | 101.3% (0.99× RT, 749/750 misses) |
| 96 kHz 1 voice | 6.7% | 10.9% | 97.2% |
| 192 kHz 8 voices | 22.2% | 39.5% (2.53× RT) | 805.9% |

0 steady-state allocations across all rows; 0 deadline misses outside the
documented host-scheduler stalls. The R19 regression target (96 kHz stereo
8 voices ≥ 30% headroom on the DEFAULT Decimated mode) still holds
(88.8% headroom); the Hybrid mode ALSO clears it (84.8%).

### 3.5 Adaptive quality mode — assessment (NOT implemented)

The measured data does NOT justify an adaptive controller: Hybrid already
delivers FullRate-class trajectories at 1.3× Decimated cost with a fixed
W; a Decimated→FullRate promotion near transitions would at best match
that at higher complexity, and the confidence proxy (the coarse cmnd
minimum) is recorded per estimate (`hybridConfidence()`) for future use
should real-material evidence (user-side) demand it. **No host parameter
was added** (the task's requirement); the Decimated default is unchanged.
The eventual Efficient/Balanced/High-Quality product surface is deferred
until real-material comparison data exists (the validation kit now ships
the three-mode comparison capability).

## 4. PRIORITY 3 — dual-mono / stereo / the "Haas" report

Structural: `MultichannelShifter` = one full `AlignedDelayLine` engine
per channel — independent detectors, trackers, rings, voice states, grain
phases; setters broadcast identically to every channel.

Measured (`dual_mono_stereo_integrity`, 7 configs — both interpolators,
48+96 kHz, 1 and 2 voices, default and minimum per-voice delays, spread
off, fb 0, wet 100%): **L/R bit-identical in every config** (max diff 0,
correlation exactly 1, interchannel delay 0, stereo width 0). A dual-mono
input with identical settings produces a dual-mono output — documented,
intentional, deterministic.

**The user's "Haas-like behaviour even with stereo input, Global Shift 0,
Voice 1 offset 0, wet 100%"**: at unity ratio a voice PARKS and the wet
output IS the input delayed by the engine's intrinsic latency — measured
by broadband cross-correlation at exactly **2304 samples = base_delay +
grain/2 = 48 ms @ 48 kHz**, identical in both channels (this is also the
reported plugin latency). A 48 ms full-band delay of the input at wet 100%
is a strong doubling/Haas sensation by itself. **"Activating a second
voice appeared to double the effect"**: with Spread ON (the default!) the
second voice is at +7 semitones (a fifth — the harmony map), adding a
second shifted copy; with Spread OFF the second voice also parks and adds
a second parked read at its own per-voice base delay (defaults stagger by
32 samples/voice) — two closely spaced full-band echoes, i.e. a literal
double. Both paths are the classic harmonizer-at-unity behaviour,
intentional and now measured and documented. No artificial stereo
widening was introduced (the task's prohibition).

The DEFAULT per-voice Base Delay surface (5.3..18.9 ms) is OUR R12-era
engine default; the ORIGINAL's per-voice delay parameter defaults to 0 ms
('delayamt=0') — a documented surface divergence (feature-matrix A-group),
NOT a stereo issue.

## 5. PRIORITY 4 — parameter semantics

`native/vst3/PARAMETER_SEMANTICS.md`: the full 38-parameter table with
actual DSP effects, the ratio-composition law
(`r_v = 2^((PitchShift + SpreadOffset_v + Offset_v)/12)` with the
zero-offset fallback explicitly documented), the Voices/Mute interaction,
the Spread naming-collision decision (documented, not renamed), and the
original-vs-ours surface mapping. The 38-parameter host surface is
UNCHANGED this round (the R20-P0 work changed initialisation behaviour,
not the surface).

## 6. PRIORITY 5 — regression gates (all green)

* Suite: **97/97 release** (25.8 s) and **97/97 ASan+UBSan with ZERO
  sanitizer reports** (188 s). 93 inherited cases with UNCHANGED gates
  (the R19 record hashes still reproduce bit-exactly on the 17.0.0 core —
  the FullRate and Decimated paths are verbatim); 4 new r20 cases.
* Hash records (all four 4/4, all double-run reproducible, verified in
  the build chain's LEG 1): r15 legacy, r18-obs legacy, r19 default
  (reproduces on 17.0.0), **r20 hybrid (new)**.
* Wrapper tests **16/16** per variant (the new default-state gate);
  module integration **12/12** per variant; Steinberg validator **47/47**
  per variant; dual-module null test PASS on the fresh R20 Linux bundles.
* Clickscan: the full 288-render scan re-run for the **Hybrid** mode
  (clickscan_hybrid/) — same clean verdicts as the R19 modes.
* Real-time/alloc/lock gates: see §3.4; process() remains allocation-free
  and lock-free by design (the no_alloc gate re-run in the wrapper suite).
* Dual-mono integrity: §4.

## 7. UNK / honest limits

* The original binary was never executed; all P1 findings are STATIC.
  No UI screenshot existed in this environment (feature discovery used
  the binary's own string/registration tables); screenshot-only details
  (visual layout, meter graphics) are UNK.
* The Crossfade (`xfad`) consumer is UNK (documented gap).
* The corpus is synthetic (no real recordings available/licensable in
  this sandbox); perceptual superiority of any mode on REAL material is
  user-side evidence — the Windows validation kit ships the three-mode
  comparison, but no user-side data has been collected yet. The user's
  listening observation (FullRate subjectively better) is RECORDED and
  was the motivation for the Hybrid design; the synthetic corpus cannot
  confirm or refute it.
* Windows PE modules cannot execute here (wine blocked); Windows-side
  functional validation is user-side via the kit.
* CPU numbers are for THIS 2-core sandbox.

## 8. Deliverables map

1. THIS file + DELIVERY_ROUND20.md.
2. Feature matrix: evidence/analysis_round20/r20_feature_matrix.json (+
   extraction artifacts: ui strings, name blocks, param regs, xrefs,
   ptr refs).
3. Roadmap + open questions: §2.3 + docs/OCTAVOX_OPEN_QUESTIONS.md (r20
   addendum) + this file.
4. Three detector modes: dsp.hpp/dsp.cpp (DetectorMode), r19_clickscan
   --detector, bench hybrid rows, refcap --detector hybrid.
5. Corpus + results: evidence/analysis_round20/detcompare/ (56 files).
6. Trajectory visualisation data: detcompare/traj_*.json (27 files).
7. Dual-mono/stereo integrity: the suite case + §4 + detcompare WAVs.
8. Corrected VST3 defaults: octavox_params.cpp, the processor's
   setComponentState, wrapper case 16.
9. Updated acceptance tests: tests/test_main.cpp (97 cases).
10. CPU comparison: r20_bench_matrix.json (224 rows) + §3.4.
11. Windows dual builds + kit: OctavoxRE_R20_Windows_x64 (v1.2.0).
12. Archive: Octavox_RE_evidence_round20.zip + checksum manifest.

## 9. Reproduction

```
cd native
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
./build/octavox_tests                          # 97/97
./build/octavox_r15refcap --legacy             # 15.0.0 record 4/4
./build/octavox_r15refcap                      # 16.0.0 record 4/4 (r19)
./build/octavox_r15refcap --detector hybrid    # 17.0.0 record 4/4 (r20)
./build/octavox_r20_detcompare --out detcompare
./build/octavox_bench --matrix --json matrix.json
./build/octavox_r19_clickscan --detector hybrid --out cs_hyb
# the full chain (Linux variants + Windows + verification):
tools/r20_dual_build.sh
```
