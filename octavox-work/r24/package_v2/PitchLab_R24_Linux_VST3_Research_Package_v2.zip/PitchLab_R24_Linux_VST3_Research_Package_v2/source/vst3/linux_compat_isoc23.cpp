// ---------------------------------------------------------------------------
// PITCHLAB HARMONIZER -- VST3 wrapper LINUX GLIBC COMPATIBILITY SHIM
// (R24-v2, Correction A)
// ============================================================================
// PROBLEM (verified on the delivered pre-correction binary): the VST3 SDK
// translation units linked into the module (pluginterfaces/base/funknown.cpp,
// base/source/fstring.cpp, ...) call sscanf; when built against glibc >= 2.38
// headers with GCC 14, <stdio.h> declares the scanf family through
// __REDIRECT_NTH to the C23-semantic symbols (__isoc23_sscanf et al.), so
// the module records dynamic dependencies on GLIBC_2.38 -- and FAILS TO LOAD
// on every older runtime (Ubuntu 22.04 LTS: glibc 2.35; Debian 12: 2.36),
// even though nothing in the plugin actually needs C23 scanf semantics
// (no 0b/0B binary-literal format strings are used anywhere).
//
// FIX (this TU, deliberately minimal and document-first): the MODULE defines
// the isoc23 scanf entry points LOCALLY and forwards them to the stable
// __isoc99_* v-forms, which glibc has exported since version 2.7 (verified:
// __isoc99_vsscanf@@GLIBC_2.7 present in glibc 2.41 and unchanged in
// semantics needed here). The linker then binds the module's references to
// these in-DSO definitions: no GLIBC_2.38 version dependency is recorded and
// the binary's glibc floor drops to 2.34 (the pthread symbols folded into
// libc by glibc 2.34 -- see LINUX_COMPATIBILITY_REPORT.md for the full
// symbol audit). No system library is bundled or statically replaced; the
// shim is three forwarding functions compiled from our own build scope only
// (the pinned-SHA SDK tree itself stays byte-untouched).
//
// Scope: linked into the octavoxnative MODULE only (the shipped artifact).
// The host-side tools (validator, moduleinfotool, the test harnesses) run on
// the build machine and keep their native references -- they are not part of
// the delivered plugin binaries.
// ---------------------------------------------------------------------------
#if defined(__linux__) && (defined(__GNUC__) || defined(__clang__))

#include <cstdio>
#include <cstdarg>

extern "C" {

// The stable glibc exports (since 2.7) -- declared locally so this TU does
// not pick up any header redirection itself.
int __isoc99_vsscanf(const char* s, const char* fmt, __builtin_va_list arg);
int __isoc99_vscanf(const char* fmt, __builtin_va_list arg);
int __isoc99_vfscanf(std::FILE* stream, const char* fmt,
                     __builtin_va_list arg);

// The glibc >= 2.38 C23-semantic scanf entry points, satisfied in-DSO.
// C23 semantics differ from C99 only for 0b/0B-prefixed integers with base
// 0/2 -- never used by the SDK's format strings; the forwarding is therefore
// behaviour-preserving for every call the module can make.
int __isoc23_sscanf(const char* s, const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    const int r = __isoc99_vsscanf(s, fmt, ap);
    va_end(ap);
    return r;
}

int __isoc23_scanf(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    const int r = __isoc99_vscanf(fmt, ap);
    va_end(ap);
    return r;
}

int __isoc23_fscanf(std::FILE* stream, const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    const int r = __isoc99_vfscanf(stream, fmt, ap);
    va_end(ap);
    return r;
}

}  // extern "C"

#endif  // __linux__ && (GNUC || clang)
